import React, { useState } from "react";
import { Image } from "react-bootstrap";
import uploadIcon from "../../../assets/icons/icon-upload-outline.svg";
import closeIcon from "../../../assets/icons/icon-n-close.svg";
import successIcon from "../../../assets/icons/icon-surface-notifstatus-success.svg";
import Files from "react-files";
import "./style/FileUpload.scss";

const constructFileObjectList = (fileObjectList, removeFromFile) => {
  return (
    fileObjectList &&
    fileObjectList.map((ele, idx) => (
      <div className="fileBorder" key={ele.name}>
        <div className="iconleft">
            <Image src={successIcon} className="icon" />
            <span className="ml16 uploadColor">{ele.name}</span>
        </div>
        <Image src={closeIcon} className="icon pointer iconRight" onClick={() => removeFromFile(idx)}/>
      </div>
    ))
  );
};

const handleChange = ( e, {
    multiple, setFileObject, fileObjectList, getFileObject,
    setErrorMessage
}) => {
    if( e.length > 0) {
        if (multiple ) {
            if( fileObjectList.length > 0 
                && fileObjectList.filter((ele)=> ele.name === e[0].name && ele.extension === e[0].extension).length !== 0
            ) {
                setErrorMessage(`File with name ${e[0].name} is already present`)
            } else {
                setFileObject([...fileObjectList, e[0]]);
            }
        } else {
            setFileObject([e[0]]);
        }
    }
    getFileObject([...fileObjectList, e[0]]);
}

const FileUpload = (props) => {
  const [fileObjectList, setFileObject] = useState([]);
  const [ errorMsg , setErrorMessage ] = useState('');
  const {
    multiple = true,
    acceptedFileFormat,
    getFileObject = () => null,
  } = props;
  const removeFromFileList = ( idx ) =>  {
        const deconstructedList = [...fileObjectList];
        deconstructedList.splice(idx, 1)
        setFileObject([...deconstructedList])
  }
  return (
    <>
      <div className="flex fileUpload flexWrap pb16">
        <div>
          {fileObjectList.length !== 0 ? (
            <div className="flex">{constructFileObjectList(fileObjectList, removeFromFileList)}</div>
          ) : (
            ""
          )}
        </div>
        <Files
            {...props}
            multiple={multiple}
            accepts={acceptedFileFormat}
            onChange={(e) => {
                handleChange(e, {
                    multiple, setFileObject, fileObjectList, getFileObject,
                    setErrorMessage
                })
            }}
            onError={(e) => {
                setErrorMessage(e.message);
            }}   
        >
        {(!multiple && fileObjectList.length === 0) || multiple ? (
            <>
                <div className="fileBorder pointer">
                    <div className="flex">
                        <Image src={uploadIcon} className="icon" />
                        <span className="ml16 uploadColor">Upload a file</span>
                    </div>
                </div>
                { errorMsg && <span className="error"> {errorMsg} </span>}
            </>
        ) : (
            ""
        )}
        </Files>
      </div>
    </>
  );
};

export default FileUpload;
