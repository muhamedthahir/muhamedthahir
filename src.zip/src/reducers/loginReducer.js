import { 
    UPDATE_MSAL_INSTANCE,
    UPDATE_AUTH_OBJ,
    VIEW_DASHBOARD,
    UPDATE_SSO_TOKEN,
    VIEW_ALL_ANNOUNCEMENT
} from "../actions/types";
const initialState = {};

const loginReducer = ( login, action) => {
    if( login === undefined) {
        login = initialState;
    }
    const { type, payload } = action;
    if( type === UPDATE_MSAL_INSTANCE) {
        return  { ...login, "msalInstance": payload}
    } else if( type === UPDATE_AUTH_OBJ) {
        return  { ...login, "authObj": payload}
    } else if( type === VIEW_DASHBOARD) {
        return  { ...login, "dashboard": payload}
    } else if( type === VIEW_ALL_ANNOUNCEMENT ) {
        return  { ...login, "announcementList": payload}
    } else if( type === UPDATE_SSO_TOKEN) {
        return  { ...login, "ssoToken": payload}
    }
    return {...login};
}

export default loginReducer;
