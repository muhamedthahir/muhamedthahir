import { combineReducers } from "redux";
import ccmparameter from "./ccmparameter";
import gatewayReducer from "./gatewaymanagement";
import approvalReducer from "./approval";
import gatewaySettingReducer from "./gatewaySettingReducer";
import notificationReducer from "./notification";
import loginReducer from  './loginReducer';

export default combineReducers({
  ccmparameter,
  gatewayReducer,
  approvalReducer,
  gatewaySettingReducer,
  notificationReducer,
  loginReducer
});
