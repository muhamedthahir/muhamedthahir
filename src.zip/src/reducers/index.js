import { combineReducers } from "redux";
import ccmparameter from "./ccmparameter";
import gatewayReducer from "./gatewaymanagement";
import approvalReducer from "./approval";
import gatewaySettingReducer from "./gatewaySettingReducer";
import notificationReducer from "./notification";

export default combineReducers({
  ccmparameter,
  gatewayReducer,
  approvalReducer,
  notificationReducer,
  gatewaySettingReducer
});
