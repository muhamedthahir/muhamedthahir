import {
    VIEW_ALL_PENDING,
    VIEW_ALL_APPROVAL,
    VIEW_ALL_REJECTED
} from "../actions/types";
  
const initialState = [];

const approvalReducer = ( approval, action ) => {
    if( approval === undefined ) {
        approval = initialState;
    }
    const { type, payload } = action;
    switch (type) {    
        case VIEW_ALL_PENDING:
          return { ...approval, "viewAllPending": payload } ; 
        case VIEW_ALL_APPROVAL:
            return { ...approval, "viewAllApproved": payload } ; 
        case VIEW_ALL_REJECTED:
          return { ...approval, "viewAllRejected": payload } ; 
        default:
            return {...approval};
    }
}
export default approvalReducer;