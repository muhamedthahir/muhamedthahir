import {
    VIEW_ALL_PENDING,
    VIEW_ALL_APPROVAL,
    VIEW_ALL_REJECTED,
    UPDATE_APPROVAL_STATUS
} from "../actions/types";
  
const initialState = [];

const approvalReducer = ( approval, action ) => {
    if( approval === undefined ) {
        approval = initialState;
    }
    const { type, payload } = action;
    switch (type) {    
        case VIEW_ALL_PENDING:
          return { ...approval, "viewAllPending": payload } ; 
        case VIEW_ALL_APPROVAL:
            return { ...approval, "viewAllApproved": payload } ; 
        case VIEW_ALL_REJECTED:
          return { ...approval, "viewAllRejected": payload } ; 
        case UPDATE_APPROVAL_STATUS:
           return { ...approval, "updateApprovalStatus": payload } ; 
        default:
            return {...approval};
    }
}
export default approvalReducer;