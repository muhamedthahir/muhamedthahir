import {
    VIEW_GWS_FOR_GWTYPE
} from "../actions/types";

const initialState = [];


export const gatewaySettingReducer = (gatewayReducer, action ) => {
    if(gatewayReducer === undefined){
      gatewayReducer= initialState;
    }
    const { type, payload } = action;
    if (type === VIEW_GWS_FOR_GWTYPE) {
      return { ...gatewayReducer, "viewGatewayTypeGwSettings": payload }
    } else {
      return {...gatewayReducer};
    }
}

export default gatewaySettingReducer;