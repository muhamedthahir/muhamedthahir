import {
    VIEW_GATEWAY_TYPE,
    VIEW_ALL_GATEWAY_TYPE,
    VIEW_ALL_GATEWAY_PROVIDER,
    VIEW_GATEWAY_SETIINGS,
    VIEW_GATEWAY_PROVIDERS,
    VIEW_GATEWAY_PROVIDER_SETTING,
    VIEW_ALL_CHANNAL,
    UNBLOCK_CHANNEL,
    VIEW_GWPR_FOR_GWTYPE,
    VIEW_ALL_GW_SETTING_CODE,
    GATEWAY_INITIAL_DATA,
    VIEW_GATEWAY_PROVIDER_SETIINGS,
    GATEWAY_TYPE_SUBMIT,
  } from "../actions/types";
  
  const initialState = [];
  
  const gatewayReducer = (gateway, action) => {
    if( gateway === undefined) {
      gateway = initialState;
    }
    const { type, payload } = action;
    switch (type) {    
      case VIEW_GATEWAY_TYPE:
        return { ...gateway, "viewGateway": payload } ;      
      case VIEW_ALL_GATEWAY_TYPE:
          return {...gateway,"viewAllGatewayType": payload };
      case VIEW_ALL_GATEWAY_PROVIDER:
          return  {...gateway,"viewAllGatewayProvider": payload };
      case VIEW_GATEWAY_SETIINGS:
          return { ...gateway, "viewGatewaySettings": payload };
      case VIEW_GATEWAY_PROVIDERS:
          return { ...gateway, "viewGatewayProviders": payload };
      case VIEW_GATEWAY_PROVIDER_SETTING:
          return { ...gateway, "viewGatewayProviderSetting": payload };
      case VIEW_ALL_CHANNAL:
          return { ...gateway, "viewAllChannal": payload };
      case UNBLOCK_CHANNEL:
        return { ...gateway, "unblockChannel": payload };
      case VIEW_GWPR_FOR_GWTYPE:
          return { ...gateway, "viewGpforGwtype": payload };
      case VIEW_ALL_GW_SETTING_CODE:
        return { ...gateway, "viewAllSettingCode": payload };
      case GATEWAY_INITIAL_DATA:
        return { ...gateway, "gatewayInitialData": payload };
      case GATEWAY_TYPE_SUBMIT:
        return { ...gateway, "typeSubmit": payload };
      case VIEW_GATEWAY_PROVIDER_SETIINGS:
        return { ...gateway, "providerSettings": payload };
      default:
        return {...gateway};
    }
  };
  export default gatewayReducer;
