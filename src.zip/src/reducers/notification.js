import {
    VIEW_ALL_DOWNTIME_NOTIFICATION,
    VIEW_DOWNTIME_NOTIFICATION,
    DELETE_NOTIFICATION
} from "../actions/types";

const initialState = [];


export const notificationReducer = (notifiObj, action ) => {
    if(notifiObj === undefined){
        notifiObj= initialState;
    }
    const { type, payload } = action;
    switch(type) {
        case VIEW_ALL_DOWNTIME_NOTIFICATION:
          return { ...notifiObj, "viewAllDowntime": payload }
        case VIEW_DOWNTIME_NOTIFICATION:
            return { ...notifiObj, "viewDowntime": payload }
        case DELETE_NOTIFICATION:
            return { ...notifiObj, "deleteNotification": payload }
      default:
        return {...notifiObj};
    }
}

export default notificationReducer;