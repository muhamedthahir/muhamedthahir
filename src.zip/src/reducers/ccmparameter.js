import {
  VIEW_ALL_CCM_PARAMETER, VIEW_CCM_PARAMETER,
  ENABLE_CCM_PARAMETER, ADD_CCM_PARAMETER ,UPDATE_CCM_PARAMETER,
} from "../actions/types";

const initialState = [];

const ccmparameterReducer = (ccmparameter, action) => {
  if( ccmparameter === undefined) {
    ccmparameter = initialState;
  }
  const { type, payload } = action;

  switch (type) {

    case VIEW_CCM_PARAMETER:
      return { ...ccmparameter, "viewCcmParameter": payload } ;      
    case VIEW_ALL_CCM_PARAMETER:
      return {...ccmparameter,"viewAllCcmParameter": payload };
    case ENABLE_CCM_PARAMETER:
      return {...ccmparameter,"updateCcmParameter": payload };
    case ADD_CCM_PARAMETER:
      return {...ccmparameter,"addCcmParameter": payload };
      case UPDATE_CCM_PARAMETER:
      return {...ccmparameter,"updatePostCcmParameter": payload };
    default:
      return ccmparameter;
  }
};

export default ccmparameterReducer;