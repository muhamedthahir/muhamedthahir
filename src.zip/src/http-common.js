import axios from "axios";
import { loginRequest } from "./components/Login/authConfig";
import commonerror from "./actions/commonerror";
import store from "./store";

const getBaseURl = () => {
  return `${window._env_.REACT_APP_HOST}:${window._env_.REACT_APP_PORT}/${window._env_.REACT_APP_CONTEXT}`
}
let accounts;

let axiosDefiner, lastReqTime;
const isValidTime = (diffTime) => diffTime > 3000 || isNaN(diffTime)
const httpClient = async () => {
  let instance = store.getState().loginReducer.msalInstance?.instance
  accounts = instance?.getAllAccounts();
  if( axiosDefiner === undefined && instance ) {
    async function returnAxiosDefiner() {
      await instance?.acquireTokenSilent({
        ...loginRequest,
        account: accounts[0]
      }).then(resp => {
        axiosDefiner = axios.create({
          baseURL: getBaseURl(),
          headers: {
            "Authorization": `Bearer ${resp.accessToken}`,
            "ssoToken": resp.accessToken,
            "userId": accounts[0].localAccountId,
            "fromUI": true
          }
        })
        axiosDefiner.interceptors.request.use((config) => {
          config.headers['reqStartTime'] = new Date().getTime()
          return config
        })
        axiosDefiner.interceptors.response.use( 
          res => res,
          err => {
            if( err?.response?.status === 401 ) {
              let startTime =  err.response.config.headers.reqStartTime;
              let diffTime =  (lastReqTime - startTime);
              if( isValidTime(diffTime)) {
                instance.logoutRedirect({
                  postLogoutRedirectUri:"/"
                });
                lastReqTime =  startTime;
                window.alert(err.response.data); 
              }
            } else {
              commonerror(err)
            }
            throw err;
          }
        )
      })
      return axiosDefiner
    }
    axiosDefiner = await returnAxiosDefiner()
    return axiosDefiner
  } else {
    return axiosDefiner
  }
}

let testaxios
export const test = async () => {
  let instance = store.getState().loginReducer.msalInstance?.instance
  accounts = instance?.getAllAccounts();
  if( testaxios === undefined && instance ) {
    async function returnAxiosDefiner() {
      await instance?.acquireTokenSilent({
        ...loginRequest,
        account: accounts[0]
      }).then(resp => {
        testaxios = axios.create({
          baseURL: "http://localhost:50451/ccm-configuration-api",
          headers: {
            "Authorization": `Bearer ${resp.accessToken}`,
            "ssoToken": resp.accessToken,
            "userId": accounts[0] && accounts[0].localAccountId,
            // "fromUI": true
          }
        })
      })
      return testaxios
    }
    testaxios = await returnAxiosDefiner()
    return testaxios
  } else {
    return testaxios
  }
}



export default httpClient;
