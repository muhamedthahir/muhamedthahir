/* eslint-disable react-hooks/exhaustive-deps */
import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from "react-redux";
import {
    Card, Spinner, Image, Badge
} from 'react-bootstrap';
import backIcon from '../../assets/icons/backIcon.png'
import { useHistory } from 'react-router-dom';
import DataTable from '../Global/DataTable/DataTable';
import { retrieveAllNotifications } from '../../actions/notification';
import './styles/viewAllNotifications.scss';

const subjectDiv = (rowData, gotoNotificationsRecord, messageWidth) => {
    return (
        <div className="flex" onClick={() => gotoNotificationsRecord(rowData)} >
            <span className="subjec">{rowData.title} </span>
            -
            <div className="message" style={{ width: messageWidth + 'px' }}>{rowData.subject}</div>
        </div>
    )
}

function ViewAllNotifications(props) {
    const dispatch = useDispatch();
    const history = useHistory();
    let retrivedData = useSelector(state => state.notificationReducer);
    const [messageWidth, setMessageWidth] = useState()
    useEffect(() => {
        dispatch(retrieveAllNotifications());
    }, []);
    useEffect(() => {
        const width = document.getElementById("notifier") && document.getElementById("notifier").offsetWidth;
        const calmessageWidth = (45 / 100) * width;
        if (messageWidth !== calmessageWidth) {
            setMessageWidth(calmessageWidth)
        }
    })
    let dataToBeEdited = retrivedData.viewnotifications;
    let [localData = dataToBeEdited] = useState();
    let gotoNotificationsRecord = (rowData) => {
        history.push({ pathname: `/notifications/${rowData.title}` })
    };
    let columns = [
        {
            Header: 'From',
            accessor: 'from',
            selector: 'from',
            sortType: 'basic',
        },
        {
            Header: 'Subject',
            accessor: 'subject',
            sortType: 'basic',
        },
        {
            Header: 'Received On',
            accessor: 'receivedtime',
            sortType: 'basic',
        }
    ];
    const handleServerSidePagination = (pageNo, pageSize) => {
        dispatch(retrieveAllNotifications(`page=${pageNo}&size=${pageSize}`));
    };

    const localObj = localData && localData.notifications.map((ele) => {
        return {
            ...ele,
            subject: subjectDiv(ele, gotoNotificationsRecord, messageWidth),
            className: ele.isread ? "seer" : "boldRow seer"
        }
    });

    function goBack() {
        history.push("/");
    }
    return (
        <div className="notification_cls " id="notifier">
            <div className="headerBlock">
                <Image onClick={goBack} src={backIcon} className="icon" />
                <div>
                    <b>Notifications</b>  <Badge pill className="badge-color">{dataToBeEdited?.totalunread} unread</Badge>
                </div>
            </div>
            <div className="tableBlock">
                <Card>
                    <Card.Body>
                        <div className="dataBlock">
                            {
                                (localObj !== undefined)
                                    ? (
                                        <DataTable
                                            columns={columns}
                                            data={localObj || []}
                                            showPagination={true}
                                            handleServerSidePagination={handleServerSidePagination}
                                        //errorDiv={errorDiv}
                                        //pageProperty={{ totalPages, isPageChanged, movePage: (val) => movePage(val) }}
                                        />) : (
                                        <div className="alignCenter">
                                            <Spinner animation="border" />
                                        </div>
                                    )
                            }
                        </div>
                    </Card.Body>
                </Card>
            </div>

        </div>
    )
}
export default ViewAllNotifications;
