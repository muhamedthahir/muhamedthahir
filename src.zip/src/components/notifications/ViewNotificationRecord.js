/* eslint-disable react-hooks/exhaustive-deps */
import React, { useEffect } from 'react';
import { useDispatch, useSelector } from "react-redux";
import {
    Card, Image, Row, Col,
} from 'react-bootstrap';
import backIcon from '../../assets/icons/backIcon.png'
import { useHistory } from 'react-router-dom';
import BDOToast from '../../components/Global/BDOToast/BDOToast';
import { retrieveNotificationRecord } from '../../actions/notification';
import './styles/viewAllNotifications.scss';

function ViewNotificationRecord(props) {
    const dispatch = useDispatch();
    const history = useHistory();
    const { match: {params: { id }}  } = props;
    let retrivedData = useSelector(state => state.notificationReducer);

    useEffect(() => {
        dispatch(retrieveNotificationRecord(id));
    }, []);
    let dataToBeEdited = retrivedData.viewNotificationRecord || {};
    let errorDiv = undefined;
    if (dataToBeEdited?.errorResponse) {
        errorDiv = (
            <BDOToast
                openState={true}
                type={"warning"}
                bodyMessage={retrivedData?.errorResponse?.errorDescription}
            />
        )
    }

    function goBack() {
        history.push("/notifications");
    }
    return (
        <div className="notification_cls mt-2">
            <div className="headerBlock">
                <Image onClick={goBack} src={backIcon} className="icon" />
                <b>Notification</b>
            </div>
            {(!errorDiv) ?
                (
                    <Card className="cardbodystyle border-0">
                        <Card.Body >
                            <Row className="mt-2 mr-2 ml-2">
                                    <label className="boldRow">{dataToBeEdited.title}</label>
                            </Row>
                            <Row className="mt-2 mr-2 ml-2">
                                <Col xs="2" sm={2}>
                                    <label className="boldRow">Received time</label>
                                </Col>
                                <Col>
                                    <div className="">{dataToBeEdited.receivedtime}</div>
                                </Col>
                            </Row>
                            <Row className="mt-2 mb-2 mr-2 ml-2">
                                <Col xs="2" sm={2}>
                                    <label className="boldRow">From </label>
                                </Col>
                                <Col>
                                    <div className="">{dataToBeEdited.from}</div>
                                </Col>
                            </Row>
                            <hr/>
                            <Row className="mt-2 mr-2 ml-2">
                                <Col xs="12" sm={12}>
                                <div className="">{dataToBeEdited.subject}</div>
                                </Col>
                            </Row>

                        </Card.Body>
                    </Card>
                ) : (
                    errorDiv
                )}
        </div>
    )
}
export default ViewNotificationRecord;
