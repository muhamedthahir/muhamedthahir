import React from 'react';
import BDOButton from '../Global/Button/BDOButton';
import { Row, Col, Image } from 'react-bootstrap';
import logo from "../../assets/icons/logo-onblue.svg";
import './styles/LoginStyles.scss';

const LoginLayout = (props) => {
    const { handleLogin } = props;
    return (
        <div>
            <Row className="fullHeight">
                <Col sm={7} className="leftCol">
                    <div className='vertical-layout'>
                        <h4 className="boldContent">
                            <b>Centralized Communication Management</b>
                        </h4>
                        <b className="boldContent">Back Office Portal</b>
                        <div className="span-text">
                            <span>Allow BDO's internal operations users to maintain & manage configurations and settings of CCM platform essential for CCM daily operations</span>
                        </div>
                    </div>
                    <div className='bottomFixedLogin '>
                        <div className='navigators'>
                            <div className='name-primary'><a href={window._env_.FAQ_URL?window._env_.FAQ_URL:''} target="_blank" rel="noreferrer" ><b>FAQs</b></a></div>
                            <div className='name-primary'><a href={window._env_.USER_MANUAL_URL?window._env_.USER_MANUAL_URL:''} target="_blank" rel="noreferrer" ><b>User Manual</b></a></div>
                            <div className='name-primary'><a href='/announcement' target="_blank" ><b>Annoucements</b></a></div>
                            <div className='name-primary'><a href='/privacyPolicy' target="_blank" ><b>Privacy Policy</b></a></div>
                            <div className='name-primary'><a href='/tc' target="_blank" ><b>Terms and Conditions</b></a></div>
                        </div>
                    </div>
                </Col>
                <Col className="rightCol" >
                    <div className="centerDiv">
                        <div>
                            <Image src={logo} className="imageLogo" />
                        </div>
                        <div className="subTitle">
                            <span >Log in to CCM BOP</span>
                        </div>
                        <div className="btnLogin">
                            <BDOButton
                                onClick={() => handleLogin()}
                                title="Log in"
                                variant="secondary"
                            />
                        </div>
                    </div>
                </Col>
            </Row>
        </div>
    )
}


export default LoginLayout;