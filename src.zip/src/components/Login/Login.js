
import React, { useState } from "react";
import  { useDispatch, useSelector } from "react-redux";
import { loginRequest } from "./authConfig";
import { useMsal , useIsAuthenticated } from "@azure/msal-react"; 
import { EventType } from "@azure/msal-browser"; 
import LoginLayout from './LoginLayout'; 
import { updateMsalInstance, createUserSession, updateSsoToken } from '../../actions/login';
import BDOButton from '../Global/Button/BDOButton';

export const Login = (props) => {
    const dispatch = useDispatch();
    const retData = useSelector( state => state.loginReducer);
    const [ssoToken = retData?.msalInstance?.ssoToken,] = useState()
    const { instance } = useMsal();
    const isAuth = useIsAuthenticated()
    const handleLogin = () => {
        instance.loginRedirect(loginRequest).catch(e => {
            console.log(e);
        });
   }
   const handleLogout = () => {
        instance.logoutRedirect({
            postLogoutRedirectUri:"/"
        });
   }

    const accounts = instance.getAllAccounts();
    if (accounts.length > 0) { 
       instance.setActiveAccount(accounts[0]); 
    } 
    instance.addEventCallback((event) => { 
        let accessToken;
        if (event.eventType === EventType.LOGIN_SUCCESS && event.payload.account) {
            const account = event.payload.account;
            instance.setActiveAccount(account); 
            accessToken =  event.payload.accessToken;
            dispatch(createUserSession({
                ssoToken: accessToken,
                userId: account.localAccountId,
                action: 'login'
            }));
            dispatch(updateMsalInstance({ instance }));
            dispatch(updateSsoToken({ ssoToken }));
        }
        if (event.eventType === EventType.LOGOUT_SUCCESS) {
            dispatch(createUserSession({
                //ssoToken: ssoToken,
                userId:  accounts[0]?.localAccountId,
                action: 'logout'
            }));
        } 
    }, error=>{ 
        console.log('error', error); 
    }); 
    // handle auth redired/do all initial setup for 
    return (
       (!isAuth) ? (
            <>
                <LoginLayout handleLogin={handleLogin} />
            </>
       ): (
        <BDOButton onClick={() => handleLogout()}  title="Logout"  variant="primary" />
       )
    )
};

export default Login;
    