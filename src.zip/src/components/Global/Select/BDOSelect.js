import React from 'react';
import './Select.scss';
import Select from "react-select";


const BDOSelect = ( props ) => {
    const colourStyles = {
        option: (styles, { data, isDisabled, isFocused, isSelected }) => {
            return {
                ...styles,
                backgroundColor: isFocused ? "#E5F5FF" : null,
                color: "black"
            };
        }
    };
    const { options } = props;
    let value = options && options.find(ele => ele.value === props.value); 

    return( 
        <Select
            {...props}
            className={
                `selectDropDown ${props.className}`
            }
            value={value}
            styles={colourStyles}
        />
    )
}

export default BDOSelect;
