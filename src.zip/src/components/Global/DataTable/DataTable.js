import React, { useState } from 'react';
import { 
    useTable, useSortBy, usePagination,
} from 'react-table';
import { Image } from 'react-bootstrap';
import Pagination from './Pagination';
import NoSortIcon from '../../../assets/icons/sort.png'
import SortUpIcon from '../../../assets/icons/triangular-filled-up-arrow.png';
import SortDownIcon from '../../../assets/icons/down-filled-triangular-arrow.png';
import Empty from '../../../assets/icons/illustrationEmpty.svg';
import './Styles/DataTable.scss';

const showIcon = ( isSorted, isSortedDesc, disableSortBy) => {
    if( isSorted && isSortedDesc) {
        return ( <Image  src={SortDownIcon} className="bgDirty sort pl5" />)
    } else if( isSorted) {
        return ( <Image  src={SortUpIcon} className="bgDirty sort pl5" />)
    } else if( !disableSortBy) {
        return ( <Image  src={NoSortIcon} className="bgDirty nosort" />)
    }
    return '';
}
function Table(props) {
    const {
        columns, data, showPagination,
        handleServerSidePagination, totalPages, hiddenColumns,
        handlePagination, isPageChanged, movePage
    } = props;
  // Use the state and functions returned from useTable to build your UI
    let initialObj = {
        columns,
        data,
        initialState: { 
            pageIndex: props.pageIndex -1,
            pageSize:  props.pageSize,
            hiddenColumns: hiddenColumns,
        },
        autoResetSortBy : false,
        manualPagination:  false,
    }
    if( props.manualPagination === true){
        initialObj = {
            ...initialObj, pageCount: totalPages , manualPagination: true
        }
    }
    const {
        getTableProps,
        getTableBodyProps,
        headerGroups,
        prepareRow,
        page,
        canPreviousPage,
        canNextPage,
        pageCount,
        gotoPage,
        nextPage,
        previousPage,
        setPageSize,
        state: { pageIndex, pageSize },
    } = useTable(
        initialObj,
        useSortBy,
        usePagination,
    )    
    if( isPageChanged ) {
        movePage(false)    
        setTimeout(() => gotoPage(0), 0);  
    }
    return (
        <>
            <div className="datatable">
                <table className="table" {...getTableProps()}>
                    <thead className="thead">
                    {
                    headerGroups.map(headerGroup => (
                        <tr className="tRow" {...headerGroup.getHeaderGroupProps()}>
                        {headerGroup.headers.map(column => (
                            <th 
                                className={`th ${column.className}`}
                                {...column.getHeaderProps(column.getSortByToggleProps())}
                            >
                            {column.render('Header')}
                            <span>
                                {
                                 showIcon( column.isSorted, column.isSortedDesc, column.disableSortBy)
                                }
                            </span>
                            </th>
                        ))}
                        </tr>
                    ))}
                    </thead>
                    <tbody 
                        className="tbody" 
                        {...getTableBodyProps()}
                    >
                    {
                        page.map((row, i) => {
                            prepareRow(row)
                            return (
                            <tr 
                                className={`tRow ${row.allCells.find((ele) => ele.column.Header === 'className') && row.allCells.find((ele) => ele.column.Header === 'className').value}`} 
                                {...row.getRowProps()}>
                                {row.cells.map(cell => {
                                return (
                                    <td 
                                        className={`tData ${cell.column.Header}`} 
                                        {...cell.getCellProps()}
                                    >
                                        {cell.render('Cell')}
                                    </td>
                                )
                                })}
                            </tr>
                            )
                    })}
                    </tbody>
                </table>
                <Pagination 
                    showPagination={showPagination}
                    canPreviousPage={canPreviousPage}
                    canNextPage={canNextPage}
                    handleServerSidePagination={handleServerSidePagination}
                    handlePagination={handlePagination}
                    pageCount={pageCount}
                    gotoPage={gotoPage}
                    nextPage={nextPage}
                    previousPage={previousPage}
                    setPageSize={setPageSize}
                    pageIndex={pageIndex}
                    pageSize={pageSize}
                />
            </div>
        </>
    )
}

function DataTable({ 
        columns, data, showPagination, handleServerSidePagination,
        pageProperty ={}, hiddenColumns=[], defaultPageSize = 10,
        errorDiv, returnPageProperty
    }) {
    const  { totalPages }  = pageProperty;
    let tempPageIndex = pageProperty.pageNo?pageProperty.pageNo:1
    let tempPageSize = pageProperty.pageSize? pageProperty.pageSize: defaultPageSize
    const  [ pageSize=tempPageSize, setLocalPageSize ] = useState();
    const  [ pageIndex=tempPageIndex, setLocalPageIndex ] = useState();
    const handlePagination = ( pgIndex, pgSize ) => {
        setLocalPageSize( pgSize);
        if( returnPageProperty) {
            setLocalPageIndex( pgIndex+1);
            returnPageProperty( pgSize, pgIndex)
        } else {
            setLocalPageIndex( pgIndex);
        }
    }
    return (
        (data.length  === 0)
        ?(
            <div className="noRow">
                <Image src={Empty} />
                <div>{errorDiv || (<span>No data found</span>)}</div>
            </div>
        ) :(
            <Table 
                columns={[...columns, { Header: 'className', accessor: 'className'}]}
                data={data}
                showPagination={showPagination}
                handleServerSidePagination={handleServerSidePagination}
                pageIndex={pageIndex}
                pageSize={pageSize}
                totalPages={totalPages}
                hiddenColumns={[...hiddenColumns,'className']}
                manualPagination={handleServerSidePagination !== undefined}
                handlePagination={handlePagination}
                isPageChanged={pageProperty.isPageChanged}
                movePage={pageProperty.movePage}
            />
        )
    )
}

export default DataTable
