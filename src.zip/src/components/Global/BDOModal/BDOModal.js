import React from 'react';
import { Modal } from 'react-bootstrap';
import "./BDOModal.scss";

function BDOModal(props) {
    const { 
        header, body, footer, modalProps,
        openState
    } = props;
    return(
        <Modal show={openState} {...modalProps} >
            <Modal.Header closeButton>
                {header}
            </Modal.Header>
            <Modal.Body>
                {body}
            </Modal.Body>
            { 
                footer && (
                    <Modal.Footer className="footer">
                        {footer}
                    </Modal.Footer>
                )
            }
        </Modal>
    )
}

export default BDOModal;
