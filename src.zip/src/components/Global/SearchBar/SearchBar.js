import React from 'react';
import { 
    Form, Row, Image,
    Col,
} from 'react-bootstrap';
import InputText from '../Input/InputText';
import { Formik } from 'formik';
import BDOButton from '../Button/BDOButton'
import * as Yup from 'yup';
import './SearchBar.scss';
import searchIcon from '../../../assets/icons/icon-search.svg';

const getClassName = ( errors, touched ) => errors.selectedCategory && touched.selectedCategory?'select err-border': 'select'


const SearchBar =(props) => {
    
    const { categoryList=[], labelText, textPlaceHolder="Input Keyword", handleClick } = props;
    const categoryOption = (
        (categoryList.length > 0)
        ?( 
            <>
                <option key="Select category" value="">Select category</option>
                {categoryList.map((ele) => <option className="optioncls" key={ele.value} value={ele.value}>{ele.key}</option>)}
            </>
        )
        :''
    )
    let validationSchema = {        
        inputText: Yup.string().required('Required feild')
    }
    if( categoryList.length > 0 ) {
        validationSchema = { 
            ...validationSchema,
            selectedCategory: Yup.string().required('Required feild'),
        }
    }
    // const validationSchema = ;
    return(
        <Formik
            initialValues={{'selectedCategory':'', inputText: ''}}
            validationSchema={Yup.object().shape(validationSchema)}
            onSubmit={(values, actions) => {
                handleClick(values.selectedCategory, values.inputText)
            }}
        >
            {({ 
                errors, touched, values, handleSubmit, handleChange,
            }) => (
                <Form   
                    onSubmit={handleSubmit}
                >
                    <Row>
                        <Form.Group as={Col} sm={labelText? 2: 3}>
                            {(categoryOption) ? (
                                <Form.Control 
                                    as="select" 
                                    name="selectedCategory" 
                                    aria-label="Select Category" 
                                    value={values.selectedCategory} 
                                    onChange={handleChange}
                                    className={
                                        `selectDropDown ${getClassName(errors, touched)}`
                                    }
                                >
                                    {categoryOption}
                                </Form.Control>
                            ):''}
                            {
                                (labelText)?labelText:''
                            }
                            {
                                errors.selectedCategory && touched.selectedCategory
                                ? <span className="err-feild">{errors.selectedCategory}</span>:''
                            } 
                            
                        </Form.Group>
                        <Form.Group as={Col} sm={5} className="pl0">
                            <InputText  
                                name="inputText" 
                                value={values.inputText} 
                                placeholder={textPlaceHolder} 
                                onChange={handleChange}
                                className={
                                    errors.inputText && touched.inputText
                                    ?'input-text err-border': 'input-text '
                                }
                            />
                            {
                                errors.inputText && touched.inputText
                                ? <span className="err-feild">{errors.inputText}</span>: ''
                            }
                        </Form.Group>
                        <Form.Group as={Col} sm={1} className="pl0">
                            <BDOButton variant="primary" type="submit">
                                <Image src={searchIcon} alt="Search" />
                            </BDOButton>
                        </Form.Group>
                    </Row>
                </Form>
            )}
        </Formik>
    )
} 
 
export default SearchBar;
