import React from 'react';
import { 
    Form, Row, Button,Image,
    Col,
} from 'react-bootstrap';
import InputText from '../Input/InputText';
import { Formik } from 'formik';
import * as Yup from 'yup';
import './SearchBar.scss';
import BDOSelect from "../../Global/Select/BDOSelect";
import searchIcon from '../../../assets/icons/icon-search.svg';

const getClassName = ( errors, touched ) => errors.selectedCategory && touched.selectedCategory?'select err-border': 'select'


const SearchBar =(props) => {
    
    const { categoryList=[], labelText, textPlaceHolder="Input Keyword", handleClick } = props;
    let validationSchema = {        
        inputText: Yup.string().required('Required field')
    }
    if( categoryList.length > 0 ) {
        validationSchema = { 
            ...validationSchema,
            selectedCategory: Yup.string().required('Required field'),
        }
    }
    return(
        <Formik
            initialValues={{'selectedCategory':'', inputText: ''}}
            validationSchema={Yup.object().shape(validationSchema)}
            onSubmit={(values, actions) => {
                handleClick(values.selectedCategory, values.inputText)
            }}
        >
            {({ 
                errors, touched, values, handleSubmit, handleChange,
                setFieldError, setFieldValue
            }) => (
                <Form   
                    onSubmit={handleSubmit}
                >
                    <Row>
                         <Form.Group as={Col} sm={3}>
                            {!(categoryList === undefined || categoryList.length === 0 || labelText === '')
                             ?(
                                <BDOSelect
                                    placeholder={"Select Category"}
                                    options={categoryList}
                                    name="selectedCategory"
                                    className={
                                        `selectDropDown ${props.className} ${getClassName(errors, touched)}`
                                    }
                                    onChange={(e) => {
                                        setFieldValue('selectedCategory',e.value)
                                    }}
                                    value={values.selectedCategory}
                                />
                             ):''}
                            {
                                (labelText)?(
                                    <div className="pt6 fs14">{labelText}</div>
                                ):''
                            }
                            {
                                errors.selectedCategory && touched.selectedCategory
                                ? <span className="err-feild">{errors.selectedCategory}</span>:''
                            } 
                            
                        </Form.Group> 
                        
                        <Form.Group as={Col} sm={5} className="pl0">
                            <InputText  
                                name="inputText" 
                                value={values.inputText} 
                                placeholder={textPlaceHolder} 
                                onChange={handleChange}
                                className={
                                    errors.inputText && touched.inputText
                                    ?'input-text err-border': 'input-text '
                                }
                            />
                            {
                                errors.inputText && touched.inputText
                                ? <span className="err-feild">{errors.inputText}</span>: ''
                            }
                        </Form.Group>
                        <Form.Group as={Col} sm={1} className="pl0">
                            <Button variant="primary" type="submit">
                                <Image src={searchIcon} alt="Search" />
                            </Button>
                        </Form.Group>
                    </Row>
                </Form>
            )}
        </Formik>
    )
} 
 
export default SearchBar;
