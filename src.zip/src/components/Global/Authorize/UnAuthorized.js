import React from 'react';
import { Card, Image } from 'react-bootstrap';
import warningIcon from '../../../assets/icons/icon-surface-notifstatus-warning.svg';
import './styles/UnAuthorize.scss';

const UnAuthorized = (props) => {
    const moduleObj = {
        'GateSet': "Gateway settings",
        'CCMP': "CCM parameters",
        'Dashboard': "Dashboard",
        'Gatew': "Gateway",
        'BJS': "Batch Job Schedule",
        'Notif': "Notifications",
        'AdhocSend': "Adhoc Message", 
        'Announcement': "Announcement",
        'Logout': "Logout",
        'Login': "Login",
        'GatePro': "Gateway Provider",
        'CBL' : "Channel Information"
    }
    const { needLayout=true , module} = props;
    return(
        (needLayout) ?(
            <div className="unAuthorized">
                <Card>
                    <Card.Body>
                        <Image src={warningIcon} className={"iconCls"} />
                        <span>Unauthorized access for {moduleObj[module] || module}. Please contact admin.</span>
                    </Card.Body>
                </Card>
                
            </div>
        ):(
            <div className="unAuthorized">
                <Image src={warningIcon} className={"iconCls"} />
                <span>Unauthorized access for {moduleObj[module] ||  module}. Please contact admin.</span>
            </div>
        )
    )
}
export default UnAuthorized;
