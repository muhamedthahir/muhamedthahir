import React from 'react';
import UnAuthorized from './UnAuthorize';
import { useSelector } from 'react-redux';

const checkUserAuthorized = (type, module, authObj) => {
    const accessibleObj = authObj;
    const accessList = accessibleObj[(module)] ||[];
    if( module === "entitlements" || module === "Dashboard") {
        let obj = {};
        accessibleObj && Object.keys(accessibleObj).forEach(ele => {
            obj[ele] = true
            if(accessibleObj[ele].includes("Approver")) {
                obj["Approval"] =true;
            }
        })
        if(module ==="Dashboard" && Object.keys(obj).length === 0)
            return false
        return obj;
    } 
    if( module === "Approval") {
        let canAccess = false;
        accessibleObj && Object.keys(accessibleObj).forEach(ele => {
            if(accessibleObj[ele].includes("Approver")) {
                canAccess =  true;
            }
        })
        if( canAccess ) {
            return { canAccess }
        } else {
            return false
        }
    }
    if( accessList && accessList.includes(type) ) {
        let obj ={};
        accessList.forEach(ele => obj["can"+ele] = true); 
        // canApprover: true, canCreate: true, canDisable: true, canEnable: true, canUpdate: true, canViewList: true , canViewRecord: true
        // canViewList: true , canViewRecord: true
        // { canApprover, canCreate, canDisable, canEnable, canUpdate, canViewList, canViewRecord }
        return obj;
    }
    return false;
}
const AuthorizeComponent = ( props ) => {
    const { Component,  type, module, needLayout } = props;
    const retData = useSelector(state => state.loginReducer);
    const { authObj={} } = retData;
    const isUserAuthorized = checkUserAuthorized(type, module, authObj);
    return (
        (isUserAuthorized) ?
        ( 
            <Component {...isUserAuthorized} {...props} />
        ) : (
            <UnAuthorized needLayout={needLayout} module={module} />
        )
    )
}

export default AuthorizeComponent;
