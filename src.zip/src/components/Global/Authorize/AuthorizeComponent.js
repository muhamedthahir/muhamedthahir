import React from 'react';
import { roleMapObj } from './GlobalObj';

const checkUserAuthorized = (type, module) => {
    const user = "SuperUser";
    const accessibleObj = roleMapObj[(user)];
    const accessList = accessibleObj[(module)];
    if( module === "entitlements") {
        let obj = {};
        accessList.forEach(ele => {
            if(typeof ele === "object" ){
                let dummyObj ={};
                Object.values(ele)[0].forEach((data => dummyObj[(data)] = true));
                const key = Object.keys(ele)[0];
                obj[(key)] = dummyObj;
            } else {  
                obj[ele] = true;
            }
        })
        return obj;
    } 
    if( accessList && accessList.includes(type) ) {
        let obj ={};
        accessList.forEach(ele => obj["is"+ele] = true); // islist: true, isadd: true, isdelete :add
        return obj;
    }
    return false;
}
const AuthorizeComponent = ( props ) => {
    const { Component,  type, module } = props;
    const isUserAuthorized = checkUserAuthorized(type, module);
    return (
        (isUserAuthorized) ?
        ( 
            <Component {...isUserAuthorized} {...props} />
        ) : (
            <div>UnAuthorized. Please contact admin</div>
        )
    )
}

export default AuthorizeComponent;
