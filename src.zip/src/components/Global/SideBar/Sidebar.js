import React, { useState, useEffect } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import logo from "../../../assets/icons/logo-onblue.svg";
import dashboardIcon from "../../../assets/icons/icon-dashboard.svg";
import dashboardIconFill from "../../../assets/icons/filled_svg/icon-dashboard.svg"
import approvalIconWhite from "../../../assets/icons/icon-checkbox-outline.svg";
import approvalIcon from "../../../assets/icons/filled_svg/icone-checkbox-filled.svg";
import burgerIcon from "../../../assets/icons/icon-burger-white.svg";
import upIcon from '../../../assets/icons/filled_svg/icon-n-up.svg';
import upIconWhite from '../../../assets/icons/icon-up-white.svg';
import downIcon from '../../../assets/icons/filled_svg/icon-n-down.svg';
import downWhiteIcon from '../../../assets/icons/icon-n-down.svg';
import maintainenceIcon from "../../../assets/icons/filled_svg/icon-maintenance-filled.svg";
import maintainenceIconWhite from "../../../assets/icons/icon-maintenance-outline.svg";
import gatewayIconWhite from "../../../assets/icons/icon-gateway.svg";
import faqIcon from '../../../assets/icons/icon-faq.svg';
import faqIconFill from '../../../assets/icons/filled_svg/icon-faqs-filled.svg';
import gatewayIcon from "../../../assets/icons/filled_svg/icon-gateway-filled.svg";
import { Accordion, Card, Image } from 'react-bootstrap';
import HoverDiv from './HoverDiv';
import reportIcon from '../../../assets/icons/filled_svg/icon-reports-filled.svg';
import './Sidebar.scss';

const getDownIcon = (state) => {
  let src;
  if (state) {
    src = downIcon
  } else {
    src = downWhiteIcon;
  }
  return src;
}

const getUpIcon = (state) => {
  let src;
  if (state) {
    src = upIcon
  } else {
    src = upIconWhite;
  }
  return src;
}

function SideBar(props) {

  const {
    CBL, CCMP, Dashboard, FAQ,
    GatePro,Gatew, Approval,
    toggleClass, isActive, setActive
  } = props;

  const [pathname, setPathname] = useState('/');
  const [accordionState, setActiveState] = useState(false);
  const [ccmHoverDiv, setCcmHoverDiv] = useState(false);
  const [gwHoverDiv, setGwHoverDiv] = useState(false);
  const [accordionMaintainState, setMaintainState] = useState(false);
  const location = useLocation();
  useEffect(() => {
    setPathname(location.pathname);
  }, [location]);
  useEffect(() => {
    window.onresize = () => {
      if( window.innerWidth < 590 && isActive) {
        setActive(false)
      }
    }
  }, [])
  const gwCollapsed = pathname.includes("/gatewaymanagment") 
  const ccmCollapsed = pathname.includes("/ccmparameter")
  return (
    <div className={isActive ? 'sidebar' : 'sidebar resize'} >
      <div className="header-top">
        {isActive ? <a href="/"><Image alt="bdologo" src={logo} className="pointer" height="50" width="120" /> </a> : ""}
        {isActive ? <span className="bdo-title">CCM BOP</span> : ""}
        <Image src={burgerIcon} className="pointer" alt="burgerIcon" width="50" height="40" onClick={toggleClass} />
      </div>
      <ul>
        {
          Dashboard &&
          <li className="nav-item">
            <NavLink className="nav-link text-truncate" exact to="/">
              <Image src={pathname === "/" ? dashboardIconFill : dashboardIcon} className="iconCls" />
              <span className="d-none d-sm-inline">  Dashboard</span>
            </NavLink>
          </li>
        }
        {
          Approval &&
          <li className="nav-item">
            <NavLink className="nav-link text-truncate" exact to="/approvalPage">
              <Image src={pathname === "/approvalPage" ? approvalIcon : approvalIconWhite} className="iconCls"/>
              <span className="d-none d-sm-inline">  My Approvals</span></NavLink>
          </li>
        }
        {
          (Gatew || CBL || GatePro) ? (
            <Accordion
              className="accordionSide"
              onSelect={() => setActiveState(!accordionState)}
              onMouseOver={(e) => {
                e.preventDefault()
                if (!isActive) {
                  setGwHoverDiv(true)
                }
              }}
              onBlur={() => {
                if(gwHoverDiv) setGwHoverDiv(false)
              }}
            >
              {(!gwHoverDiv) ? (
                <>
                  <Accordion.Toggle as={Card.Header} eventKey="gateway">
                    <li className={
                      `nav-item text-truncate accTitle ${(gwCollapsed) ? 'activeBgColor' : ''}`
                    }>
                      <Image
                        src={gwCollapsed ? gatewayIcon : gatewayIconWhite}
                        className={"iconCls"}
                      />
                      <span className="d-none d-sm-inline"> Gateway Management </span>
                      <Image src={accordionState ? getUpIcon(gwCollapsed) : getDownIcon(gwCollapsed)} className="iconCls right" />
                    </li>
                  </Accordion.Toggle>
                  <Accordion.Collapse eventKey="gateway">
                    <>
                      {
                        Gatew &&
                        <li className="nav-item liAccordion"
                        >
                          <NavLink className="nav-link text-truncate" exact to="/gatewaymanagment">
                            <span className="d-none d-sm-inline">Manage Gateway</span>
                          </NavLink>
                        </li>
                      }
                      {
                        CBL &&
                        <li className="nav-item liAccordion"
                        >
                          <NavLink className="nav-link text-truncate" exact to="/gatewaymanagment/channels">
                            <span className="d-none d-sm-inline">View Channel Status</span>
                          </NavLink>
                        </li>
                      }
                      {
                        GatePro &&
                        <li className="nav-item liAccordion"
                        >
                          <NavLink className="nav-link text-truncate" exact to="/gatewaymanagment/providers">
                            <span className="d-none d-sm-inline">  Manage Providers</span>
                          </NavLink>
                        </li>
                      }
                    </>
                  </Accordion.Collapse>
                </>
              ) : (
                <li
                  className="hoverDiv nav-item"
                >
                  <HoverDiv
                    onMouseOut={() => {
                      setGwHoverDiv(false)
                    }}
                    className={"gwIcon"}
                    imgSrc={gatewayIcon}
                    imgWhiteSrc={gatewayIconWhite}
                    collapsed={gwCollapsed}
                    accordianState={accordionState}
                    name={"Gateway Management"}
                    eleList={[
                      { 'name': 'Manage Gateway', 'route': '/gatewaymanagment', className: '' },
                      { 'name': 'View channel status', 'route': '/gatewaymanagment/channels', className: '' },
                      { 'name': 'Manage Providers', 'route': '/gatewaymanagment/providers', className: '' }
                    ]}
                  />
                </li>
              )}
            </Accordion>
          ) : ''
        }
        {
          (CCMP) ? (
            <Accordion
              className="accordionSide"
              onMouseOver={(e) => {
                e.preventDefault()
                if (!isActive) {
                  setCcmHoverDiv(true)
                }
              }}
              onBlur={() => {
                setCcmHoverDiv(false)
              }}
              onSelect={() => setMaintainState(!accordionMaintainState)}
            >
              {(!ccmHoverDiv) ? (
                <>
                  <Accordion.Toggle as={Card.Header} eventKey="gateway">
                    <li className={
                      `nav-item accTitle text-truncate ${ccmCollapsed ? 'activeBgColor' : ''}`
                    }>
                      <Image
                        src={(ccmCollapsed) ? maintainenceIcon : maintainenceIconWhite}
                        className={"iconCls"}
                      />
                      <span className="d-none d-sm-inline"> Maintainence </span>
                      <Image src={accordionMaintainState ? getUpIcon(ccmCollapsed) : getDownIcon(ccmCollapsed)} className="iconCls right" />
                    </li>
                  </Accordion.Toggle>
                  <Accordion.Collapse eventKey="gateway">
                    <>
                      {
                        CCMP &&
                        <li className="nav-item liAccordion"
                        >
                          <NavLink className="nav-link text-truncate" exact to="/ccmparameter">
                            <span className="d-none d-sm-inline">Manage CCM Parameters</span>
                          </NavLink>
                        </li>
                      }
                    </>
                  </Accordion.Collapse>
                </>
              ) : (
                <li
                  className="hoverDiv nav-item"
                >
                  <HoverDiv
                    className={"ccmIcon"}
                    imgSrc={maintainenceIcon}
                    imgWhiteSrc={maintainenceIconWhite}
                    collapsed={ccmCollapsed}
                    accordianState={accordionMaintainState}
                    name={"Maintainence"}
                    eleList={[
                      { 'name': 'Manage CCM Parameter', 'route': '/ccmparameter', className: '' }
                    ]}
                  />
                </li>
              )}
            </Accordion>
          ) : ''
        }
        <div className="bottomFixed">
          <div className="reportLi">
            <a href={window._env_.USER_MANUAL_URL} target="_blank" className="pointer usermanual" rel="noreferrer">
              {(isActive) ? (
                <div className="reportDiv">
                  <Image className="text-truncate iconCls" src={reportIcon} />
                  <span>  User Manual</span>
                </div>
              ) : (
                <div className="reportDivTrun">
                  <Image className="text-truncate iconCls" src={reportIcon} />
                </div>
              )}
            </a>
          </div>
          {FAQ && 
            <li className="nav-item">
              <a href={window._env_.FAQ_URL} className="nav-link text-truncate" target="_blank" rel="noreferrer">
                <Image src={pathname === "/help" ? faqIconFill : faqIcon} className="iconCls" />
                <span className="d-none d-sm-inline">  Need help</span>
              </a>
            </li>
          }
        </div>
      </ul>
    </div>
  );
}

export default SideBar;