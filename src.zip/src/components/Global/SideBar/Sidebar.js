import React, { useState } from 'react';
import {Link} from 'react-router-dom';
import logo from "../../../assets/icons/logo-onblue.svg";
import dashboardIcon from "../../../assets/icons/icon-dashboard.svg";
import approvalIcon from "../../../assets/icons/icon-checkbox-outline.svg";
import burgerIcon from "../../../assets/icons/icon-burger-white.svg";
import accessIcon from "../../../assets/icons/icon-access.svg";
import maintainenceIcon from "../../../assets/icons/icon-maintenance-outline.svg";
import gatewayIcon from "../../../assets/icons/icon-gateway.svg";


import './Sidebar.scss';


function SideBar(props) {

    const { 
      accessManagement, gatewayManagement, maintainence, 
      reports, approval, adHocMessaging,toggleClass,isActive
    } = props;

    return (
    <div  className={isActive ? 'sidebar': 'sidebar resize'} >
      <div className="header-top">
        {isActive ? <a href="/"><img alt="bdologo" src={logo} width="120" height="60"/> </a>:""}
        {isActive ? <span className="bdo-title">CCM BDO</span>:""}
        <img src={burgerIcon} alt="burgerIcon" width="50" height="50" onClick={toggleClass} />
      </div>
      <ul>
        { 
          <li className="nav-item">
              <a className="nav-link text-truncate" href="/"><img src={dashboardIcon} className="iconCls"></img> <span className="d-none d-sm-inline">Dashboard</span></a>
          </li>
        }  
        {
          approval &&  <li className="nav-item">
            <Link className="nav-link text-truncate"  to ="/approvalPage"><img src={approvalIcon} className="iconCls"></img>  <span className="d-none d-sm-inline">My Approvals</span></Link>
          </li>
        }
        {
          gatewayManagement.manageGateway &&
          <li className="nav-item">
            <Link className="nav-link text-truncate"  to ="/gatewaymanagment"><img src={gatewayIcon} className="iconCls"></img>  <span className="d-none d-sm-inline">Manage Gateway</span></Link>
          </li>
        }
        {
          gatewayManagement.viewChannelStatus &&
          <li className="nav-item">
              <Link className="nav-link text-truncate"  to ="/gatewaymanagment/channels"><img src={maintainenceIcon} className="iconCls"></img>  <span className="d-none d-sm-inline">View channel status</span></Link>
          </li>
        }
        {
            maintainence.manageCCM &&
            <li className="nav-item">
              <Link  className="nav-link text-truncate" to ="/ccmparameter"><img src={maintainenceIcon} className="iconCls"></img>  <span className="d-none d-sm-inline"> Manage CCM Parameter</span></Link>
            </li>
          }
          {
            maintainence.manageCCM &&
            <li className="nav-item">
              <Link  className="nav-link text-truncate" to ="/gatewayprovider"><img src={maintainenceIcon} className="iconCls"></img>  <span className="d-none d-sm-inline"> Manage Provider</span></Link>
            </li>
          }
          {
            maintainence.manageCCM &&
            <li className="nav-item">
              <Link  className="nav-link text-truncate" to ="/notification/downtime"><img src={maintainenceIcon} className="iconCls"></img>  <span className="d-none d-sm-inline"> Schedule Downtime</span></Link>
            </li>
          }
      </ul>
    </div>
  );
}

export default SideBar;