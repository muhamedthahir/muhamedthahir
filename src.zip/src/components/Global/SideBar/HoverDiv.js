import React, { useState } from 'react';
import './Sidebar.scss';
import { NavDropdown } from 'react-bootstrap';
import { NavLink } from 'react-router-dom';
import upIcon from '../../../assets/icons/filled_svg/icon-n-up.svg';
import upIconWhite from '../../../assets/icons/icon-up-white.svg';
import downIcon from '../../../assets/icons/filled_svg/icon-n-down.svg';
import downWhiteIcon from '../../../assets/icons/icon-n-down.svg';


const getDownIcon = (state) => {
  let src;
  if (state) {
    src = downIcon
  } else {
    src = downWhiteIcon;
  }
  return src;
}

const getUpIcon = (state) => {
  let src;
  if (state) {
    src = upIcon
  } else {
    src = upIconWhite;
  }
  return src;
}
const HoverDiv = (props) => {
  const {
    eleList, name, imgWhiteSrc,
  } = props;
  const [arrowIcon, setArrowIcon] = useState(false)
  return (
    <NavDropdown
      title={
        <div
          className={"bgColour"} 
          onClick={() => setArrowIcon(!arrowIcon)}
        >
          <img src={imgWhiteSrc} alt="whiteIcon" className="iconCls mr5" />
          <span
            className="white"
          >
            {name}
            <img alt="arrowIcon" src={arrowIcon ? getUpIcon(false) : getDownIcon(false)} className="iconCls" />
          </span>
        </div>
      }
      id={props.name}
      className={`menu ${props.className}`}
    >
      {
        eleList.map(ele => {
          return (
            <NavDropdown.Item>
              <li className="nav-item">
                <NavLink className="nav-link" to={ele.route}>
                  <span className="d-none d-sm-inline">{ele.name}</span>
                </NavLink>
              </li>
            </NavDropdown.Item >
          )
        })
      }
    </NavDropdown>
  )
}

export default HoverDiv;
