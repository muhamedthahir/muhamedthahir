import React from 'react';
import { Modal } from 'react-bootstrap';
import BDOButton from '../Global/Button/BDOButton'
import "./ConfirmationModal.scss";
const renderContent = ( ele) => {
    let returnEle = ele;
    if( "boolean" === typeof ele )  returnEle = ele?.toString()
    else if( Array.isArray(ele)) returnEle =ele.join(",")
    return(
        returnEle
    )
}
function ConfirmationModal(props) {
    const {
        headerText,  bodyContent, contentObj=[], confirmHandler,
        cancelHandler, openState, skipValue =[], modalSize="md",
        descriptionWidth = 80
    } = props
    const actualObj = Object.keys(contentObj).filter(ele => !skipValue.includes(ele)) 
    const boldWidth = 95 - descriptionWidth
    return(
        <Modal show={openState} onHide={cancelHandler} size={modalSize}>
            <Modal.Header closeButton>
                {headerText}
            </Modal.Header>
            <Modal.Body>
                <div className="modalBdyContent">
                    {bodyContent}
                </div>
                <div className="alignLeft">
                    {actualObj.length > 0 && actualObj.map((ele) => (
                        <div className="mb5 flexBox">
                            <b style={{width: `${boldWidth}%`}}>{ele[0].toUpperCase() + ele.substring(1)} </b>
                            <span className="mr5" >:</span>
                            <span className="ml5 content" style={{width: `${descriptionWidth}%`}}>  
                                {
                                    (
                                        contentObj[ele] !== undefined 
                                            ? renderContent( contentObj[ele])
                                            : '-'
                                    )
                                }
                            </span>
                        </div>
                    ))}
                </div>
            </Modal.Body>
            <Modal.Footer className="footer">
                <BDOButton variant="secondary" onClick={() => cancelHandler()}>Cancel</BDOButton>
                <BDOButton variant="primary" onClick={() => confirmHandler()}>Confirm</BDOButton>
            </Modal.Footer>
                
        </Modal>
    )
}

export default ConfirmationModal;
