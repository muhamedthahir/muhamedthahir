/* eslint-disable react-hooks/exhaustive-deps */
import React, { useState, useEffect, useRef } from "react";
import {
  Navbar,
  NavDropdown,
  Form,
  Image,
  ListGroup,
  Overlay, Row, Badge, Col,
  Popover
} from "react-bootstrap";
import { useMsal } from "@azure/msal-react";
import { useHistory } from 'react-router-dom';
import { useDispatch, useSelector } from "react-redux";
import logowhite from "../../../assets/icons/logo-onwhite.svg";
import notification from "../../../assets/icons/icon-notification-outline.svg";
import logoutIcon from "../../../assets/icons/icon-upload-outline.svg";
import { retrieveAllNotifications } from '../../../actions/notification';
import './Header.scss';

let dataToBeEdited = {}
function Header(props) {
  const { instance } = useMsal();
  const history = useHistory();
  const { isActive } = props;
  const [show, setShow] = useState(false);
  const target = useRef(null);

  const dispatch = useDispatch();
  let retrivedData = useSelector(state => state.notificationReducer);
  const accounts = instance.getAllAccounts();
  useEffect(() => {
    dispatch(retrieveAllNotifications());
  }, []);
  dataToBeEdited = retrivedData.viewnotifications || {};

  const handleLogout = () => {
    instance.logoutRedirect({
      postLogoutRedirectUri: "/"
    });
  }

  let gotoNotifications = () => {
    history.push({ pathname: '/notifications' })
    setShow(!show)
  };
  let gotoNotificationsRecord = (rowData) => {
    history.push({ pathname: `/notifications/${rowData.title}` })
    setShow(!show)
  };
  const popoverFunction = (<Popover id="popover-basic" className="popoverMain">
    <Popover.Title>
      <Row className="ml-1">
        <Col xs='9' sm='9' >
          <strong >Notifications</strong> {dataToBeEdited && dataToBeEdited.totalunread && dataToBeEdited.totalunread !== "" && dataToBeEdited.totalunread !== 0 &&  <Badge pill className="badge-color">{dataToBeEdited?.totalunread} unread</Badge>}
        </Col>
        <Col xs='3' sm='3'>
          <div className="seeAll" onClick={gotoNotifications}>See all</div>
        </Col>
      </Row>
    </Popover.Title>
    <Popover.Content className="content">

      {dataToBeEdited &&
        dataToBeEdited.notifications ? (dataToBeEdited.notifications.map((ele) => {
          return (
            <>
              <ListGroup.Item onClick={() => gotoNotificationsRecord(ele)} className={ele.isread === false ? "listgroupItemCls seer read" : "listgroupItemCls seer"}>
                {ele.title}

                <div className="listItemCls">
                  {ele.receivedtime}
                </div>
              </ListGroup.Item>
            </>
          );
        }) ):(
          <>
          <ListGroup.Item  className={"listgroupItemNoNotificationCls"}>
            Sorry. No Notifications. 
          </ListGroup.Item>
        </>
        )
      }
    </Popover.Content>
  </Popover>);
  return (
    <Navbar
      bg="white"
      variant="white"
      expand="lg"
      sticky="top"
      className="d-flex flex-nowrap justify-content-between px-2 py-1 nameHeader"
    >
      <div>
        <Form inline>
          {isActive ? (
            ""
          ) : (
            <Navbar.Brand className="m-0 px-2 py-0">
              <img
                alt="bdo-logo"
                src={logowhite}
                width="69"
                height="24"
              />
            </Navbar.Brand>
          )}
          {/* <div className="SearchTextCls">
            <span className="searchIcon"><img alt="search" src={searchIcon} width="16" height="16" /></span>
            <input type="text" class="form-control" placeholder="Search transaction, message, group, user..." />

          </div> */}
        </Form>
      </div>
      <div className="d-inline-flex">
        <Navbar.Brand className="m-0 px-2 py-0">

          <div className="notification-icon">
            <div 
               // ref={target} onClick={() => setShow(!show)}
               style={{position:"relative"}}
            >
              <img
                src={notification}
                width="24"
                alt="bell"
                height="24"
              />
              {dataToBeEdited && dataToBeEdited.totalunread && dataToBeEdited.totalunread !== "" && dataToBeEdited.totalunread !== 0 && <span className="badge-icon123">{dataToBeEdited?.totalunread}</span>}
            </div>
            <Overlay target={target.current} show={show} placement="bottom"
              containerPadding={140} rootCloseEvent="click" rootClose onHide={() => setShow(false)}
            >
              {popoverFunction}

            </Overlay>
          </div>

        </Navbar.Brand>
        <NavDropdown
          title={accounts && accounts[0]?.name}
          id="navbarScrollingDropdown"
          className="menu"
        >
          <div className="listItemNav">
            <div onClick={() => handleLogout()} className="logout">
              <Image src={logoutIcon} className="iconCls rotate90" />
              <span>Log out</span>
            </div>
          </div>
        </NavDropdown>
      </div>
    </Navbar>
  );
}

export default Header;
