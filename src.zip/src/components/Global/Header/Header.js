import {
  Navbar,
  NavDropdown,
  Form,
} from "react-bootstrap";
import logowhite from "../../../assets/icons/logo-onwhite.svg";
import notification from "../../../assets/icons/icon-notification-outline.svg";
import searchIcon from "../../../assets/icons/icon-search-header.svg";
import './Header.scss';


function Header(props) {
  const { isActive } = props;
  return (
    <Navbar
      bg="white"
      variant="white"
      expand="lg"
      sticky="top"
      className="d-flex flex-nowrap justify-content-between px-2 py-1"
    >
      <div>
      <Form inline>
        {isActive ? (
          ""
        ) : (
          <Navbar.Brand className="m-0 px-2 py-0">
            <img
              alt="bdo-logo"
              src={logowhite}
              width="69"
              height="24"
            />
          </Navbar.Brand>
        )}
        <div className="SearchTextCls">
        <span  className="searchIcon"><img alt="search" src={searchIcon} width="16" height="16"/></span>
        <input type="text" class="form-control" placeholder="Search transaction, message,group,user..."/>

          </div>
      </Form>
      </div>
      <div className="d-inline-flex">
      <Navbar.Brand className="m-0 px-2 py-0">
            <img
              alt="notification"
              src={notification}
              width="24"
              height="24"
            />
          </Navbar.Brand>
      <NavDropdown
        title="Dela Cruz,Juan"
        id="navbarScrollingDropdown"
        className="menu"
      >
        <NavDropdown.Item href="#action3">Action</NavDropdown.Item>
        <NavDropdown.Item href="#action4">Another action</NavDropdown.Item>
        <NavDropdown.Divider />
        <NavDropdown.Item href="#action5">Something else here</NavDropdown.Item>
      </NavDropdown>
      </div>
    </Navbar>
  );
}

export default Header;
