import { CKEditor } from 'ckeditor4-react';

const BDOCkeditor = (props) => {
    return(
        <CKEditor {...props} className={`ckeditor ${props.className}`} ref={props.innerRef} />
    )
}

export default BDOCkeditor;
