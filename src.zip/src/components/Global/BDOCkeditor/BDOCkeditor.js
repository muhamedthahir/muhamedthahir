import { CKEditor } from 'ckeditor4-react';

const BDOCkeditor = (props) => {
    return(
        <>
            <CKEditor 
                {...props}
                className={`ckeditor ${props.className}`}
                editorUrl={'http://localhost:3000/ckeditor/ckeditor.js'}
            />
        </>
    )
}

export default BDOCkeditor;
