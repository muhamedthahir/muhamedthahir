import React from 'react';
import { Toast, Image } from 'react-bootstrap';
import CloseIcon from '../../../assets/icons/icon-n-close.svg';
import TickIcon from '../../../assets/icons/icon-surface-notifstatus-success.svg';
import WarningIcon from '../../../assets/icons/icon-surface-notifstatus-warning.svg';
import CriticalIcon from '../../../assets/icons/error.svg';
import './BDOToast.scss';

const BDOToast = (props) => {
    const { 
        header, bodyMessage, openState, onClose,
        toastProps, headerProps, type
    } = props;
    const imgSrcObj = { success: TickIcon, warning: WarningIcon, critical: CriticalIcon  }
    return(
        <div className="bdoToast">
            <Toast 
                show={openState} 
                onClose={onClose} 
                {...toastProps} 
                className={`${toastProps &&toastProps.className} ${type}`}
            >
                {
                    header && (
                        <Toast.Header {...headerProps} >
                            {header}
                        </Toast.Header>
                    )
                }
                <Toast.Body >
                    <div className='flex'>
                        <Image src={imgSrcObj[(type)]} className="icon"/>
                        <div className='mainbody'> {bodyMessage} </div>
                    </div>
                    <Image className="closeIcon" src={CloseIcon} onClick={onClose} />
                </Toast.Body>
            </Toast>
        </div>
    )
}
export default BDOToast;
