/* eslint-disable react-hooks/exhaustive-deps */
import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import BDOModal from '../Global/BDOModal/BDOModal';
import {
    Button,Spinner
} from 'react-bootstrap';
import DataTable from '../Global/DataTable/DataTable';
import { sortByElement } from '../../utils/DataTableUtil';
import { retrieveAllApprovedList, retrieveAllRejectedList } from '../../actions/approval';
import './styles/AprovalHome.scss';
import Moment from 'moment';

const formatDate = ( date ) => {
    let returnDate = '0000/00/00';
    if (date) returnDate = Moment(date).format('MM/DD/YYYY');
    return returnDate;
}

function ApprovedList(props) {
    const { name  } = props;
    const dispatch = useDispatch();
    const retData = useSelector(state => state.approvalReducer);
    const { viewAllApproved = {}, viewAllRejected = {}} = retData;
    const [ openState, toggleModal ] = useState(false);
    const [ modalData, setModalData ] = useState({});
    let errorDiv = '', approvedList, totalPages = 1, rejectedList, errorResponse;
    if( name === "approved") {
        errorResponse = viewAllApproved.errorResponse;
        if( errorResponse) {
            errorDiv = (
                <span>{errorResponse.ccmErrorCode} - {errorResponse.errorDescription}</span>
            )
        }
        totalPages = viewAllApproved.totalPages;
        approvedList = viewAllApproved.pendingList
    } else if( name === "rejected") {
        errorResponse = viewAllRejected.errorResponse;
        if( errorResponse) {
            errorDiv = (
                <span>{errorResponse.ccmErrorCode} - {errorResponse.errorDescription}</span>
            )
        }
        totalPages = viewAllRejected.totalPages;
        rejectedList = viewAllRejected.pendingList
    }
   
    useEffect(() => {
        if( name === "approved") dispatch(retrieveAllApprovedList(`/APPROVED?pageSize=${10}&pageNumber=${1}`))
        else if( name === "rejected") dispatch(retrieveAllRejectedList(`/REJECTED?pageSize=${10}&pageNumber=${1}`))
    }, [])

    let [ localData=(approvedList || rejectedList)] = useState();

    const columns = [
        {
            Header: 'Reference Number',
            accessor: 'refId',
            sortType: 'basic',
        },
        {
            Header: 'Date',
            accessor: 'date',
            selector: 'date',
            sortType: 'basic',
        },
        {
            Header: 'Module',
            accessor: 'module',
            sortType: 'basic',
        },
        {
            Header: 'Request Type',
            accessor: 'request',
            sortType:( rowA, rowB, colId, desc ) => {
                return sortByElement(rowA, rowB, colId, desc)
            }
        },
        {
            Header: 'Requestor ID',
            accessor: 'reqDomainId',
            sortType: 'basic',
        },
        {
            Header: 'Reason',
            accessor: 'reason',
            sortType: 'basic',
        }
    ];
    const handleServerSidePagination = ( pageNo, pageSize ) => {
        if( name === "approved") dispatch(retrieveAllApprovedList(`/APPROVED?pageSize=${pageSize}&pageNumber=${pageNo}`))
        else if( name === "rejected") dispatch(retrieveAllRejectedList(`/REJECTED?pageSize=${pageSize}&pageNumber=${pageNo}`))
    }
    const openModal = ( rData) => {
        toggleModal(true)
        setModalData(rData)
    }
    const linkDiv = (rowData) => {
        return(
            <div className="linkDiv" onClick={() => openModal(rowData)}>{rowData.requestType}</div>
        )
    }

    const localObj = localData && localData.map((ele) => {
        return {
            ...ele,
            request: linkDiv(ele),
            date: formatDate(ele.date)
        }
    });
    const closeModal = () => { toggleModal(false); setModalData({})}
    const modalFooterContent = (
        <>
            <Button
                variant="secondary" 
                onClick={() => {
                   closeModal()
                }}>
                Cancel
            </Button>
        </>
    )
    return(
        <div className="pending-list">
            <div className="dataBlock">
                {
                    (localObj !== undefined || errorResponse)
                    ?  (
                    <DataTable 
                        columns={columns}
                        data={localObj || []}
                        showPagination={true}
                        handleServerSidePagination={handleServerSidePagination}
                        pageProperty={{ totalPages}}
                        errorDiv={errorDiv}
                    />):(
                        <div className="alignCenter">
                            <Spinner animation="border" />
                        </div>
                    )
                }
            </div>
            {
                openState && (
                    <BDOModal 
                        header={"Request Details"}
                        body={
                           <div className="reqModalBody">
                               <div><b>Status</b> : <label>{modalData.status}</label></div>
                               <div><b>Date Requested</b> : <label>{modalData.date}</label></div>
                               <div><b>Requestor Domain ID</b> : <label>{modalData.reqDomainId}</label></div>
                               <div><b>Approver ID</b> : <label>{modalData.approverId}</label></div>
                               <div><b>Request Type</b> : <label>{modalData.requestType}</label></div>
                               <div><b>Reason</b> : <label>{modalData.reason}</label></div>
                               <div><b>Module</b> : <label>{modalData.module}</label></div>
                               <div><b>Reference ID</b> : <label>{modalData.refId}</label></div>
                               <div className={`changeFeild ${modalData.fieldList.length ===1? 'justifyCenter':''}`}>
                               {
                                   modalData.fieldList.map((ele) => (
                                       <div className="feildDiv">
                                            <div><b>Field Code</b> : <label>{ele.fieldCode}</label></div>
                                            <div><b>Field Name</b> : <label>{ele.fieldName}</label></div>
                                            <div><b>Old Value</b> : <label>{ele.oldValue}</label></div>
                                            <div><b>New Value</b> : <label>{ele.newValue}</label></div>
                                            <div><b>Affected Table</b> : <label>{ele.affectedTable}</label></div>
                                        </div>
                                   ))
                               }
                               </div>
                            </div>
                        }
                        footer={modalFooterContent}
                        openState={openState}
                        modalProps={{onHide: closeModal }}
                    />
                )
            }
        </div>
    )

}

export default ApprovedList;
