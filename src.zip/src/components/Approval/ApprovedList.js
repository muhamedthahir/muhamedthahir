/* eslint-disable react-hooks/exhaustive-deps */
import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import BDOModal from '../Global/BDOModal/BDOModal';
import {
    Spinner
} from 'react-bootstrap';
import BDOButton from '../Global/Button/BDOButton'
import DataTable from '../Global/DataTable/DataTable';
import { retrieveAllApprovedList } from '../../actions/approval';
import './styles/AprovalHome.scss';

const alphaNumericSorting = (frstValue, scndValue, colId, desc = false) => {
  if (frstValue && scndValue) {
    if (!desc) return frstValue.localeCompare(scndValue);
    return -1 * scndValue.localeCompare(frstValue);
  }
};

const sortByElement = ( rowA, rowB, colId, desc) => {
    const findFn = ( entry ) => entry.column && (entry.column.id ===  colId)
    const foundAData = rowA.cells.find(findFn);
    const foundBData = rowB.cells.find(findFn);
    const aValue =  typeof rowA.cells[0] !== "function" && foundAData && foundAData.value.props.children;
    const bValue =  typeof rowB.cells[0] !== "function" && foundBData && foundBData.value.props.children;
    return alphaNumericSorting( aValue, bValue, colId, desc)
}

function ApprovedList(props) {
    const dispatch = useDispatch();
    const retData = useSelector(state => state.approvalReducer);
    const { viewAllApproved = {}} = retData;
    const [ openState, toggleModal ] = useState(false);
    const [ modalData, setModalData ] = useState({});
    const { data={}, errorResponse } = viewAllApproved;
    const { approvedList, totalPages = 1} = data;
    let errorDiv = ''
    if( errorResponse) {
        errorDiv = (
            <span>{errorResponse.errorDescription}</span>
        )
    }
    useEffect(() => {
        dispatch(retrieveAllApprovedList(`pageSize${10}&pageNo${1}`))
    }, [])
    let [ localData=approvedList] = useState();

    const columns = [
        {
            Header: 'Date',
            accessor: 'date',
            selector: 'date',
            sortType: 'basic',
        },
        {
            Header: 'Request Type',
            accessor: 'request',
            sortType:( rowA, rowB, colId, desc ) => {
                return sortByElement(rowA, rowB, colId, desc)
            }
        },
        {
            Header: 'Reference Number',
            accessor: 'refId',
            sortType: 'basic',
        },
        {
            Header: 'Requestor Id',
            accessor: 'reqDomainId',
            sortType: 'basic',
        },
        {
            Header: 'Module',
            accessor: 'module',
            sortType: 'basic',
        },
        {
            Header: 'Reason',
            accessor: 'reason',
            sortType: 'basic',
        }
    ];
    const handleServerSidePagination = ( pageNo, pageSize ) => {
        dispatch(retrieveAllApprovedList(`pageSize${pageSize}&pageNo${pageNo}`))
    }
    const openModal = ( rData) => {
        toggleModal(true)
        setModalData(rData)
    }
    const linkDiv = (rowData) => {
        return(
            <div className="linkDiv" onClick={() => openModal(rowData)}>{rowData.requestType}</div>
        )
    }

    const localObj = localData && localData.map((ele) => {
        return { 
            ...ele,
            request: linkDiv(ele),
        }
    });
    const closeModal = () => { toggleModal(false); setModalData({})}
    const modalFooterContent = (
        <>
            <BDOButton
                variant="secondary" 
                onClick={() => {
                   closeModal()
                }}>
                Cancel
            </BDOButton>
        </>
    )
    return(
        <div className="pending-list">
            <div className="dataBlock">
                {
                    localObj !== undefined
                    ?  (
                    <DataTable 
                        columns={columns}
                        data={localObj}
                        showPagination={true}
                        // handleServerSidePagination={handleServerSidePagination}
                        pageProperty={{ totalPages}}
                        errorDiv={errorDiv}
                    />):(
                        <div className="alignCenter">
                            <Spinner animation="border" />
                        </div>
                    )
                }
            </div>
            {
                openState && (
                    <BDOModal 
                        header={"Request Details"}
                        body={
                           <div className="reqModalBody">
                               <div><b>Status</b> : <label>{modalData.status}</label></div>
                               <div><b>Request Id</b> : <label>{modalData.requestId}</label></div>
                               <div><b>Date Requested</b> : <label>{modalData.date}</label></div>
                               <div><b>Requestor Domain Id</b> : <label>{modalData.reqDomainId}</label></div>
                               <div><b>Request Type</b> : <label>{modalData.requestType}</label></div>
                               <div><b>Reason</b> : <label>{modalData.reason}</label></div>
                               <div><b>Module</b> : <label>{modalData.module}</label></div>
                               <div><b>ID/Code</b> : <label>{modalData.refId}</label></div>
                            </div>
                        }
                        footer={modalFooterContent}
                        openState={openState}
                        modalProps={{onHide: closeModal }}
                    />
                )
            }
        </div>
    )

}

export default ApprovedList;
