/* eslint-disable react-hooks/exhaustive-deps */
import React, { useEffect, useState, useRef } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import BDOModal from '../Global/BDOModal/BDOModal';
import {
    Button,Spinner
} from 'react-bootstrap';
import ApprovalModal from './ApprovalModal';
import DataTable from '../Global/DataTable/DataTable';
import Switch from '../Global/Switch/Switch';
import { sortByElement } from '../../utils/DataTableUtil';
import { 
    retrieveAllPendingList, retrieveAllRejectedList,
    retrieveAllApprovedList,updateApprovalStatus
 } from '../../actions/approval';
import Moment from 'moment';
import './styles/AprovalHome.scss';


const ModalFooterContent = ({
        reqModalState, openState, regModalData, clickHandler,
        closeModal, closeReqModal
    }) => (
    <>
        { ((reqModalState && regModalData.type === "Approve") || openState) && (
            <Button 
                variant="primary" 
                className="mr8" 
                onClick={() => clickHandler("Approve")}
            > Approve
            </Button>
        )}
        { ((reqModalState && regModalData.type === "Reject") || openState) && (
            <Button 
                variant="danger" 
                className="mr8" 
                onClick={() => clickHandler("Reject")}
            > Reject
            </Button>
        )}
        <Button
            variant="secondary" 
            onClick={() => {
                if( openState) closeModal()
                if( reqModalState) closeReqModal()
            }}>
            Cancel
        </Button>
</>
)

const formatDate = ( date ) => {
    let returnDate = '0000/00/00';
    if (date) returnDate = Moment(date).format('MM/DD/YYYY');
    return returnDate;
}

function PendingList(props) {
    const  { setToastState, setToastData } = props;
    const dispatch = useDispatch();
    const formikRef = useRef();
    const retData = useSelector(state => state.approvalReducer);
    const { viewAllPending = {}} = retData;
    const [ openState, toggleModal ] = useState(false);
    const [ reqModalState, setReqModalState ] = useState(false);
    const [ modalData, setModalData ] = useState({});
    const [ regModalData, setReqModalData ] = useState({});
    const { 
        pendingList, totalPages = 1, pageNo = 1, pageSize =10,
        errorResponse
    } = viewAllPending;
    let errorDiv = ''
    if( errorResponse) {
        errorDiv = (
            <span>{errorResponse.ccmErrorCode} - {errorResponse.errorDescription}</span>
        )
    }
    useEffect(() => {
        dispatch(retrieveAllPendingList(`/SUBMITTED?pageSize=${10}&pageNumber=${1}`))
    }, [])
    let [ localData=pendingList, ] = useState();
    let [ activeRow, setActiveRow] = useState([]);

    const handleHeaderCheck = ( value ) => {
        (value === true)
            ? setActiveRow( [...localData.map((entry) => entry.refId)])
            : setActiveRow([]);
    }

    const handleOnChangeStatus = ( reqObj ) => {
        let requestData = { ...reqObj, reason: reqObj.updateReason}
        if( reqObj.type === "Approve") {
            requestData = { "approvalAction": 1, ...requestData}
        }
        if( reqObj.type === "Reject") {
            requestData = { "approvalAction": 2, ...requestData}
        }
		dispatch(updateApprovalStatus(requestData, (respData) => {
            const { responseStatus, listReferenceId } = respData;
            const reference_number= listReferenceId && listReferenceId.join(",")
            const map = {1: "approved",2: "rejected"}
            if( responseStatus === "200 OK") {
                dispatch(retrieveAllPendingList(`/SUBMITTED?pageSize=${pageSize}&pageNumber=${pageNo}`))
                dispatch(retrieveAllApprovedList(`/APPROVED?pageSize=${10}&pageNumber=${1}`))
                dispatch(retrieveAllRejectedList(`/REJECTED?pageSize=${10}&pageNumber=${1}`))
                setToastState(true);
                setToastData({ message: `Request ${map[requestData.approvalAction]}`, reference_number, type: "success"});
                closeReqModal();
                window.scrollTo({
                    top: 0,
                    left:0,
                    behavior: "smooth"
                });
            }
            if( respData.errorResponse ) {
                setToastState(true);
                setToastData({ message: respData?.errorResponse.errorDescription, type: "warning"});
                closeReqModal();
                window.scrollTo({
                    top: 0,
                    left:0,
                    behavior: "smooth"
                });

            }
        }));
    }


    const columns = [
        {
            Header: (
                <Switch
                    onClick={(e) => handleHeaderCheck(e.target.checked)} 
                    checked={(activeRow && localData) && activeRow.length === localData.length}
                />
            ),
            accessor: 'checkBox',
            disableSortBy: true,
        },
        {
            Header: 'Reference Number',
            accessor: 'refId',
            sortType: 'basic',
        },
        {
            Header: 'Date',
            accessor: 'date',
            selector: 'date',
            sortType: 'basic',
        },
        {
            Header: 'Module',
            accessor: 'module',
            sortType: 'basic',
        },
        {
            Header: 'Request Type',
            accessor: 'request',
            sortType:( rowA, rowB, colId, desc ) => {
                return sortByElement(rowA, rowB, colId, desc)
            }
        },
        {
            Header: 'Requestor ID',
            accessor: 'reqDomainId',
            sortType: 'basic',
        },
        {
            Header: 'Reason',
            accessor: 'reason',
            sortType: 'basic',
        }
    ];
    const handleServerSidePagination = ( pageNumber, pgSize ) => {
        dispatch(retrieveAllPendingList(`/SUBMITTED?pageSize=${pgSize}&pageNumber=${pageNumber}`))
    }
    const openModal = ( rData) => {
        toggleModal(true)
        setModalData(rData);
    }
    const openReqModal = ( type) => {
        toggleModal(false)
        let rData = {}
        if( activeRow.length === 1 ) {
            const tData = localData.filter((ele) => ele.refId === activeRow[0]);
            rData = { ...tData[0], type: type }
        } else if(modalData && Object.keys(modalData).length > 0) {
            rData = { ...modalData, type: type }
        } else {
            rData = { refIdList: activeRow, type: type }
        }
        setReqModalState(true)
        setReqModalData(rData)
    }
    const linkDiv = (rowData) => {
        return(
            <div className="linkDiv" onClick={() => openModal(rowData)}>{rowData.requestType}</div>
        )
    }
    const handleCheckList = ( value, code ) => {
        const idx = activeRow.indexOf( code );
        if( value) setActiveRow( [...activeRow, code ] );
        else {
            activeRow.splice( idx, 1);
            setActiveRow([...activeRow])
        }
    }
    const localObj = localData && localData.map((ele) => {
        return {
            checkBox: (
                <Switch
                    onChange={(e) => handleCheckList(e.target.checked, ele.refId)} 
                    checked={activeRow.indexOf(ele.refId) !== -1}
                />),
            ...ele,
            date:  formatDate(ele.date),
            request: linkDiv(ele),
        }
    });
    const closeModal = () => { toggleModal(false); setModalData({})}
    const closeReqModal = () => { setReqModalState(false);setReqModalData({});setModalData({});setActiveRow([])}
    const clickHandler = (type) =>  {
        if( reqModalState && activeRow.length === 1) {
            formikRef.current.handleSubmit()   
        }  else if(reqModalState) {
            formikRef.current.handleSubmit() 
        }else {
            openReqModal(type)
        }
    }
    return(
        <div className="pending-list">
    
            <div className="btnBlock">
                {
                    (activeRow.length > 0) 
                    ? (
                        <>
                            <Button variant="primary" className="mr8" onClick={() => openReqModal("Approve")}>Approve</Button>
                            <Button variant="danger" onClick={() => openReqModal("Reject")}>Reject</Button>
                        </>
                    ) : ''
                }
            </div>
            <div className="dataBlock">
                {
                    (localObj !== undefined || errorResponse) 
                    ?  (
                    <DataTable 
                        columns={columns}
                        data={localObj || []}
                        showPagination={true}
                        handleServerSidePagination={handleServerSidePagination}
                        pageProperty={{ totalPages}}
                        errorDiv={errorDiv}
                    />):(
                        <div className="alignCenter">
                            <Spinner animation="border" />
                        </div>
                    )
                }
            </div>
            {
                openState && (
                    <BDOModal 
                        header={"Request Details"}
                        body={
                           <div className="reqModalBody">
                               <div><b>Status</b> : <label>{modalData.status}</label></div>
                               <div><b>Date Requested</b> : <label>{modalData.date}</label></div>
                               <div><b>Requestor Domain Id</b> : <label>{modalData.reqDomainId}</label></div>
                               <div><b>Request Type</b> : <label>{modalData.requestType}</label></div>
                               <div><b>Reason</b> : <label>{modalData.reason}</label></div>
                               <div><b>Module</b> : <label>{modalData.module}</label></div>
                               <div><b>Reference Id</b> : <label>{modalData.refId}</label></div>
                               <div className={`changeFeild ${modalData.fieldList.length ===1? 'justifyCenter':''}`}>
                               {
                                   modalData.fieldList.map((ele) => (
                                       <div className="feildDiv">
                                            <div><b>Field Code</b> : <label>{ele.fieldCode}</label></div>
                                            <div><b>Field Name</b> : <label>{ele.fieldName}</label></div>
                                            <div><b>Old Value</b> : <label className={ele?.oldValue?.includes(' ')?'': 'letter-break'}>{ele.oldValue}</label></div>
                                            <div><b>New Value</b> : <label className={ele?.newValue?.includes(' ')?'': 'letter-break'}>{ele.newValue}</label></div>
                                            <div><b>Affected Table</b> : <label>{ele.affectedTable}</label></div>
                                        </div>
                                   ))
                               }
                               </div>
                            </div>
                        }
                        footer={
                            <ModalFooterContent 
                                reqModalState={reqModalState}
                                openState={openState}
                                regModalData={regModalData}
                                clickHandler={clickHandler}
                                closeModal={closeModal}
                                closeReqModal={closeReqModal}
                            />
                        }
                        openState={openState}
                        modalProps={{onHide: closeModal }}
                    />
                )
            }
            {
                reqModalState && (
                    <BDOModal 
                        header={`${regModalData.type} Request`}
                        body={
                           <ApprovalModal 
                                regModalData={regModalData}
                                formikRef={formikRef}
                                handleOnChangeStatus={handleOnChangeStatus}
                           />
                        }
                        footer={
                            <ModalFooterContent 
                                reqModalState={reqModalState}
                                openState={openState}
                                regModalData={regModalData}
                                clickHandler={clickHandler}
                                closeModal={closeModal}
                                closeReqModal={closeReqModal}
                            />
                        }
                        openState={reqModalState}
                        modalProps={{onHide: closeReqModal }}
                    />
                )
            }
        </div>
    )

}

export default PendingList;
