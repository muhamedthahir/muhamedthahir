import React from 'react';
import InputText from '../Global/Input/InputText';
import { Form } from 'react-bootstrap';
import { Formik } from 'formik';
import * as Yup from 'yup';

const validationSchema = Yup.object().shape({
	updateReason: Yup.string().required('Required feild'),
});

const ApprovalModal = (props) => {
	const { regModalData, handleOnChangeStatus, formikRef } = props;
    const { refIdList } = regModalData;
	return (
		<div>
			<div className="leftDivReqBody">
                {(refIdList === undefined || refIdList.length === 0)  ? `${regModalData.type} this request?`: `Do you want to ${regModalData.type} all the request?`}
			</div>
            {(refIdList === undefined || refIdList.length === 0)? (
                <>
                    <div className="bdyRow">
                        <b>Request User : </b>
                        <span>{regModalData.reqDomainId}</span>
                    </div>
                    <div className="bdyRow">
                        <b>Module : </b>
                        <span>{regModalData.module}</span>
                    </div>
                    <div className="bdyRow">
                        <b>Reason : </b>
                        <span>{regModalData.reason}</span>
                    </div>
                    <div className="bdyRow reasonBlock">
                        <Formik
                            initialValues={{'updateReason':'', code: regModalData.refId}}
                            validationSchema={validationSchema}
                            innerRef={formikRef}
                            onSubmit={(values) => handleOnChangeStatus(values)}
                        >
                            {({ 
                        errors, touched, values, handleSubmit, handleChange,
                    }) => (
                            <Form onSubmit={handleSubmit}>
                                <InputText  
                                    value={regModalData.updateReason} 
                                    onChange={handleChange}
                                    placeholder="Please provide reason"
                                    name="updateReason"
                                    className={errors.updateReason && touched.updateReason? `err-feild`:''}
                                />
                                {
                                    errors.updateReason && touched.updateReason
                                    ?(
                                        <div className="alignLeft"> 
                                            <span className="err-feild">
                                                {errors.updateReason}
                                            </span>
                                        </div>
                                    ): ''
                                }
                            </Form>
                        )}
                    </Formik>
                </div>
            </>
        ):''}
    </div>
	)
};

export default ApprovalModal;
