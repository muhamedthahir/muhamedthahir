import React from 'react';
import InputText from '../Global/Input/InputText';
import { Form } from 'react-bootstrap';
import { Formik } from 'formik';
import * as Yup from 'yup';

const ApprovalModal = (props) => {
    let validationSchema = Yup.object().shape({});
    const { regModalData, handleOnChangeStatus, formikRef } = props;
    if( regModalData.type === "Reject") {
        validationSchema =  Yup.object().shape({
            updateReason: Yup.string().required('Required field'),
        });
    }
    
    const { refIdList } = regModalData;
    let referenceId = []
    if( refIdList ) referenceId = refIdList
    else referenceId = [ regModalData.refId]
	return (
		<div>
			<div className="leftDivReqBody">
                {(refIdList === undefined || refIdList.length === 0)  ? `${regModalData.type} this request?`: `Do you want to ${regModalData.type} all the request?`}
			</div>
            {(refIdList === undefined || refIdList.length === 0)? (
                <>
                    <div className="bdyRow">
                        <b>Request User : </b>
                        <span>{regModalData.reqDomainId}</span>
                    </div>
                    <div className="bdyRow">
                        <b>Module : </b>
                        <span>{regModalData.module}</span>
                    </div>
                    <div className="bdyRow">
                        <b>Reason : </b>
                        <span>{regModalData.reason}</span>
                    </div>
                </>
            ):''}
            <div className="bdyRow reasonBlock">
                <Formik
                    initialValues={{'updateReason':'', referenceId: referenceId, type: regModalData.type}}
                    validationSchema={validationSchema}
                    innerRef={formikRef}
                    onSubmit={(values) => {
                            handleOnChangeStatus(values)
                    }}
                >
                    {({ 
                        errors, touched, values, handleSubmit, handleChange,
                    }) => (
                            <Form onSubmit={handleSubmit}>
                                <InputText  
                                    value={regModalData.updateReason} 
                                    onChange={handleChange}
                                    placeholder="Please Provide Reason"
                                    name="updateReason"
                                    className={errors.updateReason && touched.updateReason? `err-feild`:''}
                                />
                                {
                                    errors.updateReason && touched.updateReason
                                    ?(
                                        <div className="alignLeft"> 
                                            <span className="err-feild">
                                                {errors.updateReason}
                                            </span>
                                        </div>
                                    ): ''
                                }
                            </Form>
                        )}
                    </Formik>
                </div>
        </div>
	)
};

export default ApprovalModal;
