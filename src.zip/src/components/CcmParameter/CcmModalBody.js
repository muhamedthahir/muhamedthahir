import React from 'react';
import InputText from '../Global/Input/InputText';
import { Form } from 'react-bootstrap';
import { Formik } from 'formik';
import * as Yup from 'yup';

const validationSchema = Yup.object().shape({
	reason: Yup.string()
		.required('Required field')
		.max(200, 'Reason should have less than 200 characters')
});

const CcmModalBody = (props) => {
	const { modalData, handleOnChangeStatus, formIkRef } = props;
	return (
		<div>
			<div>
				{modalData.header}
			</div>
			<div className="bdyRow">
				<b>CCM Parameter Code : </b>
				<span className={modalData?.fieldCode?.includes(' ')?'': 'letter-break'}>{modalData.fieldCode}</span>
			</div>
			<div className="bdyRow">
				<b>CCM Parameter Name : </b>
				<span>{modalData.fieldName}</span>
			</div>
			<div className="bdyRow">
				<b>CCM Parameter Value : </b>
				<span className={modalData?.fieldValue?.includes(' ')?'': 'letter-break'}>{modalData.fieldValue}</span>
			</div>
			<div className="bdyRow reasonBlock">
				<Formik
					initialValues={{ 'reason': '', fieldCode: modalData.fieldCode }}
					validationSchema={validationSchema}
					innerRef={formIkRef}
					onSubmit={(values) => handleOnChangeStatus({ ...values, state: modalData.changedState})}
				>
					{({
						errors, touched, values, handleSubmit, handleChange,
					}) => (
						<Form onSubmit={handleSubmit}>
							<InputText
								value={modalData.reason}
								onChange={handleChange}
								className={(errors.reason && touched.reason) ? 'error' : ''}
								placeholder="Please Provide Reason"
								name="reason"
							/>
							{
								errors.reason && touched.reason
									? (
										<div className="alignLeft">
											<span className="err-feild">
												{errors.reason}
											</span>
										</div>
									) : ''
							}
						</Form>
					)}
				</Formik>
			</div>
		</div>
	)
};

export default CcmModalBody;
