import React from 'react';
import {
    Row,
    Col
} from 'react-bootstrap';

function DetailsLabel(props) {
    const { labelName,  valueName, labelClassName, valueClassName } = props;
    return(
        <Row>
            <Col sm={3}>
                <label className={labelClassName}>{labelName}</label>
            </Col>
            <Col>
                <div className={valueClassName}>{valueName}</div>
            </Col>
        </Row>
    )
}

export default DetailsLabel;
