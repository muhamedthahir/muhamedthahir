import React from 'react';
import {
    Card,
    Container,
} from 'react-bootstrap';
import DetailsLabel from './DetailsLabel';


function ViewCCMDetails(props){
    const {
        ccmParameterDetails: { code, description, name, status}
    } = props;
    
    return(
        <Card>
            <Card.Body>
                <div className="cardHeader">
                    <Card.Title className="cardTitle">CCM Details</Card.Title>
                </div>
                <Card.Text>
                    <Container>
                        <DetailsLabel 
                            labelClassName="bodyRowLabel" 
                            labelName="Parameter Code" 
                            valueName={code}
                            valueClassName="bodyRowValue"
                        />
                        <DetailsLabel 
                            labelClassName="bodyRowLabel" 
                            labelName="Parameter Name" 
                            valueName={name}
                            valueClassName="bodyRowValue"
                        />
                        <DetailsLabel 
                            labelClassName="bodyRowLabel" 
                            labelName="Parameter Value" 
                            valueName={code}
                            valueClassName="bodyRowValue"
                        />
                        <DetailsLabel 
                            labelClassName="bodyRowLabel" 
                            labelName="Parameter Description" 
                            valueName={description}
                            valueClassName="bodyRowValue"
                        />
                        <DetailsLabel 
                            labelClassName="bodyRowLabel" 
                            labelName="Status" 
                            valueName={status}
                            valueClassName="bodyRowValue"
                        />
                    </Container>
                </Card.Text>
            </Card.Body>
        </Card>
    )
}

export default ViewCCMDetails;
