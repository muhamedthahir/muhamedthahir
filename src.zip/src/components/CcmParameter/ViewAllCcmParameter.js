/* eslint-disable react-hooks/exhaustive-deps */
import React, { useEffect, useState, useRef } from 'react';
import { useDispatch, useSelector } from "react-redux";
import {
  Card, Row, Col,
  Image, Spinner
} from 'react-bootstrap';
import { useHistory } from 'react-router-dom';
import SearchBar from '../Global/SearchBar/SearchBar';
import DataTable from '../Global/DataTable/DataTable';
import EditIcon from '../../assets/icons/icon-edit-outline.svg';
import Switch from '../Global/Switch/Switch';
import BDOModal from '../Global/BDOModal/BDOModal';
import CcmModalBody from './CcmModalBody';
import {
  retrieveAllCCMParameter, retrieveFindCCMParameter, updateCCMStatus,
  disableCCMStatus
} from '../../actions/ccmparameter';
import backIcon from '../../assets/icons/backIcon.png'
import BDOToast from '../Global/BDOToast/BDOToast';
import BDOButton from '../Global/Button/BDOButton';
import './styles/ViewAllCcmParameter.scss';

const editIcon = (rowData, toggle) => (
  <Image
    onClick={() => toggle('EDIT', rowData)}
    src={EditIcon} className="icon" 
  />
);
const linkDiv = (rowData, toggle, access) => (
  (access)? (
    <span
      className="name-primary"
      onClick={() => toggle('VIEW', rowData)} 
    >
      {rowData.fieldName}
    </span>
  ): (
    <span>{rowData.fieldName}</span>
  )
);
const actionDiv = (ele, handleStatusChange, toggle, accessMap) => {
  let isedit = false;
  if (accessMap?.canUpdate && ele.status === "ACTIVE") isedit = true;
  return (
    ele.status === "ACTIVE" || ele.status === "INACTIVE" ? (
      <div className="actionDiv">
        <div onClick={(e) => handleStatusChange(e, ele, accessMap)}>
          {(accessMap.canEnable || accessMap.canDisable) && (
            <Switch
              type="switch"
              id={`custom-switch-${ele.fieldCode}`}
              checked={ele.status === "ACTIVE"}
              onClick={(e) => {
                handleStatusChange(e, ele, accessMap)
              }}
            />
          )}
        </div>
        {isedit && <div className="editDiv">{editIcon(ele, toggle)}</div>}
      </div>
    ) : (
      ""
    )
  )
}
const alphaNumericSorting = (frstValue, scndValue, colId, desc = false) => {
  if (frstValue && scndValue) {
    if (!desc) return frstValue.localeCompare(scndValue);
    return -1 * scndValue.localeCompare(frstValue);
  }
};
const categoryList = [
  { 'label': 'Parameter Code', 'value': 'FieldCode' },
  { 'label': 'Parameter Name', 'value': 'FieldName' },
  { 'label': 'Parameter Value', 'value': 'FieldValue' }
];

const statusDiv = (rowData) => {
  let { status } = rowData;
  let className = "FORAPPROVAL";
  let text = "For Approval";
  if (status === "ACTIVE" || status === "INACTIVE") {
    className = "status" + status;
    text = status[0].toUpperCase() + status.substring(1, status.length).toLowerCase();
  }
  return <div className={className}>{text}</div>;
};

function ViewAllCcmParameter(props) {
  const { 
    canCreate, canDisable, canEnable,
    canUpdate, canViewRecord
  } = props;
  const history = useHistory();
  const dispatch = useDispatch();
  const retData = useSelector((state) => state.ccmparameter);
  let { viewAllCcmParameter = [] } = retData;
  const [isPageChanged, movePage] = useState(false)
  let {
    data, totalPages = 1, pageSize =10, currentPageNumber =1,
    errorResponse
  } = viewAllCcmParameter;
  let errorDiv = '';
  if (errorResponse) {
    errorDiv = (
      <span>{errorResponse.ccmErrorCode} - {errorResponse.errorDescription}</span>
    )
  }
  useEffect(() => {
    dispatch(retrieveAllCCMParameter(`?pageNumber=${1}&pageSize=${10}`));
  }, []);
  let propsData = props?.location?.state;
  let [localData = data,] = useState();
  const [modalState, setModalState] = useState(false);
  const [modalData, setModalData] = useState({});
  const [toastState, setToastState] = useState(false);
  const [toastData, setToastData] = useState({});
  const formIkRef = useRef();


  let toggle = (toggleaction, datatochild) => {
    if(toggleaction === "ADD"){
    history.push({ pathname: '/ccmparameter/addccmparameter', state: { toggleaction, datatochild } })
    }else{
      history.push({ pathname: `/ccmparameter/${datatochild.fieldCode}`, state: { toggleaction, datatochild } })
    }
  };
  const closeModal = () => {
    setModalData({});
    setModalState(false);
  }

  useEffect(() => {
    let responseMessage = propsData?.data?.responseMessage;
    let referenceId = propsData?.data?.referenceId;
    if (responseMessage  && referenceId) {
      setToastState(true);
      setToastData({ message : responseMessage , reference_number: referenceId, type: "success" });
      window.scrollTo({
        top: 0,
        left: 0,
        behavior: "smooth",
      });
    }
  }, [propsData?.data]);

  const updateStatus = (respData, reqObj) => {
    const { responseStatus,  referenceId} = respData;
    if (responseStatus === "200 OK") {
      dispatch(retrieveAllCCMParameter(`?pageNumber=${currentPageNumber}&pageSize=${pageSize}`))
      setToastState(true);
      setToastData({ message: `${reqObj.state} request submitted for approval`, reference_number: referenceId, type: "success" });
      closeModal();
      window.scrollTo({
        top: 0,
        left: 0,
        behavior: "smooth"
      });
    }
  }

  const handleOnChangeStatus = (reqObj) => {
    if (reqObj.state === "Enable") {
      dispatch(updateCCMStatus(reqObj, (respData) => {
        updateStatus(respData, reqObj)
      }));
    }
    if (reqObj.state === "Disable") {
      dispatch(disableCCMStatus(reqObj, (respData) => {
        updateStatus(respData, reqObj)
      }));
    }

  }



  const columns = [
    {
      Header: "Parameter Code",
      accessor: "fieldCode",
      selector: "fieldCode",
      sortType: "basic",
    },
    {
      Header: "Parameter Name",
      accessor: "fieldName",
      sortType: (rowA, rowB, colId, desc) => {
        const findFn = (entry) => entry.column && entry.column.id === colId;
        const foundAData = rowA.cells.find(findFn);
        const foundBData = rowB.cells.find(findFn);
        const aValue =
          typeof rowA.cells[0] !== "function" &&
          foundAData &&
          foundAData.value.props.children;
        const bValue =
          typeof rowB.cells[0] !== "function" &&
          foundBData &&
          foundBData.value.props.children;
        return alphaNumericSorting(aValue, bValue, colId, desc);
      },
    },
    {
      Header: "Parameter Value",
      accessor: "fieldValue",
    },
    {
      Header: "Status",
      accessor: "status",
    },
    {
      Header: "Actions",
      accessor: "actions",
      disableSortBy: true,
    },
  ];


  const handleClick = (category, ipText) => {
    movePage(true)
    dispatch(retrieveFindCCMParameter(`searchText=${ipText}&searchType=${category}&pageSize=${10}&pageNumber=${1}`));
  };
  const handleStatusChange = (e, valueObj, accessMap) => {
    e.stopPropagation();
    if (e.target.checked) {
      if( accessMap.canEnable) {
        valueObj = { ...valueObj, modalHeader: 'Enable CCM parameter', changedState: 'Enable' }
        setModalState(true);
        setModalData(valueObj);
      } else {
        setToastState(true)
        setToastData({ message : "Unauthorized access for enable action.Please contact admin for access " , type: "warning" })
        window.scrollTo({
          top: 0,
          left: 0,
          behavior: "smooth",
        });
      }
    } else {
      if( accessMap.canDisable) {
        valueObj = { ...valueObj, modalHeader: 'Disable CCM parameter', changedState: 'Disable' }
        setModalState(true);
        setModalData(valueObj);
      } else {
        setToastState(true)
        setToastData({ message : "Unauthorized access for disable action.Please contact admin for access " , type: "warning" })
        window.scrollTo({
          top: 0,
          left: 0,
          behavior: "smooth",
        });
      }
    }
    
  };
  const codeDiv =(ele)=>{
    let text = ele.fieldCode;
    if(ele?.fieldCode?.length > 50){
      text = ele.fieldCode.substring(0,44)+"..."
    }
    return(
      <span title={ele.fieldCode} className='cursor-context'>{text}</span>
    )
  }
  const localObj =
    localData &&
    localData.map((ele) => {
      return {
        ...ele,
        fieldCode: codeDiv(ele),
        fieldName: linkDiv(ele, toggle, canViewRecord),
        status: statusDiv(ele),
        actions: actionDiv(ele, handleStatusChange, toggle, { canEnable, canDisable, canUpdate}),
      };
    });
  const modalFooterContent = (
    <div>
      <BDOButton variant="secondary" onClick={closeModal}>Cancel</BDOButton>
      <BDOButton variant={modalData.changedState === "Enable" ? "primary" : "danger"}
        onClick={() => formIkRef.current.handleSubmit()}
      >
        {modalData.changedState}
      </BDOButton>
    </div>
  );

  const onToastClose = () => {
    setToastState(false);
    setToastData({});
    if (history.location.state && history.location.state.data) {
      let state = { ...history.location.state };
      delete state.data;
      history.replace({ ...history.location, state });
    }
  }

  const handleServerSidePagination = (pageNo, pgSize) => {
    dispatch(retrieveAllCCMParameter(`?pageNumber=${pageNo}&pageSize=${pgSize}`));
  };

  return (
    <div className="ccmParameter">
      <div className="headerBlock">
        <div className="redirect">
          <div style={{cursor: "pointer"}} onClick={() => history.push("/")}>
              <Image src={backIcon}  className="icon"/>
          </div>
          <b>CCM Parameter</b>
        </div>
        <div className="buttonBlock">
          { canCreate && 
            <BDOButton variant="primary"
              onClick={(e) => toggle('ADD')}
            >
              Add CCM Parameter
            </BDOButton>
          }
        </div>
      </div>
      {
        toastState && (
          <BDOToast
            openState={toastState}
            type={`${toastData.type?toastData.type:"success"}`}
            bodyMessage={
              `${toastData.message}. ${toastData.reference_number? "Reference No:" +toastData.reference_number:''}`
            }
            onClose={onToastClose}
          />
        )
      }
      <Card className="searchBlock">
        <Card.Body>
          <div className="searchCard">
            <Row className="mb10">
              <Col sm={8}>
                <b className="ml10">Search CCM Parameter</b>
              </Col>
            </Row>
            <div className="formBlock">
              <SearchBar
                categoryList={categoryList}
                textPlaceHolder="Input Keyword"
                handleClick={handleClick}
              />
            </div>
          </div>
        </Card.Body>
      </Card>
      <div className="tableBlock">
        <Card>
          <Card.Body>
            <div className="mb10">
              <b className="header6">CCM Parameter</b>
            </div>
            <div className="dataBlock">
              {localObj !== undefined || errorResponse ? (
                <DataTable
                  columns={columns}
                  data={localObj || []}
                  showPagination={true}
                  handleServerSidePagination={handleServerSidePagination}
                  pageProperty={{ totalPages, isPageChanged, movePage: (val) => movePage(val) }}
                  errorDiv={errorDiv}

                />
              ) : (
                <div className="alignCenter">
                  <Spinner animation="border" />
                </div>
              )}
            </div>
          </Card.Body>
        </Card>
      </div>
      {
        modalState && (
          <BDOModal
            header={modalData.modalHeader}
            body={
              <CcmModalBody
                modalData={modalData}
                setModalData={setModalData}
                formIkRef={formIkRef}
                handleOnChangeStatus={handleOnChangeStatus}
              />}
            footer={modalFooterContent}
            openState={modalState}
            modalProps={{ onHide: closeModal }}
          />
        )
      }
    </div>
  );
}
export default ViewAllCcmParameter;
