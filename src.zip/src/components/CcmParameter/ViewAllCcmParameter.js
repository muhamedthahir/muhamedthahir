/* eslint-disable react-hooks/exhaustive-deps */
import React, { useEffect, useState, useRef } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Card, Row, Col, Button, Image, Spinner } from "react-bootstrap";
import { useHistory } from "react-router-dom";
import SearchBar from "../Global/SearchBar/SearchBar";
import DataTable from "../Global/DataTable/DataTable";
import EditIcon from "../../assets/icons/icon-edit-outline.svg";
import Switch from "../Global/Switch/Switch";
import BDOModal from "../Global/BDOModal/BDOModal";
import CcmModalBody from "./CcmModalBody";
import {
  retrieveAllCCMParameter,
  retrieveFindCCMParameter,
  updateCCMStatus,
} from "../../actions/ccmparameter";
import BDOToast from "../Global/BDOToast/BDOToast";
import "./styles/ViewAllCcmParameter.scss";
import BDOButton from "../Global/Button/BDOButton";

const editIcon = (rowData, toggle) => (
  <Image
    onClick={() => toggle("EDIT", rowData)}
    src={EditIcon}
    className="icon"
  />
);
const linkDiv = (rowData, toggle) => (
  <span className="name-primary" onClick={() => toggle("VIEW", rowData)}>
    {rowData.fieldName}
  </span>
);
const actionDiv = (ele, handleStatusChange, toggle) => {
  let status;
  if (ele.status) status = "active";
  else status = "inactive";
  let isedit = false;
  if (status === "active") isedit = true;
  return status === "active" || status === "inactive" ? (
    <div className="actionDiv">
      <div onClick={(e) => handleStatusChange(e, ele)}>
        <Switch
          type="switch"
          id={`custom-switch-${ele.code}`}
          checked={status === "active"}
        />
      </div>
      {isedit && <div className="editDiv">{editIcon(ele, toggle)}</div>}
    </div>
  ) : (
    ""
  );
};
const alphaNumericSorting = (frstValue, scndValue, colId, desc = false) => {
  if (frstValue && scndValue) {
    if (!desc) return frstValue.localeCompare(scndValue);
    return -1 * scndValue.localeCompare(frstValue);
  }
};
const categoryList = [
  { key: "CCM Code", value: "FieldCode" },
  { key: "CCM Name", value: "FieldName" },
  { key: "CCM Value", value: "FieldValue" },
];

const statusDiv = (rowData) => {
  let { status } = rowData;
  let className = "forApproval";
  let text = "For Approval";
  if (status) status = "active";
  else status = "inactive";
  if (status === "active" || status === "inactive") {
    className = "status" + status;
    text = status[0].toUpperCase() + status.substring(1, status.length);
  }
  return <div className={className}>{text}</div>;
};

function ViewAllCcmParameter(props) {
  const history = useHistory();
  const dispatch = useDispatch();
  const retData = useSelector((state) => state.ccmparameter);
  let { viewAllCcmParameter = [] } = retData;
  const [isPageChanged, movePage] = useState(false);
  let { data, totalPages = 1, errorResponse } = viewAllCcmParameter;
  let errorDiv = "";
  if (errorResponse) {
    errorDiv = <span>{errorResponse.errorDescription}</span>;
  }
  useEffect(() => {
    dispatch(retrieveAllCCMParameter(`pageNumber=${1}&pageSize=${10}`));
  }, []);
  let propsData = props?.location?.state;
  let [localData = data, setData] = useState();
  const [modalState, setModalState] = useState(false);
  const [modalData, setModalData] = useState({});
  const [toastState, setToastState] = useState(false);
  const [toastData, setToastData] = useState({});
  const formIkRef = useRef();

  let toggle = (toggleaction, datatochild) => {
    history.push({
      pathname: "/ccmparameter/addccmparameter",
      state: { toggleaction, datatochild },
    });
  };
  const closeModal = () => {
    setModalData({});
    setModalState(false);
    setData([...localData]);
  };

  useEffect(() => {
    let message = propsData?.values?.paramname;
    let reference_number = propsData?.values?.paramvalue;
    if (message !== undefined && reference_number !== undefined) {
      setToastState(true);
      setToastData({ message, reference_number, type: "success" });
    }
  }, [propsData?.values]);
  const handleOnChangeStatus = (reqObj) => {
    dispatch(
      updateCCMStatus(reqObj, (respData) => {
        const {
          data: { message, reference_number },
        } = respData;
        const finder = data.find((ele) => ele.code === reqObj.code);
        finder["status"] = finder.status === "inactive" ? "active" : "inactive";
        setData([...data]);
        setToastState(true);
        setToastData({ message, reference_number, type: "success" });
        closeModal();
        window.scrollTo({
          top: 0,
          left: 0,
          behavior: "smooth",
        });
      })
    );
  };

  const columns = [
    {
      Header: "CCM Code",
      accessor: "fieldCode",
      selector: "fieldCode",
      sortType: "basic",
    },
    {
      Header: "CCM Name",
      accessor: "fieldName",
      sortType: (rowA, rowB, colId, desc) => {
        const findFn = (entry) => entry.column && entry.column.id === colId;
        const foundAData = rowA.cells.find(findFn);
        const foundBData = rowB.cells.find(findFn);
        const aValue =
          typeof rowA.cells[0] !== "function" &&
          foundAData &&
          foundAData.value.props.children;
        const bValue =
          typeof rowB.cells[0] !== "function" &&
          foundBData &&
          foundBData.value.props.children;
        return alphaNumericSorting(aValue, bValue, colId, desc);
      },
    },
    {
      Header: "CCM Value",
      accessor: "fieldValue",
    },
    {
      Header: "Status",
      accessor: "status",
    },
    {
      Header: "Actions",
      accessor: "actions",
      disableSortBy: true,
    },
  ];

  const handleClick = (category, ipText) => {
    movePage(true);
    dispatch(
      retrieveFindCCMParameter(
        `searchText=${ipText}&searchType=${category}&pageSize=${10}&pageNumber=${1}`
      )
    );
  };
  const handleStatusChange = (e, valueObj) => {
    e.stopPropagation();
    if (e.target.checked) {
      valueObj = {
        ...valueObj,
        modalHeader: "Enable CCM parameter",
        changedState: "Enable",
      };
    } else {
      valueObj = {
        ...valueObj,
        modalHeader: "Disable CCM parameter",
        changedState: "Disable",
      };
    }
    setModalState(true);
    setModalData(valueObj);
  };

  const localObj =
    localData &&
    localData.map((ele) => {
      return {
        ...ele,
        fieldName: linkDiv(ele, toggle),
        status: statusDiv(ele),
        actions: actionDiv(ele, handleStatusChange, toggle),
      };
    });
  const modalFooterContent = (
    <div>
      <BDOButton variant="secondary" onClick={closeModal}>
        Cancel
      </BDOButton>
      <BDOButton
        variant="primary"
        onClick={() => formIkRef.current.handleSubmit()}
      >
        {modalData.changedState}
      </BDOButton>
    </div>
  );

  const onToastClose = () => {
    setToastState(false);
    setToastData({});
    if (history.location.state && history.location.state.values) {
      let state = { ...history.location.state };
      delete state.values;
      history.replace({ ...history.location, state });
    }
  };

  const handleServerSidePagination = (pageNo, pageSize) => {
    dispatch(
      retrieveAllCCMParameter(`pageNumber=${pageNo}&pageSize=${pageSize}`)
    );
  };

  return (
    <div className="ccmParameter">
      <div className="headerBlock">
        <div>
          <b>CCM Parameter</b>
        </div>
        <div className="buttonBlock">
          <BDOButton
            variant="primary"
            // onClick={(e) => toggle('ADD')}
          >
            Add CCM Parameter
          </BDOButton>
        </div>
      </div>
      {toastState && (
        <BDOToast
          openState={toastState}
          type={"success"}
          bodyMessage={`${toastData.message}. Reference No: ${toastData.reference_number}`}
          onClose={onToastClose}
        />
      )}
      <Card className="searchBlock">
        <Card.Body>
          <div className="searchCard">
            <Row className="mb10">
              <Col sm={8}>
                <b className="ml10">Search CCM Parameter</b>
              </Col>
            </Row>
            <div className="formBlock">
              <SearchBar
                categoryList={categoryList}
                textPlaceHolder="Enter CCM Parameter"
                handleClick={handleClick}
              />
            </div>
          </div>
        </Card.Body>
      </Card>
      <div className="tableBlock">
        <Card>
          <Card.Body>
            <div className="mb10">
              <b className="header6">CCM Parameter</b>
            </div>
            <div className="dataBlock">
              {localObj !== undefined || errorResponse ? (
                <DataTable
                  columns={columns}
                  data={localObj || []}
                  showPagination={true}
                  handleServerSidePagination={handleServerSidePagination}
                  pageProperty={{
                    totalPages,
                    isPageChanged,
                    movePage: (val) => movePage(val),
                  }}
                  errorDiv={errorDiv}
                />
              ) : (
                <div className="alignCenter">
                  <Spinner animation="border" />
                </div>
              )}
            </div>
          </Card.Body>
        </Card>
      </div>
      {modalState && (
        <BDOModal
          header={modalData.modalHeader}
          body={
            <CcmModalBody
              modalData={modalData}
              setModalData={setModalData}
              formIkRef={formIkRef}
              handleOnChangeStatus={handleOnChangeStatus}
            />
          }
          footer={modalFooterContent}
          openState={modalState}
          modalProps={{ onHide: closeModal }}
        />
      )}
    </div>
  );
}
export default ViewAllCcmParameter;
