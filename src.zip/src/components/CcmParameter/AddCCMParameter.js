/* eslint-disable react-hooks/exhaustive-deps */
import React, { useEffect, useState } from "react";
import {
  Col,
  Form,
  Row,
  Card,
  Image,
} from 'react-bootstrap';
import { useDispatch, useSelector } from "react-redux";
import { useHistory } from 'react-router-dom';
import { useFormik } from 'formik';
import DateTimePicker from '../Global/DateTimePicker/DateTimePicker';
import PlusIcon from '../../assets/icons/plus_icon.svg'
import MinusIcon from '../../assets/icons/icon-delete.svg'
import * as Yup from 'yup';
import BDOToast from '../../components/Global/BDOToast/BDOToast';
import backIcon from '../../assets/icons/backIcon.png'
import BDOButton from '../Global/Button/BDOButton';
import InputText from '../Global/Input/InputText';
import Switch from '../Global/Switch/Switch';
import { retrieveCCMRecord, addCCMParameter, updateCCMParameter } from '../../actions/ccmparameter';
import BDOSelect from "../Global/Select/BDOSelect";
let initialValues = {};
let dataToBeEdited = {};
// to avoid nested ternary
const getClassNamefordType = (propsData, getClazzName, formik, props) => propsData.toggleaction === "VIEW" ? `disabled selectDropDown ${props.className} ${getClazzName(formik, 'dataType')}` : `selectDropDown ${props.className} ${getClazzName(formik, 'dataType')}`

const getStepVlaue = ( formik ) => formik.values.dataType === "Decimal" ? "0.01" : 1

const getLabelValue = (formik) => (formik.values.dataType !== "List" && formik.values.dataType !== "Checkbox")? "Parameter Value" : "DataList Value"

const getName = formik => (formik.values.dataType !== "List" && formik.values.dataType !== "Checkbox" ) ? "fieldValue" : "dataList"

const getOptionlist = ( formik, optionList, optionCheckbox) => formik.values.dataType === "List" ? optionList : optionCheckbox;

const getFeildValue = formik => ((formik.values.fieldValue === undefined || formik.values.fieldValue === '') ? formik.values?.fieldDefaultValue : formik.values.fieldValue)

const getStatusValue = formik => formik.values.status === "ACTIVE" ? 'Active' : 'Inactive';

const getInputStatus = formik => (formik.values.status === "ACTIVE" || formik.values.status === "INACTIVE") ?formik.values.status[0].toUpperCase() + formik.values.status.substring(1, formik.values.status.length).toLowerCase() : "For Approval"

const isChecbkBoxDataList = values => values.dataType === 'Checkbox' && values?.dataList?.length>=1

const isEditMode = propsData => (propsData?.toggleaction === 'ADD' || (propsData?.toggleaction === 'EDIT') || (propsData?.toggleaction === 'VIEW'));

const getTitle = ( propsData, initialValue, title ) => propsData?.toggleaction === 'ADD' ? `${title}  CCM Parameter` : `${initialValue.fieldCode}`

const collectInitialValues = ( dataToEdit ) => {
  let initVal = {}
  initVal.fieldCode = dataToEdit.fieldCode || '';
  initVal.fieldName = dataToEdit.fieldName || '';
  initVal.fieldValue = dataToEdit.fieldValue || '';
  initVal.fieldDescription = dataToEdit.fieldDescription || '';
  initVal.dataType = dataToEdit.dataType || '';
  initVal.status = dataToEdit?.status;
  initVal.affectedModules = dataToEdit.affectedModules || '';
  initVal.reason = dataToEdit.reason || '';
  if(dataToEdit.dataType === "Checkbox"){
    initVal.dataList = dataToEdit.selectedDataList;
  }
  return initVal;
}
const renderStaus = ( propsData, formik, getClazzName, handleSwitchChange ) => (
  (propsData.toggleaction !== "VIEW") ?
    <div className="flex">
    <Switch
      type="switch"
      id={`custom-switch-${formik?.values?.fieldName}`}
      disabled={propsData.toggleaction === "VIEW"}
      onChange={(e) => handleSwitchChange("status", e.target.checked)}
      checked={formik.values.status === "ACTIVE"}
    /><div>{getStatusValue(formik)}</div>
    </div> : <>
    <InputText
      className={getClazzName(formik, 'status')}
      value={getInputStatus(formik)}
      disabled={propsData.toggleaction === "VIEW"}
      name='status'
    />  
  </>
)

const renderError = (formik, fieldName) => {
  return formik.errors[(fieldName)] ? (
    <span className='mb-1 error-text'>
      {formik.errors[(fieldName)]}
    </span>
  ) : null
}

const getClassName = (formik, fieldName) => {
  let returnMsg = "input-text";
  if(fieldName === "dataType" || fieldName === "selectedDataList"){
    returnMsg = "select";
  }
  if (formik.errors[(fieldName)]) return returnMsg + " error"
  return returnMsg
}
const dataTypeList = [
  { label: "String", value: "String" },
  { label: "Integer", value: "Integer" },
  { label: "Decimal", value: "Decimal" },
  { label: "Check Box", value: "Checkbox" },
  { label: "List", value: "List" },
  { label: "Time", value: "Time" },
  { label: "Date", value: "Date" },
  { label: "DateTime", value: "DateTime" },
];
const handleDataChange = (formik, val ,setNumber ,setString ,setDecimal) => {
  formik.setFieldValue('dataType', val)
  formik.setFieldValue('fieldValue', '')
  formik.setFieldValue('dataType', val)
  formik.setFieldValue('dataFormat', dataFormat[val])

  const resetValidation = ( numberValue, decimalValue ) => {
    formik.setFieldValue('maximumValue', '');
    formik.setFieldValue('minimumValue', '');
    formik.setFieldValue('dataList',[]);
    setNumber(numberValue);
    setDecimal(decimalValue);
  }
  if (val === 'String') {
    formik.setFieldValue('fieldDefaultValue', '');
    resetValidation(false,false);
  }
  if (val === 'List' || val === 'Checkbox') {
    formik.setFieldValue('fieldValue', "null");
    resetValidation(false,false);
  }
  else if (val === 'Integer') {
    formik.setFieldValue('fieldDefaultValue', 0)
    formik.setFieldValue('fieldValue', 0);
    resetValidation(true,false);
  }
  else if (val === 'Decimal') {
    formik.setFieldValue('fieldDefaultValue', 0.00)
    formik.setFieldValue('fieldValue', 0.00);
    resetValidation(false,true);
  } else {
    formik.setFieldValue('fieldDefaultValue', '');
    resetValidation(false,false);
  }
}

const addDatalist = (inpText, objec, setInputText, dataType, setErrorMessage) => {
  if (inpText && inpText.length > 0) {
    setInputText('');
    let tempObj = (objec.values.dataList && [...objec.values.dataList]) || []
    if( tempObj.length < 50) {
      if(dataType==="List"){
        objec.setFieldValue('dataList', [...tempObj, inpText])
      }else{
        objec.setFieldValue('dataList', [...tempObj, {value: inpText , selected: false}])
      }
    } else {
      setErrorMessage('Datalist cannot add more than 50 values in the list') // this thing alone we need to discuss
    }
  } else {
    setErrorMessage('Please enter value')
  }
}

const getStep = ( dataType ) => dataType === "Decimal" ? "0.01" : 1;

const getTimeFormat = ( dataType ) => dataType === "Date" ? false : "hh:mm A"

const getDateFormat = ( dataType, getDatatype ) => dataType=== 'Time' ? false : getDatatype(dataType)

const renderDateTimePicker = (dataType, name, value, disabled,dataObj, {constructedDate, getDatatype, className}) => (
  <DateTimePicker
    onChange={(e) => {
      if (dataType === 'Date' && e._d) {
        dataObj.setFieldValue(name,`${(e._d.getUTCMonth() + 1).toString().padStart(2, '0')}-${e._d.getUTCDate().toString().padStart(2, '0')}-${e._d.getUTCFullYear()}`)
        if (name === 'fieldDefaultValue') {
          dataObj.setFieldValue('fieldValue', `${(e._d.getUTCMonth() + 1).toString().padStart(2, '0')}-${e._d.getUTCDate().toString().padStart(2, '0')}-${e._d.getUTCFullYear()}`)
        }
      }
      else if (dataType === 'Time' && e._d) {
        dataObj.setFieldValue(name, `${e._d.getUTCHours().toString().padStart(2, '0')}:${e._d.getUTCMinutes().toString().padStart(2, '0')}:${e._d.getUTCSeconds().toString().padStart(2, '0')}`)
        if (name === 'fieldDefaultValue') {
          dataObj.setFieldValue('fieldValue', `${e._d.getUTCHours().toString().padStart(2, '0')}:${e._d.getUTCMinutes().toString().padStart(2, '0')}:${e._d.getUTCSeconds().toString().padStart(2, '0')}`)
        }
      }
      else if (e._d) {
        dataObj.setFieldValue(name, `${e._d.getUTCFullYear()}-${(e._d.getUTCMonth() + 1).toString().padStart(2, '0')}-${e._d.getUTCDate().toString().padStart(2, '0')}T${e._d.getUTCHours().toString().padStart(2, '0')}:${e._d.getUTCMinutes().toString().padStart(2, '0')}:${e._d.getUTCSeconds().toString().padStart(2, '0')}`)
        if (name === 'fieldDefaultValue') {
          dataObj.setFieldValue('fieldValue', `${e._d.getUTCFullYear()}-${(e._d.getUTCMonth() + 1).toString().padStart(2, '0')}-${e._d.getUTCDate().toString().padStart(2, '0')}T${e._d.getUTCHours().toString().padStart(2, '0')}:${e._d.getUTCMinutes().toString().padStart(2, '0')}:${e._d.getUTCSeconds().toString().padStart(2, '0')}`)
        }
      }
    }}
    initialValue={value}
    inputProps = {{ disabled: disabled}}
    value={constructedDate}
    dateFormat={getDateFormat(dataType, getDatatype)}
    timeFormat={getTimeFormat(dataType) }
    className={`datePicker ${className}`}
    key={`${name}_${dataType}`}
    utc={true}
  />
)

const dataFormat = { String: '#AANNNLLL', Integer: 'NNNNNN', Decimal: '#N.NN', Date: 'MM-DD-YYYY', Time: 'HH:MM:SS(UTC)', DateTime: 'YYYY-MM-DDThh:mm:ss+0000 (UTC)' }
const formatFinder = { String: 'text', Checkbox: 'switch', Integer: 'number', Decimal: 'number', Date: 'date', Time: 'time', DateTime: 'date' }

const isDateRelated = dataType  => dataType === 'DateTime' || dataType === 'Date' || dataType === 'Time'

const FindInputType = ({ dataType, className, handleChange, name, placeholder, value, dataObj, disabled }) => {

  const [ipText, setInputText] = useState();
  const [errorMsg, setErrorMessage] = useState();
  
  const type = formatFinder[dataType];
  let inputEle = '';
  if (isDateRelated(dataType)) {
    let constructedDate;
    if (dataType === 'Time' && value) {
      constructedDate = new Date();
      constructedDate.setUTCHours(value.split(":")[0])
      constructedDate.setUTCMinutes(value.split(":")[1])
      constructedDate.setUTCSeconds(value.split(":")[2])
    }
    if (dataType === 'Date') {
      let splitList = value.split("-")
      constructedDate = new Date(Date.UTC(splitList[2], parseInt(splitList[0]) - 1, splitList[1]))
    }
    if (dataType === 'DateTime') {
      let [datesplitList , timesplitList=""] = value.split("T")
      let datelist = datesplitList.split("-")
      let timelist = timesplitList.split(":")
      constructedDate = new Date(Date.UTC(datelist[0], parseInt(datelist[1]) - 1, datelist[2]))
      constructedDate.setUTCHours(timelist[0])
      constructedDate.setUTCMinutes(timelist[1])
      constructedDate.setUTCSeconds(timelist[2])
    }
    const getDatatype = dateFormat => (dataType === 'DateTime'? "YYYY-MM-DD" :"MM-DD-YYYY")
    inputEle = (
      <>
      {renderDateTimePicker(dataType, name, value, disabled,dataObj, {constructedDate, getDatatype, className})}
      </>
      
    )
  } else if ((dataType === 'Checkbox' || dataType === 'List' ) && !disabled) {
    inputEle = (
      <>
        <div className="flex">
          <InputText
            name='dataText'
            type="text"
            labelClassName={"labelClass"}
            valueClassName={"valueClass"}
            disabled={disabled}
            smValue={2}
            onChange={(e) => { setErrorMessage(''); setInputText(e.target.value) }}
            rowClassName="rowMargin"
            className={className}
            placeholder={"Enter Value For Data List"}
            value={ipText}
          />
          <Image className="plusIcon" src={PlusIcon} disabled={disabled} onClick={
            ()=>addDatalist(ipText , dataObj, setInputText, dataType, setErrorMessage)
          } />
        </div>
        <span className='mb-1 error-text'>
          {errorMsg}
        </span>
      </>
    )
  } else {
    inputEle = (
      <InputText
        name={name}
        type={type}
        onChange={handleChange}
        labelClassName={"labelClass"}
        valueClassName={"valueClass"}
        smValue={2}
        rowClassName="rowMargin"
        className={className}
        step={getStep(dataType)}
        disabled={disabled}
        placeholder={placeholder}
        value={value}
      />
    )
  }
  return (
    inputEle
  )
}
const getValidationSchema = ( isNumber, isDecimal ) => {
  let validationSchemaActual = {
    fieldName: Yup.string()
      .matches(/^[A-Za-z0-9 _]*$/, 'Please enter valid name')
      .max(50, 'Must be 50 characters or less')
      .required('Required field'),
    fieldValue: Yup.string()
      .required('Required field'),
    fieldDescription: Yup.string()
      .max(200, 'Must be 200 characters or less')
      .required('Required field'),
    dataType: Yup.string().required('Required field'),
    // fieldDefaultValue: Yup.string()
    //   .max(50, 'Must be 50 characters or less')
    //   .required('Required field'),
    affectedModules: Yup.string()
      .max(200, 'Must be 200 characters or less')
      .required('Required field'),
    reason: Yup.string()
      .max(50, 'Must be 50 characters or less')
      .required('Required field'),
    status: Yup.string().required('Required field')
  };
  if( isDecimal ) {
    validationSchemaActual = {
        ...validationSchemaActual,
        maximumValue: Yup.number()
      .typeError("That doesn't look like a number")
      .max(99999, 'Must be 99999 or less')
      .required('Required field')
      .positive("Number can't be negative or 0"),
    minimumValue: Yup.number()
      .typeError("That doesn't look like a number")
      .positive("Number can't be negative or 0")
      .max(99999, 'Must be 99999 or less')
      .required('Required field'),
      fieldValue: Yup.number()
      .typeError("That doesn't look like a number")
      .positive("Number can't be negative or 0")
      .required('Required field'),
    }
  } else if( isNumber ) {
    validationSchemaActual = {
        ...validationSchemaActual,
        maximumValue: Yup.number()
        .typeError("That doesn't look like a number")
        .positive("Number can't be negative or 0")
        .max(99999, 'Must be 99999 or less')
        .integer("Number can't include a decimal point")
        .required('Required field'),
      minimumValue: Yup.number()
        .typeError("That doesn't look like a number")
        .positive("Number can't be negative or 0")
        .max(99999, 'Must be 99999 or less')
        .integer("Number can't include a decimal point")
        .required('Required field'),
      fieldValue: Yup.number()
      .typeError("That doesn't look like a number")
      .positive("Number can't be negative or 0")
      .integer("Number can't include a decimal point")
      .required('Required field'),
    }
  } else {
    validationSchemaActual = { ...validationSchemaActual }
  }
  return validationSchemaActual;
}
export default function AddCCMParameter(props) {
  const history = useHistory();
  const dispatch = useDispatch();

  let propsData = props?.location?.state;
  let retrivedData = useSelector(state => state.ccmparameter);
  useEffect(() => {
    if (propsData.toggleaction === 'EDIT' || propsData.toggleaction === 'VIEW') {
      dispatch(retrieveCCMRecord(propsData.datatochild.fieldCode));
    }
  }, []);
  const [isNumber, setNumber] = useState(false);
  const [, setString] = useState(false);
  const [isDecimal, setDecimal] = useState(false);
  const [toastState, setToastState] = useState(false);
  dataToBeEdited = retrivedData?.viewCcmParameter;
  let errorDiv = undefined;

  if (retrivedData?.addCcmParameter?.errorResponse ) {
    errorDiv = (
      <BDOToast
        openState={toastState}
        onClose={()=>setToastState(false)}
        type={"critical"}
        bodyMessage={retrivedData?.addCcmParameter?.errorResponse?.errorDescription}
      />
    )
    window.scrollTo({
      top: 0,
      left: 0,
      behavior: "smooth",
  });
  }
  if (retrivedData?.updatePostCcmParameter?.errorResponse) {
    errorDiv = (
      <BDOToast
        openState={toastState}
        onClose={()=>{setToastState(false)}}
        type={"critical"}
        bodyMessage={retrivedData?.updatePostCcmParameter?.errorResponse?.errorDescription}
      />
    )
    window.scrollTo({
      top: 0,
      left: 0,
      behavior: "smooth",
  });
  }

  if (propsData && propsData.datatochild && dataToBeEdited !== undefined) {
    let dataToEdit = dataToBeEdited;
    initialValues = dataToEdit; //This is written to check and update the fields automatically without below lines
    initialValues= { ...collectInitialValues( dataToEdit )}; 
  }
  if (!initialValues.status) {
    initialValues.status = "INACTIVE";
  }
  
  let validationSchemaActual = getValidationSchema( isNumber, isDecimal);

  const handleErrorMsg = ( errRes, resStatus, setErrors, tstData ) => {
    if (errRes) {
      setToastState(true)
      const { errorList = {} } = errRes
      setErrors(errorList );
      if(formik.values.dataType === "Checkbox"){
        formik.values.dataList = formik.values.selectedDataList;
      }
    }
    if (resStatus === "200 OK") {
      initialValues = {};
      retrivedData = {};
      history.push({ pathname: '/ccmparameter', state: { data: tstData } })
    }
  }
  const formik = useFormik({
    enableReinitialize: true,
    initialValues,
    validationSchema: Yup.object(validationSchemaActual),
    onSubmit: (values, { setErrors }) => {
      if (values.fieldValue === "null") values.fieldValue = null;
      if (values.dataType === "Checkbox") {values["selectedDataList"] = values.dataList; values.dataList = null ;values.fieldDefaultValue = null; }
      if (propsData.toggleaction === "ADD") {
        dispatch(addCCMParameter(values, (respData) => {
          const { responseStatus, referenceId, errorResponse = [] } = respData;
          let data = { responseMessage: "Add CCM Parameter request submitted for approval", referenceId };
          handleErrorMsg(errorResponse, responseStatus, setErrors, data)
        }));
      } else if (propsData.toggleaction === "EDIT") {
        dispatch(updateCCMParameter(values, (respData) => {
          const { responseStatus, referenceId, errorResponse = [] } = respData;
          let data = { responseMessage: "Update CCM Parameter request submitted for approval", referenceId };
          handleErrorMsg(errorResponse, responseStatus, setErrors, data)
        }));
      }
    },
    validate: values => {
      let errors = {};
      if ((values.dataType === 'Integer' || values.dataType === 'Decimal') && values.minimumValue && values.maximumValue) {
        if (values.minimumValue > values.maximumValue) {
          errors.minimumValue = 'Minimum value should not be greater than maximum value';
        }
        if (values.fieldValue < values.minimumValue || values.fieldValue > values.maximumValue) {
          errors.fieldValue = 'Parameter value should be between minimum and maximum values';
        }
      }
      if ((values.dataType === 'List' || values.dataType === 'Checkbox') && (values?.dataList === undefined || values?.dataList?.length === 0)) {
          errors.selectedDataList = 'Datalist should not be empty';
      }
      if (isChecbkBoxDataList(values)) {
        let obj = false
        obj = values.dataList.some((elem)=> elem.selected)
        if(obj === false){
          errors.selectedDataList = 'DataList must have at least one item selected.';
        }
      }
      return errors;
    }
  });
  useEffect(() => {
    if((formik.values.dataType === "List" || formik.values.dataType === "Checkbox")&& propsData.toggleaction !== "VIEW"){
      formik.setFieldValue('fieldValue', "null");}
  }, [formik.errors.fieldValue]);
  const handleSwitchChange = (name, value) => {
    if (name === "status") {
      formik.setFieldValue(name, value ? 'ACTIVE' : 'INACTIVE');
    } else {
      formik.setFieldValue(name, value);
    }
  }

  function goBack() {
    formik.resetForm();
    initialValues = {};
    retrivedData.addCcmParameter = {}
    retrivedData.updatePostCcmParameter = {};
    history.push("/ccmparameter");
  }

  const removeFromDataList = (e, idx) => {
    e.stopPropagation();
    formik.values.dataList.splice(idx, 1);
    formik.setFieldValue('dataList', [...formik.values.dataList]);
  }
  const changestatus = (e, idx) => {
    e.stopPropagation();
    formik.values.dataList[idx].selected = e.target.checked;
    formik.setFieldValue('dataList', [...formik.values.dataList]);
  }
  const optionList = [];
  const constructOptionList = () => {
    (formik.values.dataType==="List"&& formik.values.dataList && formik.values.dataList.map((elem, idx) => (
      optionList.push({
        label: (
          <div className="flexDivLabel">
            <div>{elem}</div>
            {propsData.toggleaction !== "VIEW" && <Image onClick={(e) => removeFromDataList(e, idx)} className="icon rightIcon" height={10} width={10} src={MinusIcon} />}
          </div>
        ), value: elem , isdisabled :true 
      })
    )))
  }
  constructOptionList()

  const optionCheckbox = [];
  const constructCheckBoxOptionList = () => {
    (formik.values.dataType==="Checkbox" && formik.values.dataList && formik.values.dataList.map((elem, idx) => (
      optionCheckbox.push({
        label: (
          <div className="flexDivLabel">
            <div className="flex">
                        <Switch
                        type="checkbox"
                        onChange={(e) => changestatus(e, idx)}
                        checked={elem.selected} 
                        disabled={propsData.toggleaction === "VIEW"}
                      />
            <div id={idx} >{elem.value}</div>
            </div>
            {propsData.toggleaction !== "VIEW" && <Image onClick={(e) => removeFromDataList(e, idx)} className="icon rightIcon" height={10} width={10} src={MinusIcon} />}
          </div>
        ), value: elem , isdisabled :true,
      })
    )))
  }
  constructCheckBoxOptionList();

  let title = propsData?.toggleaction?.toLowerCase();
  title = title[0]?.toUpperCase() + title.substring(1, title.length);
  return (
    <div className="addCcm mt-2">
      <div className="headertitle">
        <Image onClick={goBack} src={backIcon} className="icon" />
        <b>{getTitle( propsData, initialValues, title)}</b>
      </div>
            {errorDiv}

      <Form onSubmit={formik.handleSubmit}>
        {isEditMode(propsData)?
          (
            <Card className="cardbodystyle border-0">
              <Card.Body >
              {propsData.toggleaction !== "ADD" &&
                <Row className="mt-2 mr-2 ml-2">
                  <Col xs='2' sm='2' >
                    <div className=''>
                      <label htmlFor='fieldCode' className=''>Parameter Code </label>

                    </div>
                  </Col>
                  <Col xs='5' sm='5'>
                    <InputText
                      className={getClassName(formik, 'fieldCode')}
                      value={formik.values.fieldCode}
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                      disabled={true}
                      name='fieldCode'
                      placeholder='Enter Parameter Code'
                    />
                  </Col>
                </Row>
}
                <Row className="mt-2 mr-2 ml-2">
                  <Col xs='2' sm='2' >
                    <div className=''>
                      <label htmlFor='fieldName' className=''>Parameter Name </label>

                    </div>
                  </Col>
                  <Col xs='5' sm='5'>
                    <InputText
                      className={getClassName(formik, 'fieldName')}
                      value={formik.values.fieldName}
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                      disabled={propsData.toggleaction === "VIEW"}
                      name='fieldName'
                      placeholder='Enter Parameter Name'
                    />
                    {renderError(formik, 'fieldName')}
                  </Col>
                </Row>
                <Row className="mt-2 mr-2 ml-2">
                  <Col xs='2' sm='2' >
                    <div className=''>
                      <label htmlFor='fieldDescription' className=''>Parameter Description </label>
                    </div>
                  </Col>
                  <Col xs='5' sm='5'>
                    <InputText
                      as="textarea"
                      rows={3}
                      className={getClassName(formik, 'fieldDescription')}
                      value={formik.values.fieldDescription}
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                      disabled={propsData.toggleaction === "VIEW"}
                      name='fieldDescription'
                      placeholder='Enter Parameter Description'
                    />
                    {renderError(formik, 'fieldDescription')}
                  </Col>
                </Row>
                <Row className="mt-2 mr-2 ml-2">
                  <Col xs='2' sm='2' >
                    <div className=''>
                      <label htmlFor='dataType' className=''>Data Type </label>
                    </div>
                  </Col>
                  <Col xs='5' sm='5'>
                    <BDOSelect
                      name="dataType"
                      options={dataTypeList}
                      value={formik.values.dataType}
                      isDisabled={propsData.toggleaction === "VIEW"}
                      className={getClassNamefordType(propsData, getClassName, formik, props)}
                      placeholder={"Select Datatype"}
                      onChange={(e) => {
                        handleDataChange(formik, e.value , setNumber, setString , setDecimal)
                      }}
                    />
                    {renderError(formik, 'dataType')}
                  </Col>
                </Row>

                {
                  (formik.values.dataType !== 'List' && formik.values.dataType !== 'Checkbox')
                    && (<Row className="mt-2 mr-2 ml-2">
                      <Col xs='2' sm='2' >
                        <div className=''>
                          <label htmlFor='dataFormat' className=''>Parameter Data Format </label>
                        </div>
                      </Col>
                      <Col xs='5' sm='5'>
                        <InputText
                          className={getClassName(formik, 'dataFormat')}
                          value={formik.values.dataFormat}
                          onChange={formik.handleChange}
                          onBlur={formik.handleBlur}
                          disabled={propsData.toggleaction === "VIEW" || formik.values.dataType === "Time" || formik.values.dataType === "Date" || formik.values.dataType === "DateTime"}
                          name='dataFormat'
                          placeholder='Enter Parameter Data Format'
                        />
                      </Col>
                    </Row>
                    )
                }
                {
                  (formik.values.dataType !== 'List' && formik.values.dataType !== 'Checkbox')
                    && (
                      <Row className="mt-2 mr-2 ml-2">
                        <Col xs='2' sm='2' >
                          <div className=''>
                            <label htmlFor='fieldDefaultValue' className=''>Parameter default value </label>
                          </div>
                        </Col>
                        <Col xs='5' sm='5'>
                          <>
                            <FindInputType
                              dataType={formik.values.dataType}
                              handleChange={(e) => {
                                formik.handleChange(e)
                                formik.setFieldValue('fieldValue', e.target.value)
                              }}
                              onBlur={formik.handleBlur}
                              name={"fieldDefaultValue"}
                              placeholder={'Enter Default Value'}
                              dataObj={{ setFieldValue: formik.setFieldValue, values: formik.values }}
                              value={formik.values.fieldDefaultValue}
                              className={getClassName(formik, 'fieldDefaultValue')}
                              disabled={propsData.toggleaction === "VIEW"}
                            />
                            {renderError(formik, 'fieldDefaultValue')}
                          </>
                        </Col>
                      </Row>
                    )
                }
                {
                  (formik.values.dataType === 'Integer' || formik.values.dataType === 'Decimal')
                    && (
                      <>
                        <Row className="mt-2 mr-2 ml-2">
                          <Col xs='2' sm='2' >
                            <div className=''>
                              <label htmlFor='minimumValue' className=''>Minimum Value </label>
                            </div>
                          </Col>
                          <Col xs='5' sm='5'>
                            <InputText
                              type="number"
                              className={getClassName(formik, 'minimumValue')}
                              value={formik.values.minimumValue}
                              onChange={formik.handleChange}
                              onBlur={formik.handleBlur}
                              step={getStepVlaue(formik)}
                              disabled={propsData.toggleaction === "VIEW"}
                              name='minimumValue'
                              placeholder='Enter Minimum Value'
                            />
                            {renderError(formik, 'minimumValue')}
                          </Col>
                        </Row>
                        <Row className="mt-2 mr-2 ml-2">
                          <Col xs='2' sm='2' >
                            <div className=''>
                              <label htmlFor='maximumValue' className=''>Maximum Value</label>
                            </div>
                          </Col>
                          <Col xs='5' sm='5'>
                            <InputText
                              type="number"
                              className={getClassName(formik, 'maximumValue')}
                              value={formik.values.maximumValue}
                              onChange={formik.handleChange}
                              disabled={propsData.toggleaction === "VIEW"}
                              onBlur={formik.handleBlur}
                              step={getStepVlaue(formik)}
                              name='maximumValue'
                              placeholder='Enter Maximum Value'
                            />
                            {renderError(formik, 'maximumValue')}
                          </Col>
                        </Row>
                      </>
                    )
                }
                <Row className="mt-2 mr-2 ml-2">
                  <Col xs='2' sm='2' >
                    <div className=''>
                      <label htmlFor={getLabelValue(formik)} className=''>{getLabelValue(formik)}  </label>
                    </div>
                  </Col>
                  <Col xs='5' sm='5'>
                    <>
                      <FindInputType
                        dataType={formik.values.dataType}
                        handleChange={formik.handleChange}
                        name={getName(formik)}
                        onBlur={formik.handleBlur}
                        placeholder={'Enter Value'}
                        value={getFeildValue(formik)}
                        dataObj={{ setFieldValue: formik.setFieldValue, values: formik.values }}
                        className={getClassName(formik, getName(formik))}
                        disabled={propsData.toggleaction === "VIEW"}
                      />
                      {renderError(formik, getName(formik))}
                    </>
                  </Col>
                </Row>
                {
                  (formik.values.dataType === 'List'|| formik.values.dataType === 'Checkbox') && (
                    <Row className="mt-2 mr-2 ml-2">
                      <Col xs='2' sm='2' >
                        <div className=''>
                          <label htmlFor='selectedDataList' className=''>Datalist</label>
                        </div>
                      </Col>
                      <Col xs='5' sm='5'>
                        <BDOSelect
                          className={getClassName(formik, "selectedDataList")}
                          name="selectedDataList"
                          value={formik.values.selectedDataList}
                          onBlur={formik.handleBlur}
                          options={getOptionlist(formik,optionList,optionCheckbox)}
                          isOptionDisabled= {(option)=> option.isdisabled}
                        />
                        {propsData.toggleaction !== "VIEW" && renderError(formik, 'selectedDataList')}
                      </Col>
                    </Row>

                  )
                }
                <Row className="mt-2 mr-2 ml-2">
                  <Col xs='2' sm='2' >
                    <div className=''>
                      <label htmlFor='affectedModules' className=''>Affected Modules </label>
                    </div>
                  </Col>
                  <Col xs='5' sm='5'>
                    <InputText
                      className={getClassName(formik, 'affectedModules')}
                      value={formik.values.affectedModules}
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                      disabled={propsData.toggleaction === "VIEW"}
                      name='affectedModules'
                      placeholder='Enter Affected Modules'
                    />
                    {renderError(formik, 'affectedModules')}
                  </Col>
                </Row>
                <Row className="mt-2 mr-2 ml-2">
                  <Col xs='2' sm='2' >
                    <div className=''>
                      <label htmlFor='status' className=''>Status</label>
                    </div>
                  </Col>
                  <Col xs='5' sm='5'>
                    { renderStaus( propsData, formik, getClassName, handleSwitchChange )}
                    {renderError(formik, 'status')}
                  </Col>
                </Row>
                <Row className="mt-2 mr-2 ml-2">
                  <Col xs='2' sm='2' >
                    <div className=''>
                      <label htmlFor='reason' className=''>Reason</label>
                    </div>
                  </Col>
                  <Col xs='5' sm='5'>
                    <InputText
                      className={getClassName(formik, 'reason')}
                      value={formik.values.reason}
                      disabled={propsData.toggleaction === "VIEW"}
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                      name='reason'
                      placeholder='Enter Reason '
                    />
                    {renderError(formik, 'reason')}
                  </Col>
                </Row>
              </Card.Body>
            </Card>
          ) : (
            null
          )}
          {renderButton(propsData, goBack )}  
      </Form>
    </div>);
}

const renderButton = (propsData, goBack ) => (
    propsData?.toggleaction !== 'VIEW' &&
    (<div className='mt-4 float-right mb8'>
      <BDOButton onClick={goBack} title="Cancel" style1="style2 mr-3" />
      <BDOButton type="submit" title={propsData?.toggleaction === 'ADD'
        ? 'Add'
        : 'Save'} style1="style1" />
    </div>)
)