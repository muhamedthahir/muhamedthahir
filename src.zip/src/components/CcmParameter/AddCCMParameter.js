/* eslint-disable react-hooks/exhaustive-deps */
import React, { useEffect, useState } from "react";
import {
  Col,
  Form,
  Row,
  Card,
  Image,
} from 'react-bootstrap';
import { useDispatch, useSelector } from "react-redux";
import { useHistory } from 'react-router-dom';
import { useFormik } from 'formik';
import DateTimePicker from '../Global/DateTimePicker/DateTimePicker';
import PlusIcon from '../../assets/icons/plus_icon.svg'
import MinusIcon from '../../assets/icons/icon-delete.svg'
import * as Yup from 'yup';
import BDOToast from '../../components/Global/BDOToast/BDOToast';
import backIcon from '../../assets/icons/backIcon.png'
import BDOButton from '../Global/Button/BDOButton';
import InputText from '../Global/Input/InputText';
import Switch from '../Global/Switch/Switch';
import { retrieveCCMRecord, addCCMParameter, updateCCMParameter } from '../../actions/ccmparameter';
import BDOSelect from "../Global/Select/BDOSelect";
let initialValues = {};
let dataToBeEdited = {};
// to avoid nested ternary
const getClassNamefordType = (propsData, getClazzName, formik, props) => propsData.toggleaction === "VIEW" ? `disabled selectDropDown ${props.className} ${getClassName(formik, 'dataType')}` : `selectDropDown ${props.className} ${getClazzName(formik, 'dataType')}`

const getStepVlaue = ( formik ) => formik.values.dataType === "Decimal" ? "0.01" : 1

const getLabelValue = (formik) => formik.values.dataType !== "List" ? "Parameter Value" : "DataList Value"

const getName = formik => formik.values.dataType !== "List" ? "fieldValue" : "dataList"

const getFeildValue = formik => ((formik.values.fieldValue === undefined || formik.values.fieldValue === '') ? formik.values?.fieldDefaultValue : formik.values.fieldValue)

const getStatusValue = formik => formik.values.status === "ACTIVE" ? 'Active' : 'Inactive';

const getInputStatus = formik => (formik.values.status === "ACTIVE" || formik.values.status === "INACTIVE") ?formik.values.status[0].toUpperCase() + formik.values.status.substring(1, formik.values.status.length).toLowerCase() : "For Approval"

const renderStaus = ( propsData, formik, getClazzName, handleSwitchChange ) => (
  (propsData.toggleaction !== "VIEW") ?
    <div className="flex">
    <Switch
      type="switch"
      id={`custom-switch-${formik?.values?.fieldCode}`}
      disabled={propsData.toggleaction === "VIEW"}
      onChange={(e) => handleSwitchChange("status", e.target.checked)}
      checked={formik.values.status === "ACTIVE"}
    /><div>{getStatusValue(formik)}</div>
    </div> : <>
    <InputText
      className={getClassName(formik, 'status')}
      value={getInputStatus(formik)}
      disabled={propsData.toggleaction === "VIEW"}
      name='status'
    />  
  </>
)

const renderError = (formik, fieldName) => {
  return formik.errors[(fieldName)] ? (
    <span className='mb-1 error-text'>
      {formik.errors[(fieldName)]}
    </span>
  ) : null
}

const getClassName = (formik, fieldName) => {
  let returnMsg = "input-text";
  if(fieldName === "dataType"){
    returnMsg = "select";
  }
  if (formik.errors[(fieldName)]) return returnMsg + " error"
  return returnMsg
}
const dataTypeList = [
  { label: "String", value: "String" },
  { label: "Integer", value: "Integer" },
  { label: "Decimal", value: "Decimal" },
  { label: "Check Box", value: "Checkbox" },
  { label: "List", value: "List" },
  { label: "Time", value: "Time" },
  { label: "Date", value: "Date" },
  { label: "DateTime", value: "DateTime" },
];
const handleDataChange = (formik, val ,setNumber ,setString ,setDecimal) => {
  formik.setFieldValue('dataType', val)
  formik.setFieldValue('fieldValue', '')
  formik.setFieldValue('dataType', val)
  formik.setFieldValue('dataFormat', dataFormat[val])
  if (val === 'String') {
    formik.setFieldValue('fieldDefaultValue', '');
    formik.setFieldValue('maximumValue', '')
    formik.setFieldValue('minimumValue', '');
    setNumber(false);
    setDecimal(false);
  }
  if (val === 'List') {
    formik.setFieldValue('fieldValue', "null");
    formik.setFieldValue('maximumValue', '')
    formik.setFieldValue('minimumValue', '');
    setNumber(false);
    setDecimal(false);
  }
  else if (val === 'Integer') {
    formik.setFieldValue('fieldDefaultValue', 0)
    formik.setFieldValue('fieldValue', 0);
    formik.setFieldValue('maximumValue', '')
    formik.setFieldValue('minimumValue', '');
    setNumber(true);
    setDecimal(false);
  }
  else if (val === 'Decimal') {
    formik.setFieldValue('fieldDefaultValue', 0.00)
    formik.setFieldValue('fieldValue', 0.00);
    formik.setFieldValue('maximumValue', '')
    formik.setFieldValue('minimumValue', '');
    setNumber(false);
    setDecimal(true);
  } else {
    formik.setFieldValue('fieldDefaultValue', '');
    formik.setFieldValue('maximumValue', '')
    formik.setFieldValue('minimumValue', '');
    setNumber(false);
    setDecimal(false);
  }
}


const dataFormat = { String: '#AANNNLLL', Integer: 'NNNNNN', Decimal: '#N.NN', Date: 'MM-DD-YYYY', Time: 'HH:MM:SS(UTC)', DateTime: 'YYYY-MM-DDThh:mm:ss+0000 (UTC)' }
const formatFinder = { String: 'text', Checkbox: 'switch', Integer: 'number', Decimal: 'number', Date: 'date', Time: 'time', DateTime: 'date' }

const FindInputType = ({ dataType, className, handleChange, name, placeholder, value, dataObj, disabled }) => {

  const [ipText, setInputText] = useState();
  const [errorMsg, setErrorMessage] = useState();
  const type = formatFinder[dataType];
  let inputEle = '';
  if (dataType === 'DateTime' || dataType === 'Date' || dataType === 'Time') {
    let constructedDate;
    if (dataType === 'Time' && value) {
      constructedDate = new Date();
      constructedDate.setUTCHours(value.split(":")[0])
      constructedDate.setUTCMinutes(value.split(":")[1])
      constructedDate.setUTCSeconds(value.split(":")[2])
    }
    if (dataType === 'Date') {
      let splitList = value.split("-")
      constructedDate = new Date(Date.UTC(splitList[2], parseInt(splitList[0]) - 1, splitList[1]))
    }
    if (dataType === 'DateTime') {
      let [datesplitList , timesplitList=""] = value.split("T")
      let datelist = datesplitList.split("-")
      let timelist = timesplitList.split(":")
      constructedDate = new Date(Date.UTC(datelist[0], parseInt(datelist[1]) - 1, datelist[2]))
      constructedDate.setUTCHours(timelist[0])
      constructedDate.setUTCMinutes(timelist[1])
      constructedDate.setUTCSeconds(timelist[2])
    }
    const getDatatype = dateFormat => (dataType === 'DateTime'? "YYYY-MM-DD" :"MM-DD-YYYY")
    inputEle = (
      <DateTimePicker
        onChange={(e) => {
          if (dataType === 'Date' && e._d) {
            dataObj.setFieldValue(name,`${(e._d.getUTCMonth() + 1).toString().padStart(2, '0')}-${e._d.getUTCDate().toString().padStart(2, '0')}-${e._d.getUTCFullYear()}`)
            if (name === 'fieldDefaultValue') {
              dataObj.setFieldValue('fieldValue', `${(e._d.getUTCMonth() + 1).toString().padStart(2, '0')}-${e._d.getUTCDate().toString().padStart(2, '0')}-${e._d.getUTCFullYear()}`)
            }
          }
          else if (dataType === 'Time' && e._d) {
            dataObj.setFieldValue(name, `${e._d.getUTCHours().toString().padStart(2, '0')}:${e._d.getUTCMinutes().toString().padStart(2, '0')}:${e._d.getUTCSeconds().toString().padStart(2, '0')}`)
            if (name === 'fieldDefaultValue') {
              dataObj.setFieldValue('fieldValue', `${e._d.getUTCHours().toString().padStart(2, '0')}:${e._d.getUTCMinutes().toString().padStart(2, '0')}:${e._d.getUTCSeconds().toString().padStart(2, '0')}`)
            }
          }
          else if (e._d) {
            dataObj.setFieldValue(name, `${e._d.getUTCFullYear()}-${(e._d.getUTCMonth() + 1).toString().padStart(2, '0')}-${e._d.getUTCDate().toString().padStart(2, '0')}T${e._d.getUTCHours().toString().padStart(2, '0')}:${e._d.getUTCMinutes().toString().padStart(2, '0')}:${e._d.getUTCSeconds().toString().padStart(2, '0')}`)
            if (name === 'fieldDefaultValue') {
              dataObj.setFieldValue('fieldValue', `${e._d.getUTCFullYear()}-${(e._d.getUTCMonth() + 1).toString().padStart(2, '0')}-${e._d.getUTCDate().toString().padStart(2, '0')}T${e._d.getUTCHours().toString().padStart(2, '0')}:${e._d.getUTCMinutes().toString().padStart(2, '0')}:${e._d.getUTCSeconds().toString().padStart(2, '0')}`)
            }
          }
        }}
        initialValue={value}
        inputProps = {{ disabled: disabled}}
        value={constructedDate}
        dateFormat={dataType === 'Time' ? false : getDatatype(dataType)}
        timeFormat={dataType === "Date" ? false : "hh:mm A"}
        className={`datePicker ${className}`}
        key={`${name}_${dataType}`}
        utc={true}
      />
    )
  }
  else if (dataType === 'Checkbox') {
    inputEle = (
      <div className="flex gatewaySettingSpl">
        <Form.Group controlId="formBasicCheckbox" className="checkboxGrp">
          <Form.Check type="checkbox" checked={value === 'Yes'} className="yesCheck" name={name} label="Yes" onChange={(e) => dataObj.setFieldValue(name, 'Yes')} />
          <Form.Check type="checkbox" checked={value === 'No'} className="noCheck" name={name} label="No" onChange={(e) => dataObj.setFieldValue(name, 'No')} />
        </Form.Group>
      </div>
    )
  } else if (dataType === 'List' && !disabled) {
    inputEle = (
      <>
        <div className="flex">
          <InputText
            name='dataText'
            type="text"
            labelClassName={"labelClass"}
            valueClassName={"valueClass"}
            disabled={disabled}
            smValue={2}
            onChange={(e) => { setErrorMessage(''); setInputText(e.target.value) }}
            rowClassName="rowMargin"
            className={className}
            placeholder={"Enter Value For Data List"}
            value={ipText}
          />
          <Image className="plusIcon" src={PlusIcon} disabled={disabled} onClick={() => {
            if (ipText && ipText.length > 0) {
              setInputText('');
              let tempObj = (dataObj.values.dataList && [...dataObj.values.dataList]) || []
              if( tempObj.length < 50) {
                dataObj.setFieldValue('dataList', [...tempObj, ipText])
              } else {
                setErrorMessage('Datalist cannot add more than 50 values in the list') // this thing alone we need to discuss
              }
            } else {
              setErrorMessage('Please enter value')
            }
          }} />
        </div>
        <span className='mb-1 error-text'>
          {errorMsg}
        </span>
      </>
    )
  } else {
    inputEle = (
      <InputText
        name={name}
        type={type}
        onChange={handleChange}
        labelClassName={"labelClass"}
        valueClassName={"valueClass"}
        smValue={2}
        rowClassName="rowMargin"
        className={className}
        step={dataType === "Decimal" ? "0.01" : 1}
        disabled={disabled}
        placeholder={placeholder}
        value={value}
      />
    )
  }
  return (
    inputEle
  )
}

export default function AddCCMParameter(props) {
  const history = useHistory();
  const dispatch = useDispatch();

  let propsData = props?.location?.state;
  let retrivedData = useSelector(state => state.ccmparameter);
  useEffect(() => {
    if (propsData.toggleaction === 'EDIT' || propsData.toggleaction === 'VIEW') {
      dispatch(retrieveCCMRecord(propsData.datatochild.fieldCode));
    }
  }, []);
  const [isNumber, setNumber] = useState(false);
  const [, setString] = useState(false);
  const [isDecimal, setDecimal] = useState(false);
  const [toastState, setToastState] = useState(false);
  dataToBeEdited = retrivedData?.viewCcmParameter;
  let errorDiv = undefined;

  if (retrivedData?.addCcmParameter?.errorResponse) {
    errorDiv = (
      <BDOToast
        openState={toastState}
        onClose={()=>setToastState(false)}
        type={"warning"}
        bodyMessage={retrivedData?.addCcmParameter?.errorResponse?.errorDescription}
      />
    )
    window.scrollTo({
      top: 0,
      left: 0,
      behavior: "smooth",
  });
  }
  if (retrivedData?.updatePostCcmParameter?.errorResponse) {
    errorDiv = (
      <BDOToast
        openState={toastState}
        onClose={()=>{setToastState(false)}}
        type={"warning"}
        bodyMessage={retrivedData?.updatePostCcmParameter?.errorResponse?.errorDescription}
      />
    )
    window.scrollTo({
      top: 0,
      left: 0,
      behavior: "smooth",
  });
  }

  if (propsData && propsData.datatochild && dataToBeEdited !== undefined) {
    let dataToEdit = dataToBeEdited;
    initialValues = dataToEdit; //This is written to check and update the fields automatically without below lines
    initialValues.fieldCode = dataToEdit.fieldCode || '';
    initialValues.fieldName = dataToEdit.fieldName || '';
    initialValues.fieldValue = dataToEdit.fieldValue || '';
    initialValues.fieldDescription = dataToEdit.fieldDescription || '';
    initialValues.dataType = dataToEdit.dataType || '';
    initialValues.status = dataToEdit?.status;
    initialValues.affectedModules = dataToEdit.affectedModules || '';
    initialValues.reason = dataToEdit.reason || '';
  }
  if (!initialValues.status) {
    initialValues.status = "INACTIVE";
  }
  
  let validationSchemaActual = {
    fieldCode: Yup.string()
    .matches(/^[\w]*$/, 'Please enter valid code')
      .required('Required field'),
    fieldName: Yup.string()
      .matches(/^[A-Za-z0-9 _]*$/, 'Please enter valid name')
      .max(50, 'Must be 50 characters or less')
      .required('Required field'),
    fieldValue: Yup.string()
      .required('Required field'),
    fieldDescription: Yup.string()
      .max(200, 'Must be 200 characters or less')
      .required('Required field'),
    dataType: Yup.string().required('Required field'),
    // fieldDefaultValue: Yup.string()
    //   .max(50, 'Must be 50 characters or less')
    //   .required('Required field'),
    affectedModules: Yup.string()
      .max(200, 'Must be 200 characters or less')
      .required('Required field'),
    reason: Yup.string()
      .max(50, 'Must be 50 characters or less')
      .required('Required field'),
    status: Yup.string().required('Required field')
  };
  if( isDecimal ) {
    validationSchemaActual = {
        ...validationSchemaActual,
        maximumValue: Yup.number()
      .typeError("That doesn't look like a number")
      .max(99999, 'Must be 99999 or less')
      .required('Required field')
      .positive("Number can't be negative or 0"),
    minimumValue: Yup.number()
      .typeError("That doesn't look like a number")
      .positive("Number can't be negative or 0")
      .max(99999, 'Must be 99999 or less')
      .required('Required field'),
      fieldValue: Yup.number()
      .typeError("That doesn't look like a number")
      .positive("Number can't be negative or 0")
      .required('Required field'),
    }
  } else if( isNumber ) {
    validationSchemaActual = {
        ...validationSchemaActual,
        maximumValue: Yup.number()
        .typeError("That doesn't look like a number")
        .positive("Number can't be negative or 0")
        .max(99999, 'Must be 99999 or less')
        .integer("Number can't include a decimal point")
        .required('Required field'),
      minimumValue: Yup.number()
        .typeError("That doesn't look like a number")
        .positive("Number can't be negative or 0")
        .max(99999, 'Must be 99999 or less')
        .integer("Number can't include a decimal point")
        .required('Required field'),
      fieldValue: Yup.number()
      .typeError("That doesn't look like a number")
      .positive("Number can't be negative or 0")
      .integer("Number can't include a decimal point")
      .required('Required field'),
    }
  } else {
    validationSchemaActual = { ...validationSchemaActual }
  }

  const handleErrorMsg = ( errRes, resStatus, setErrors, tstData ) => {
    if (errRes) {
      setToastState(true)
      const { errorList = {} } = errRes
      setErrors(errorList );
    }
    if (resStatus === "200 OK") {
      initialValues = {};
      retrivedData = {};
      history.push({ pathname: '/ccmparameter', state: { data: tstData } })
    }
  }
  const formik = useFormik({
    enableReinitialize: true,
    initialValues,
    validationSchema: Yup.object(validationSchemaActual),
    onSubmit: (values, { setErrors }) => {
      if (values.fieldValue === "null") values.fieldValue = null;
      if (values.dataType === "Checkbox") {values["dataList"] = ["Yes", "No"]; values.fieldDefaultValue = null; }
      if (propsData.toggleaction === "ADD") {
        dispatch(addCCMParameter(values, (respData) => {
          const { responseStatus, referenceId, errorResponse = [] } = respData;
          let data = { responseMessage: "Add CCM Parameter request submitted for approval", referenceId };
          handleErrorMsg(errorResponse, responseStatus, setErrors, data)
        }));
      } else if (propsData.toggleaction === "EDIT") {
        dispatch(updateCCMParameter(values, (respData) => {
          const { responseStatus, referenceId, errorResponse = [] } = respData;
          let data = { responseMessage: "Update CCM Parameter request submitted for approval", referenceId };
          handleErrorMsg(errorResponse, responseStatus, setErrors, data)
        }));
      }
    },
    validate: values => {
      let errors = {};
      if ((values.dataType === 'Integer' || values.dataType === 'Decimal') && values.minimumValue && values.maximumValue) {
        if (values.minimumValue > values.maximumValue) {
          errors.minimumValue = 'Minimum value should not be greater than maximum value';
        }
        if (values.fieldValue < values.minimumValue || values.fieldValue > values.maximumValue) {
          errors.fieldValue = 'Parameter value should be between minimum and maximum values';
        }
      }
      return errors;
    }
  });
  useEffect(() => {
    if(formik.values.dataType === "List" && propsData.toggleaction !== "VIEW"){
      formik.setFieldValue('fieldValue', "null");}
  }, [formik.errors.fieldValue]);
  const handleSwitchChange = (name, value) => {
    if (name === "status") {
      formik.setFieldValue(name, value ? 'ACTIVE' : 'INACTIVE');
    } else {
      formik.setFieldValue(name, value);
    }
  }

  function goBack() {
    formik.resetForm();
    initialValues = {};
    retrivedData.addCcmParameter = {}
    retrivedData.updatePostCcmParameter = {};
    history.push("/ccmparameter");
  }

  const removeFromDataList = (e, idx) => {
    e.stopPropagation();
    formik.values.dataList.splice(idx, 1);
    formik.setFieldValue('dataList', [...formik.values.dataList]);
  }

  const optionList = [];
  (formik.values.dataList && formik.values.dataList.map((elem, idx) => (
    optionList.push({
      label: (
        <div className="flexDivLabel">
          <div>{elem}</div>
          {propsData.toggleaction !== "VIEW" && <Image onClick={(e) => removeFromDataList(e, idx)} className="icon rightIcon" height={10} width={10} src={MinusIcon} />}
        </div>
      ), value: elem , isdisabled :true 
    })
  )))
  let title = propsData?.toggleaction?.toLowerCase();
  title = title[0]?.toUpperCase() + title.substring(1, title.length);
  return (
    <div className="addCcm mt-2">
      <div className="headertitle">
        <Image onClick={goBack} src={backIcon} className="icon" />
        <b>{propsData?.toggleaction === 'ADD' ? `${title}  CCM Parameter` : `${initialValues.fieldCode}`}</b>
      </div>
            {errorDiv}

      <Form onSubmit={formik.handleSubmit}>
        {(propsData?.toggleaction === 'ADD' || (propsData?.toggleaction === 'EDIT') || (propsData?.toggleaction === 'VIEW')) ?
          (
            <Card className="cardbodystyle border-0">
              <Card.Body >
                <Row className="mt-2 mr-2 ml-2">
                  <Col xs='2' sm='2' >
                    <div className=''>
                      <label htmlFor='fieldCode' className=''>Parameter Code </label>

                    </div>
                  </Col>
                  <Col xs='5' sm='5'>
                    <InputText
                      className={getClassName(formik, 'fieldCode')}
                      value={formik.values.fieldCode}
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                      disabled={propsData.toggleaction !== "ADD"}
                      name='fieldCode'
                      placeholder='Enter Parameter Code'
                    />
                    {renderError(formik, 'fieldCode')}
                  </Col>
                </Row>
                <Row className="mt-2 mr-2 ml-2">
                  <Col xs='2' sm='2' >
                    <div className=''>
                      <label htmlFor='fieldName' className=''>Parameter Name </label>

                    </div>
                  </Col>
                  <Col xs='5' sm='5'>
                    <InputText
                      className={getClassName(formik, 'fieldName')}
                      value={formik.values.fieldName}
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                      disabled={propsData.toggleaction === "VIEW"}
                      name='fieldName'
                      placeholder='Enter Parameter Name'
                    />
                    {renderError(formik, 'fieldName')}
                  </Col>
                </Row>
                <Row className="mt-2 mr-2 ml-2">
                  <Col xs='2' sm='2' >
                    <div className=''>
                      <label htmlFor='fieldDescription' className=''>Parameter Description </label>
                    </div>
                  </Col>
                  <Col xs='5' sm='5'>
                    <InputText
                      as="textarea"
                      rows={3}
                      className={getClassName(formik, 'fieldDescription')}
                      value={formik.values.fieldDescription}
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                      disabled={propsData.toggleaction === "VIEW"}
                      name='fieldDescription'
                      placeholder='Enter Parameter Description'
                    />
                    {renderError(formik, 'fieldDescription')}
                  </Col>
                </Row>
                <Row className="mt-2 mr-2 ml-2">
                  <Col xs='2' sm='2' >
                    <div className=''>
                      <label htmlFor='dataType' className=''>Data Type </label>
                    </div>
                  </Col>
                  <Col xs='5' sm='5'>
                    <BDOSelect
                      name="dataType"
                      options={dataTypeList}
                      value={formik.values.dataType}
                      isDisabled={propsData.toggleaction === "VIEW"}
                      className={getClassNamefordType(propsData, getClassName, formik, propsData.toggle)}
                      placeholder={"Select Datatype"}
                      onChange={(e) => {
                        handleDataChange(formik, e.value , setNumber, setString , setDecimal)
                      }}
                    />
                    {renderError(formik, 'dataType')}
                  </Col>
                </Row>

                {
                  (formik.values.dataType !== 'List' && formik.values.dataType !== 'Checkbox')
                    && (<Row className="mt-2 mr-2 ml-2">
                      <Col xs='2' sm='2' >
                        <div className=''>
                          <label htmlFor='dataFormat' className=''>Parameter Data Format </label>
                        </div>
                      </Col>
                      <Col xs='5' sm='5'>
                        <InputText
                          className={getClassName(formik, 'dataFormat')}
                          value={formik.values.dataFormat}
                          onChange={formik.handleChange}
                          onBlur={formik.handleBlur}
                          disabled={propsData.toggleaction === "VIEW" || formik.values.dataType === "Time" || formik.values.dataType === "Date" || formik.values.dataType === "DateTime"}
                          name='dataFormat'
                          placeholder='Enter Parameter Data Format'
                        />
                      </Col>
                    </Row>
                    )
                }
                {
                  (formik.values.dataType !== 'List' && formik.values.dataType !== 'Checkbox')
                    && (
                      <Row className="mt-2 mr-2 ml-2">
                        <Col xs='2' sm='2' >
                          <div className=''>
                            <label htmlFor='fieldDefaultValue' className=''>Parameter default value </label>
                          </div>
                        </Col>
                        <Col xs='5' sm='5'>
                          <>
                            <FindInputType
                              dataType={formik.values.dataType}
                              handleChange={(e) => {
                                formik.handleChange(e)
                                formik.setFieldValue('fieldValue', e.target.value)
                              }}
                              onBlur={formik.handleBlur}
                              name={"fieldDefaultValue"}
                              placeholder={'Enter Default Value'}
                              dataObj={{ setFieldValue: formik.setFieldValue, values: formik.values }}
                              value={formik.values.fieldDefaultValue}
                              className={getClassName(formik, 'fieldDefaultValue')}
                              disabled={propsData.toggleaction === "VIEW"}
                            />
                            {renderError(formik, 'fieldDefaultValue')}
                          </>
                        </Col>
                      </Row>
                    )
                }
                {
                  (formik.values.dataType === 'Integer' || formik.values.dataType === 'Decimal')
                    && (
                      <>
                        <Row className="mt-2 mr-2 ml-2">
                          <Col xs='2' sm='2' >
                            <div className=''>
                              <label htmlFor='minimumValue' className=''>Minimum Value </label>
                            </div>
                          </Col>
                          <Col xs='5' sm='5'>
                            <InputText
                              type="number"
                              className={getClassName(formik, 'minimumValue')}
                              value={formik.values.minimumValue}
                              onChange={formik.handleChange}
                              onBlur={formik.handleBlur}
                              step={getStepVlaue(formik)}
                              disabled={propsData.toggleaction === "VIEW"}
                              name='minimumValue'
                              placeholder='Enter Minimum Value'
                            />
                            {renderError(formik, 'minimumValue')}
                          </Col>
                        </Row>
                        <Row className="mt-2 mr-2 ml-2">
                          <Col xs='2' sm='2' >
                            <div className=''>
                              <label htmlFor='maximumValue' className=''>Maximum Value</label>
                            </div>
                          </Col>
                          <Col xs='5' sm='5'>
                            <InputText
                              type="number"
                              className={getClassName(formik, 'maximumValue')}
                              value={formik.values.maximumValue}
                              onChange={formik.handleChange}
                              disabled={propsData.toggleaction === "VIEW"}
                              onBlur={formik.handleBlur}
                              step={getStepVlaue(formik)}
                              name='maximumValue'
                              placeholder='Enter Maximum Value'
                            />
                            {renderError(formik, 'maximumValue')}
                          </Col>
                        </Row>
                      </>
                    )
                }
                <Row className="mt-2 mr-2 ml-2">
                  <Col xs='2' sm='2' >
                    <div className=''>
                      <label htmlFor={getLabelValue(formik)} className=''>{getLabelValue(formik)}  </label>
                    </div>
                  </Col>
                  <Col xs='5' sm='5'>
                    <>
                      <FindInputType
                        dataType={formik.values.dataType}
                        handleChange={formik.handleChange}
                        name={getName(formik)}
                        onBlur={formik.handleBlur}
                        placeholder={'Enter Value'}
                        value={getFeildValue(formik)}
                        dataObj={{ setFieldValue: formik.setFieldValue, values: formik.values }}
                        className={getClassName(formik, getName(formik))}
                        disabled={propsData.toggleaction === "VIEW"}
                      />
                      {renderError(formik, getName(formik))}
                    </>
                  </Col>
                </Row>
                {
                  (formik.values.dataType === 'List') && (
                    <Row className="mt-2 mr-2 ml-2">
                      <Col xs='2' sm='2' >
                        <div className=''>
                          <label htmlFor='fieldValue' className=''>Datalist</label>
                        </div>
                      </Col>
                      <Col xs='5' sm='5'>
                        <BDOSelect
                          name="fieldValue"
                          className={propsData.toggleaction === "VIEW" && 'disabled'}
                          value={formik.values.fieldValue}
                          onBlur={formik.handleBlur}
                          options={optionList}
                          isOptionDisabled= {(option)=> option.isdisabled}
                        />
                        {propsData.toggleaction !== "VIEW" && renderError(formik, 'fieldValue')}
                      </Col>
                    </Row>

                  )
                }
                <Row className="mt-2 mr-2 ml-2">
                  <Col xs='2' sm='2' >
                    <div className=''>
                      <label htmlFor='affectedModules' className=''>Affected Modules </label>
                    </div>
                  </Col>
                  <Col xs='5' sm='5'>
                    <InputText
                      className={getClassName(formik, 'affectedModules')}
                      value={formik.values.affectedModules}
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                      disabled={propsData.toggleaction === "VIEW"}
                      name='affectedModules'
                      placeholder='Enter Affected Modules'
                    />
                    {renderError(formik, 'affectedModules')}
                  </Col>
                </Row>
                <Row className="mt-2 mr-2 ml-2">
                  <Col xs='2' sm='2' >
                    <div className=''>
                      <label htmlFor='status' className=''>Status</label>
                    </div>
                  </Col>
                  <Col xs='5' sm='5'>
                    { renderStaus( propsData, formik, getClassName, handleSwitchChange )}
                    {renderError(formik, 'status')}
                  </Col>
                </Row>
                <Row className="mt-2 mr-2 ml-2">
                  <Col xs='2' sm='2' >
                    <div className=''>
                      <label htmlFor='reason' className=''>Reason</label>
                    </div>
                  </Col>
                  <Col xs='5' sm='5'>
                    <InputText
                      className={getClassName(formik, 'reason')}
                      value={formik.values.reason}
                      disabled={propsData.toggleaction === "VIEW"}
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                      name='reason'
                      placeholder='Enter Reason '
                    />
                    {renderError(formik, 'reason')}
                  </Col>
                </Row>
              </Card.Body>
            </Card>
          ) : (
            null
          )}
        {propsData?.toggleaction !== 'VIEW' &&
          (<div className='mt-4 float-right mb8'>
            <BDOButton onClick={goBack} title="Cancel" style1="style2 mr-3" />
            <BDOButton type="submit" title={propsData?.toggleaction === 'ADD'
              ? 'Add'
              : 'Save'} style1="style1" />
          </div>)}
      </Form>
    </div>);
}

