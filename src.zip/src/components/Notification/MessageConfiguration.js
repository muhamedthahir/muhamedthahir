import React from 'react';
import DateTimePicker from '../../components/Global/DateTimePicker/DateTimePicker'
import DetailsLabel from '../GatewayManagement/DetailsLabel';
import InputText from '../../components/Global/Input/InputText';
import Switch from '../../components/Global/Switch/Switch';


const MessageConfiguration = (props) => {
    const {
        setFieldValue, value, errors, renderError,
        handleChange, getClassName, handleBlur, disabled
    } = props;
    return(
        <>
            <DetailsLabel 
            labelClassName="bodyRowLabel" 
            labelName="Start Date and Time" 
            valueName={
                <>
                    <DateTimePicker
                        onClose={(e) => {
                            setFieldValue('startDate', e._d && e._d.toUTCString().replace("GMT","UTC"))
                        }}
                        initialValue={value.startDate && value.startDate.replace("UTC","GMT")} 
                        value={value.startDate && new Date(value.startDate.replace("UTC","GMT"))}
                        className={`datePicker`}
                        placeholder={"Enter Start Date and Time"}
                        key={`startDate`}
                        utc={true}
                        isDisabled={disabled}
                    />
                    {renderError(errors, 'startDate')}
                </>
            }
            valueClassName="bodyRowValue"
            rowClassName="rowMargin"
        />
        <DetailsLabel 
            labelClassName="bodyRowLabel" 
            labelName="End Date and Time" 
            valueName={
                <>
                    <DateTimePicker
                        onClose={(e) => {
                            setFieldValue('endDate', e._d && e._d.toUTCString().replace("GMT","UTC"))
                        }}
                        initialValue={value.endDate && new Date(value.endDate.replace("UTC","GMT"))} 
                        value={value.endDate && new Date(value.endDate.replace("UTC","GMT"))}
                        placeholder={"Enter End Date and Time"}
                        className={`datePicker`}
                        key={`endDate`}
                        utc={true}
                        isDisabled  ={disabled}
                    />
                    {renderError(errors, 'endDate')}
                </>
            }
            valueClassName="bodyRowValue"
            rowClassName="rowMargin"
        />
        <DetailsLabel 
            labelClassName="bodyRowLabel" 
            labelName="CCM BOP" 
            valueName={
                <>
                   <Switch
                        type="switch"
                        name="ccmBop" 
                        id="ccmBop"
                        defaultChecked={value.ccmBop}
                        onChange={handleChange}
                        onBlur={handleBlur}
                        disabled={disabled}
                    />
                    {renderError(errors, 'providerCode')}
                </>
            }
            valueClassName="bodyRowValue"
            rowClassName="rowMargin"
        />
        <DetailsLabel 
            labelClassName="bodyRowLabel" 
            labelName="CCM API" 
            valueName={
                <>
                   <Switch
                        type="switch"
                        name="ccmApi" 
                        id="ccmApi"
                        checked={value.ccmApi}
                        onChange={handleChange}
                        onBlur={handleBlur}
                        disabled={disabled}
                    />
                    {renderError(errors, 'providerCode')}
                </>
            }
            valueClassName="bodyRowValue"
            rowClassName="rowMargin"
        />
        <DetailsLabel 
            labelClassName="bodyRowLabel" 
            labelName="Provider Code" 
            valueName={
                <>
                   <InputText
                        name="providerCode" 
                        value={value.providerCode|| ''} 
                        onChange={handleChange}
                        className={`feildLabel textArea ${getClassName(errors, 'providerCode')}`} 
                        placeholder="Enter Provider Code"
                        onBlur={handleBlur}
                        disabled={disabled}
                    />
                    {renderError(errors, 'providerCode')}
                </>
            }
            valueClassName="bodyRowValue"
            rowClassName="rowMargin"
        />
        <DetailsLabel 
            labelClassName="bodyRowLabel" 
            labelName="Gateway Code" 
            valueName={
                <>
                   <InputText
                        name="gatewayCode" 
                        value={value.gatewayCode|| ''} 
                        onChange={handleChange}
                        className={`feildLabel textArea ${getClassName(errors, 'gatewayCode')}`} 
                        placeholder="Enter Gateway Code"
                        onBlur={handleBlur}
                        disabled={disabled}
                    />
                    {renderError(errors, 'gatewayCode')}
                </>
            }
            valueClassName="bodyRowValue"
            rowClassName="rowMargin"
        />
        <DetailsLabel 
            labelClassName="bodyRowLabel" 
            labelName="Description" 
            valueName={
                <>
                   <InputText
                        name="description" 
                        value={value.description|| ''} 
                        onChange={handleChange}
                        className={`feildLabel textArea ${getClassName(errors, 'description')}`} 
                        placeholder="Enter Description"
                        onBlur={handleBlur}
                        disabled={disabled}
                    />
                    {renderError(errors, 'description')}
                </>
            }
            valueClassName="bodyRowValue"
            rowClassName="rowMargin"
        />
        <DetailsLabel 
            labelClassName="bodyRowLabel" 
            labelName="Reason" 
            valueName={
                <>
                    <InputText
                        name="reason" 
                        value={value.reason|| ''} 
                        onChange={handleChange} 
                        disabled={disabled}
                        className={`feildLabel textArea ${getClassName(errors, 'reason')}`} 
                        placeholder="Enter Reason"
                        onBlur={handleBlur}
                    />
                    {renderError(errors, 'reason')}
                </>
            }
            valueClassName="bodyRowValue"
            rowClassName="rowMargin"
        />
    </>
    )
}

export default MessageConfiguration;
