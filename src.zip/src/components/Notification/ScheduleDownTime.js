import React, { useState, useEffect, useRef } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Link, useHistory } from "react-router-dom";
import { retriveScheduleDowntime } from '../../actions/notification';
import {
    Image, Form, Card, Container
} from 'react-bootstrap';
import BDOButton from '../Global/Button/BDOButton';
import MessageConfiguration from './MessageConfiguration';
import BDOCkeditor from '../Global/BDOCkeditor/BDOCkeditor';
import DetailsLabel from '../GatewayManagement/DetailsLabel';
import InputText from '../../components/Global/Input/InputText';
import backIcon from '../../assets/icons/backIcon.png'
import './style/scheduleDowntime.scss';
import { Formik } from 'formik';
import * as Yup from 'yup';

const renderError = ( errors, paramname) => (
    errors[(paramname)]? (
      <span className='mb-1 error-text'>
        {errors[(paramname)]}
      </span>
    ) : null
  )
  
  const getClassName = (errors, paramname) => {
    let returnMsg = "input-text";
    if( errors[(paramname)]) return returnMsg+" error"
    return returnMsg
  }

function ScheduleDowntime(props) {
    const dispatch = useDispatch();
    const ckeditorRef = useRef();
    const history = useHistory();
    const retData = useSelector( states => states.notificationReducer);
    const {  match: {params: { id }}} = props;
    let { viewDowntime={} }  = retData;
    const { data={}, errorResponse} = viewDowntime;
    const [ notificationData=(viewDowntime.data || {}) ] = useState();
    let errorDiv = '';
    if( errorResponse) {
        errorDiv = (
            <span>{errorResponse.errorDescription}</span>
        )
    }
    const { location : { state={} }} =props;
    const { action= '' } = state;
    const isView = action === 'view'
    useEffect(() => {
        if( id !== 'add') {
            dispatch(retriveScheduleDowntime(id))
        }
    },[])
    const goBack = () => {
        viewDowntime.data  = undefined;
        history.push('/notification/downtime');
    }

    const handleNotificationSubmit = () => {
        console.log('asdsa');
    }
    const validationSchema = {
        subject: Yup.string().required('Required field'),
        startDate: Yup.string().required('Required field'),
        messageContent: Yup.string().required('Required field'),
        endDate: Yup.string().required('Required field'),
        reason: Yup.string().required('Required field'),
    }

    const  { 
        messageContent 
    } = data;
    return (
        <div className="downtimeNotification">
            <div className="headerBlock">
                <div>
                    <Link onClick={() => goBack()}>
                        <Image src={backIcon}  className="icon"/>
                    </Link>
                    <b>Schedule Downtime Notification</b>
                </div>
            </div>
            <div>
                <Formik
                    initialValues={{...notificationData, ccmBop: false, ccmApi : false}}
                    enableReinitialize
                    validationSchema={Yup.object().shape(validationSchema)}
                    onSubmit={(values, actions) => {
                        console.log('act', values, actions)
                        handleNotificationSubmit();
                    }}
                >
                {({ 
                    errors, touched, values, handleChange,
                    setFieldValue, handleBlur, handleSubmit
                }) => (
                    <Form onSubmit={handleSubmit}>
                        <div className="messageDetails">
                            <Card className="mb16">
                                <Card.Body>
                                    <div className="cardHeader">
                                        <Card.Title className="cardTitle">Message Configuration</Card.Title>
                                    </div>
                                    <Card.Text>
                                        <Container>
                                            <MessageConfiguration 
                                                setFieldValue={setFieldValue}
                                                value={values}
                                                errors={errors} 
                                                renderError={renderError}
                                                handleChange={handleChange}
                                                getClassName={getClassName}
                                                handleBlur={handleBlur}
                                                disabled={isView}
                                            />
                                        </Container>
                                    </Card.Text>
                                </Card.Body>
                            </Card>
                            <Card>
                                <Card.Body>
                                    <div className="cardHeader">
                                        <Card.Title className="cardTitle">Message Details</Card.Title>
                                    </div>
                                    <Card.Text>
                                        <Container>
                                            <DetailsLabel 
                                                labelClassName="bodyRowLabel" 
                                                labelName="Recipient" 
                                                valueName={
                                                    <>
                                                        <InputText
                                                            name="recipient" 
                                                            value={values.recipient|| ''} 
                                                            onChange={handleChange}
                                                            className={`feildLabel textArea ${getClassName(errors, 'recipient')}`} 
                                                            placeholder="Enter Recipient"
                                                            onBlur={handleBlur}
                                                            disabled={isView}
                                                        />
                                                        {renderError(errors, 'recipient')}
                                                    </>
                                                }
                                                valueClassName="bodyRowValue"
                                                rowClassName="rowMargin"
                                            />
                                            <DetailsLabel 
                                                labelClassName="bodyRowLabel" 
                                                labelName="Subject" 
                                                valueName={
                                                    <>
                                                        <InputText
                                                            name="subject" 
                                                            value={values.subject|| ''} 
                                                            onChange={handleChange}
                                                            className={`feildLabel textArea ${getClassName(errors, 'subject')}`} 
                                                            placeholder="Enter Subject"
                                                            onBlur={handleBlur}
                                                            disabled={isView}
                                                        />
                                                        {renderError(errors, 'subject')}
                                                    </>
                                                }
                                                valueClassName="bodyRowValue"
                                                rowClassName="rowMargin"
                                            />
                                        </Container>
                                    </Card.Text>
                                </Card.Body>
                            </Card>
                        </div>
                        <div className="messageContent">
                        <Card>
                            <Card.Body>
                                <div className="cardHeader">
                                    <Card.Title className="cardTitle">Message Body</Card.Title>
                                </div>
                                <Card.Text>
                                    <Container className="pl0">
                                        <BDOCkeditor 
                                            innerRef={ckeditorRef}
                                            initData={messageContent}
                                            onChange={(e) => {                                              
                                                setFieldValue('messageContent',e.editor.getData())
                                            }}
                                            className={getClassName(errors, 'messageContent')}
                                        />
                                        {renderError(errors, 'messageContent')}
                                    </Container>
                                </Card.Text>
                            </Card.Body>
                        </Card>
                        </div>
                        {!isView?
                            (<div className="recordBtnBlock">
                                <BDOButton variant="secondary" onClick={() => goBack()}>Cancel</BDOButton>
                                <BDOButton variant="primary" onClick={handleSubmit} >Save</BDOButton>
                            </div>):''
                        } 
                    </Form>
                )}
                </Formik>
            </div>
        </div>
    )

}

export default ScheduleDowntime;
