/* eslint-disable react-hooks/exhaustive-deps */
import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from "react-redux";
import {
    Card, Spinner, Image
} from 'react-bootstrap';
import { Link , useHistory} from 'react-router-dom';
import DataTable from '../Global/DataTable/DataTable';
import BDOToast from '../Global/BDOToast/BDOToast';
import EditIcon from '../../assets/icons/icon-edit-outline.svg';
import { retrieveAllDowntimeNotification }  from '../../actions/notification';
import './style/viewAllSchedule.scss';

const alphaNumericSorting = (frstValue, scndValue, colId, desc=false) => {
    if( frstValue && scndValue ){
        if( !desc ) return frstValue.localeCompare(scndValue)
        return (-1 *(scndValue.localeCompare(frstValue)))
    }
}


const sortByElement = ( rowA, rowB, colId, desc) => {
    const findFn = ( entry ) => entry.column && (entry.column.id ===  colId)
    const foundAData = rowA.cells.find(findFn);
    const foundBData = rowB.cells.find(findFn);
    const aValue =  typeof rowA.cells[0] !== "function" && foundAData && foundAData.value.props.children;
    const bValue =  typeof rowB.cells[0] !== "function" && foundBData && foundBData.value.props.children;
    return alphaNumericSorting( aValue, bValue, colId, desc)
}

const subjectDiv = ( rowData) => {
    return(
        <div className="flex">
            <span className="subjec">{rowData.subject} </span>
            -
            <div className="message">{rowData.message}</div>
        </div>
    )
}

const actionDiv = (rowData, history) => {
    return (
        <Image src={EditIcon} className="icon" />
    )
}

function ViewAllScheduleTime(props) { 
    const { isupdate } = props;
    const dispatch = useDispatch();
    const history = useHistory();
    const retData = useSelector( state => state.notificationReducer);
    let { viewAllDowntime=[] }  = retData;
    const { notificationList , totalPages=1, errorResponse} = viewAllDowntime;
    const [ isPageChanged, movePage ] = useState(false)
    const [ toastData, setToastData] = useState({});
    let errorDiv = '';
    if( errorResponse) {
        errorDiv = (
        <span>{errorResponse.errorDescription}</span>
        )
    }
    useEffect(() => {
        dispatch(retrieveAllDowntimeNotification(`page=${1}&size=${10}`));         
    }, []);

    let [ localData=notificationList ] = useState();
   
    let columns = [
        {
            Header: 'From',
            accessor: 'from',
            selector: 'from',
            sortType: 'basic',
        },
        {
            Header: 'Subject',
            accessor: 'subject',
            disableSortBy: true
        },
        {
            Header: 'Received On',
            accessor: 'receivedDate',
            sortType:( rowA, rowB, colId, desc ) => {
                return sortByElement(rowA, rowB, colId, desc)
            }
        },
        {
            Header: 'Action',
            accessor: 'action',
            disableSortBy: true
        }
    ];
    if( isupdate ) {
        columns = [ 
            ...columns,  {
            Header: 'Actions',
            accessor: 'actions',
            disableSortBy: true,
            }
        ];
    }

    const handleServerSidePagination = (pageNo, pageSize) => {
        dispatch(retrieveAllDowntimeNotification(`page=${pageNo}&size=${pageSize}`));
    };
    const linkDiv = (rowData) => <Link  to={{
            pathname: `/gatewaymanagment/${rowData.gatewayCode}`,
            state: { action: 'view'}
        }}>{rowData.name}</Link>;
    
    const localObj = localData && localData.map((ele) => {
            return {
                ...ele,
                subject: subjectDiv(ele),
                action: actionDiv(ele, history),
                className: ele.isRead?"boldRow":""
            }
        });
    return(
        <div className="downtimeNotification">
            <div className="headerBlock">
                <div>
                    <b>Notifications</b>
                </div>
                <div className="buttonBlock">
                </div>
            </div>
            {
                toastData.toastState && (
                    <BDOToast 
                        openState={toastData.toastState}
                        type={toastData.toastType}
                        bodyMessage={toastData.toastMessage}
                        onClose={() => setToastData({})} 
                    />
                )
            }
            <div className="tableBlock">
                <Card>
                    <Card.Body>
                        <div  className="mb10">
                            <b className="header6">Downtime Notifications</b>
                        </div>
                        <div className="dataBlock">
                            {
                                (localObj !== undefined || errorResponse)
                                ?  (
                                <DataTable 
                                    columns={columns}
                                    data={localObj || []}
                                    showPagination={true}
                                    handleServerSidePagination={handleServerSidePagination}
                                    errorDiv={errorDiv}
                                    pageProperty={{ totalPages, isPageChanged, movePage: (val) => movePage(val) }}
                                />):(
                                    <div className="alignCenter">
                                        <Spinner animation="border" />
                                    </div>
                                )
                            }
                        </div>
                    </Card.Body>
                </Card>
            </div>

        </div>
    )
}
export default ViewAllScheduleTime;
