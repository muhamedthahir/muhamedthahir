/* eslint-disable react-hooks/exhaustive-deps */
import React, { useEffect, useState, useRef } from 'react';
import { useDispatch, useSelector } from "react-redux";
import {
    Card, Spinner, Image
} from 'react-bootstrap';
import { useHistory} from 'react-router-dom';
import BDOButton from '../Global/Button/BDOButton';
import DataTable from '../Global/DataTable/DataTable';
import BDOToast from '../Global/BDOToast/BDOToast';
import EditIcon from '../../assets/icons/icon-edit-outline.svg';
import DeleteIcon from "../../assets/icons/icon-delete.svg";
import NotificationModalBody from './NotificationModalBody';
import { retrieveAllDowntimeNotification, updateNotification }  from '../../actions/notification';
import './style/viewAllSchedule.scss';
import BDOModal from '../Global/BDOModal/BDOModal';

const subjectDiv = ( rowData, history, messageWidth) => {
    return(
        <div className="flex">
            <span 
                onClick={() => {
                    history.push({
                        pathname: `/notification/viewdowntime/${rowData.id}`,
                        state: {action: 'view'}
                    })
                }} 
                className="subjec"
            >
                {rowData.subject}
             </span>
            -
            <div className="message" style={{ width: messageWidth+'px'}}>{rowData.message}</div>
        </div>
    )
}

const actionDiv = (rowData, history, deleteNotification) => {
    return (
        <div className="flex">
            <Image 
                src={EditIcon}
                className="icon"
                onClick={() => history.push(`/notification/viewdowntime/${rowData.id}`)}
            />
            <Image 
                src={DeleteIcon}
                className="icon"
                onClick={() => deleteNotification(rowData)}
            />
        </div>
    )
}

function ViewAllScheduleTime(props) { 
    const { isupdate } = props;
    const dispatch = useDispatch();
    const history = useHistory();
    const retData = useSelector( state => state.notificationReducer);
    let { viewAllDowntime=[] }  = retData;
    const { notificationList , totalPages=1, errorResponse} = viewAllDowntime;
    const [ isPageChanged, movePage ] = useState(false)
    const [ toastData, setToastData] = useState({});
    const [ modalData, setModalData] = useState({});
    const [ messageWidth, setMessageWidth ] = useState();
    const formIkRef = useRef();
    let errorDiv = '';
    if( errorResponse) {
        errorDiv = (
        <span>{errorResponse.errorDescription}</span>
        )
    }
    useEffect(() => {
        dispatch(retrieveAllDowntimeNotification(`page=${1}&size=${10}`)); 
        const { location: { state={}}} = props;
        const { toastState, toastMessage, toastType } = state || {};
        if( toastState ) {
            setToastData({
                toastState: toastState,
                toastMessage: toastMessage ,
                toastType: toastType
            })
            window.scrollTo({
                top: 0,
                left: 0,
                behavior: "smooth",
            })
        }        
    }, []);
    useEffect(() => {
        const width = document.getElementById("notifier") && document.getElementById("notifier").offsetWidth;
        const calmessageWidth = (45 / 100) * width;
        if (messageWidth !== calmessageWidth) {
            setMessageWidth(calmessageWidth)
        }
    })

    let [ localData=notificationList ] = useState();
   
    let columns = [
        {
            Header: 'From',
            accessor: 'from',
            selector: 'from',
            sortType: 'basic',
        },
        {
            Header: 'Subject',
            accessor: 'subject',
            disableSortBy: true
        },
        {
            Header: 'Received On',
            accessor: 'receivedDate',
            sortType: 'basic',
        },
        {
            Header: 'Action',
            accessor: 'action',
            disableSortBy: true
        }
    ];
    if( isupdate ) {
        columns = [ 
            ...columns,  {
            Header: 'Actions',
            accessor: 'actions',
            disableSortBy: true,
            }
        ];
    }

    const deleteNotification = ( rowData ) => {
        setModalData({ state: true, ...rowData})
    }

    const handleServerSidePagination = (pageNo, pageSize) => {
        dispatch(retrieveAllDowntimeNotification(`page=${pageNo}&size=${pageSize}`));
    };
    
    const localObj = localData && localData.map((ele) => {
            return {
                ...ele,
                subject: subjectDiv(ele, history, messageWidth),
                action: actionDiv(ele, history, deleteNotification),
                className: ele.isRead?"boldRow":""
            }
        });
    
    const handleOnChangeStatus = (reqObj) => {
        dispatch(
            updateNotification(reqObj, (respData) => {
            const {
               reference_number,
            } = respData;
            setToastData({
                toastState: true,
                toastMessage: `Notification deleted. Reference No: ${reference_number}` ,
                toastType: "success"
            });
            closeModal();
            dispatch(retrieveAllDowntimeNotification(`page=1&size=10`));
            window.scrollTo({
                top: 0,
                left: 0,
                behavior: "smooth",
            });
            })
        );
    };
    
    const closeModal = () => {
        setModalData({});
    };

    const modalFooterContent = (
        <div>
            <BDOButton variant="secondary" onClick={closeModal}>
                Cancel
            </BDOButton>
            <BDOButton
                variant="danger"
                onClick={() => formIkRef.current.handleSubmit()}
            >
                Delete
            </BDOButton>
        </div>
    )
    return(
        <div className="downtimeNotification" id="notifier">
            <div className="headerBlock">
                <div>
                    <b>Notifications</b>
                </div>
                <div className="buttonBlock">
                    <BDOButton
                        title="Add Downtime Notification"
                        onClick={() => history.push('/notification/viewdowntime/add')}
                        variant="primary"
                    />
                </div>
            </div>
            {
                toastData.toastState && (
                    <BDOToast 
                        openState={toastData.toastState}
                        type={toastData.toastType}
                        bodyMessage={toastData.toastMessage}
                        onClose={() => setToastData({})} 
                    />
                )
            }
            {
                modalData.state && (
                    <BDOModal 
                        header={"Request Details"}
                        body={
                            <NotificationModalBody
                                modalData={modalData}
                                setModalData={setModalData}
                                formIkRef={formIkRef}
                                handleOnChangeStatus={handleOnChangeStatus}
                            />
                        }
                        footer={modalFooterContent}
                        openState={modalData.state}
                        modalProps={{ onHide: closeModal }}
                    />
                )
            }
            <div className="tableBlock">
                <Card>
                    <Card.Body>
                        <div  className="mb10">
                            <b className="header6">Downtime Notifications</b>
                        </div>
                        <div className="dataBlock">
                            {
                                (localObj !== undefined || errorResponse)
                                ?  (
                                <DataTable 
                                    columns={columns}
                                    data={localObj || []}
                                    showPagination={true}
                                    handleServerSidePagination={handleServerSidePagination}
                                    errorDiv={errorDiv}
                                    pageProperty={{ totalPages, isPageChanged, movePage: (val) => movePage(val) }}
                                />):(
                                    <div className="alignCenter">
                                        <Spinner animation="border" />
                                    </div>
                                )
                            }
                        </div>
                    </Card.Body>
                </Card>
            </div>

        </div>
    )
}
export default ViewAllScheduleTime;
