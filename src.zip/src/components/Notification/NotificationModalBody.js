import React from 'react';
import InputText from '../Global/Input/InputText';
import { Form } from 'react-bootstrap';
import { Formik } from 'formik';
import * as Yup from 'yup';

const validationSchema = Yup.object().shape({
	reason: Yup.string().required('Required feild'),
});

const NotificationModalBody = (props) => {
	const { modalData, handleOnChangeStatus, formIkRef } = props;
	return (
		<div>
			<div>
				{modalData.header}
			</div>
			<div className="bdyRow">
				<b>Subject : </b>
				<span>{modalData.subject}</span>
			</div>
			<div className="bdyRow">
				<b>Reference no : </b>
				<span>{modalData.referenceNo}</span>
			</div>
			<div className="bdyRow">
				<b>Received date : </b>
				<span>{modalData.receivedDate}</span>
			</div>
			<div className="bdyRow reasonBlock">
				<Formik
					initialValues={{'reason':'', code: modalData.code}}
					validationSchema={validationSchema}
					innerRef={formIkRef}
					onSubmit={(values) => handleOnChangeStatus(values)}
				>
					{({ 
                errors, touched, values, handleSubmit, handleChange,
            }) => (
                    <Form onSubmit={handleSubmit}>
                        {console.log('ere', errors)}
                        <InputText  
                            value={modalData.reason} 
                            onChange={handleChange}
                            className={errors.reason && touched.reason?"err-feild":""}
                            placeholder="Please provide reason"
                            name="reason"
                        />
                        {
                            errors.reason && touched.reason
                            ?(
                                <div className="alignLeft"> 
                                    <span className="err-feild">
                                        {errors.reason}
                                    </span>
                                </div>
                            ): ''
                        }
                    </Form>
                )}
            </Formik>
        </div>
    </div>
	)
};

export default NotificationModalBody;
