/* eslint-disable react-hooks/exhaustive-deps */
import React, { useEffect, useRef, useState } from 'react';
import { Image, Form } from 'react-bootstrap';
import ViewGatewayDetails from './ViewGatewayDetails';
import ViewGatewaySubDetails from './ViewGatewaySubDetails';
import { useDispatch, useSelector } from "react-redux";
import {
    retrieveGatewayRecord, updateLocalData, addGatewayRecord,
    addOrUpdateGateway,
} from '../../actions/gatewaymanagement';
import { withRouter } from "react-router-dom";
import BDOButton from '../Global/Button/BDOButton'
import backIcon from '../../assets/icons/backIcon.png'
import { Formik } from 'formik';
import BDOToast from '../Global/BDOToast/BDOToast';
import BDOModal from '../Global/BDOModal/BDOModal';
import './styles/viewGatewayRecord.scss';
import * as Yup from 'yup';
import { useMsal  } from "@azure/msal-react";

const handleListener = ( history, window , id, viewGateway) => {
    const allowedPath = [ "/gatewaymanagment/gatewayProviders", "/gatewaymanagment/gatewayProvidersGw","/gatewaymanagment/gatewaySettings"]
    const { location: { pathname }} = history;
    if(allowedPath.filter(ele => pathname.includes(ele)).length === 0 && pathname !==  `/gatewaymanagment/${id}`) {
        if(!window.confirm("Leaving the page will discard any unsaved changes")) {
            history.go(-1)
        } else {
            viewGateway.data = {};
        }
    } else {
        window.onbeforeunload = undefined;
    }
}

function ViewGatewayRecord(props) {
    const { history }= props;
    const dispatch = useDispatch();
    const [ toastObj, setToastData ] = useState({});
    const [ modalData, setModalData ] = useState({});
    const { instance } = useMsal();
    const accounts = instance.getAllAccounts();
    const accountUserId = (accounts && accounts[0]?.localAccountId) || "us-02";
    const retData = useSelector( state => state.gatewayReducer);
    const {  match: {params: { id }}} = props;
    const { viewGateway={}, gatewayInitialData={} } = retData;
    const { data = {} } = viewGateway;
    let maximumNoOfAllowablegwSettings = ( gatewayInitialData.data && gatewayInitialData.data.maximumNoOfAllowablegwSettings) || data.maximumNoOfAllowablegwSettings
    let maximumNoOfAllowablegwProvider = ( gatewayInitialData.data && gatewayInitialData.data.maximumNoOfAllowablegwProvider) || data.maximumNoOfAllowablegwProvider
    let { 
        gatewayTypeDetails={}, gatewaySettingsList, gatewayProviderList
    } = data;
    useEffect(() => {
        const {
            location: { 
                dataFrom= {}, toastState= false, toastMessage ='', toastType = 'success',
                state={}
            }
        } = props;
        const { action = '' } = state;
        let listener=() => null;
        if( action !== 'view') {
            window.onbeforeunload = (e) => {
                e.preventDefault();
                e.returnValue= '';
            }
            listener = history.listen((loc) => {
                handleListener(history, window, id, viewGateway)
            })
        }
        
        if( dataFrom !== "localState" && id !== "add" && Object.keys(data).length === 0)  {
            dispatch(addGatewayRecord())
            dispatch(retrieveGatewayRecord(id))
        }
        else if( id === "add" && maximumNoOfAllowablegwSettings === undefined) {
            dispatch(addGatewayRecord())
        }
        else if(toastState)  {
            setToastData({ toastState , toastMessage , toastType})
            window.scrollTo({
                top: 0,
                left:0,
                behavior: "smooth"
            });
        }
        
        return () => {
            window.onbeforeunload = undefined;
            return listener()
        }
    }, []);
    const goBack = ( toastData) => {
        history.push({
            pathname: '/gatewaymanagment', state: { toastData }
        });
        viewGateway.data = {};
    }
    const formikRef = useRef();
    if( id === "add") {
        if( !viewGateway.data || Object.keys(viewGateway.data).length === 0) {
            dispatch( updateLocalData({
                data: {
                    gatewayTypeDetails : { gatewayId: "add"},
                    gatewaySettingsList: [],
                    gatewayProviderList: []
                }
            }))
        }
    }
    const validationSchema = {
        gatewayCode: Yup.string()
            .matches(/^[a-z0-9\s]+$/i, { message: 'Enter only alpha numeric characters'})
            .max(50, 'Must be 50 characters or less')
            .required('Required field'),
        name: Yup.string()
            .matches(/^[a-z0-9\s_-]+$/i, { message: 'Enter only alpha numeric characters'})
            .max(50, 'Must be 50 characters or less')
            .required('Required field'),
        description: Yup.string()
            .max(50, 'Must be 300 characters or less')
            .required('Required field'),
        status: Yup.string().required('Required field'),
    }
    

    const handleSubmit = ( values , action ) => {
        if( data.gatewayProviderList.length === 0) {
            setModalData({ 
                modalState: true,
                modalMessage: 'Adding a gateway without a provider will set its status to Inactive. Proceed ?'
            })
        } else {
            const findActiveEle = gatewayProviderList.filter((ele) => ele.status).map((retrnEle) =>
                retrnEle.distributionPercentage ? retrnEle.distributionPercentage : 0
            );
            if( findActiveEle.length > 0 ) {
                const calculateTotal = findActiveEle.reduce((prev, current) => prev + current);
                if( calculateTotal !== 100 ) {
                    setToastData({ toastState: true , toastMessage: 'Distribution percentage should be 100%' , toastType: 'warning'})
                    window.scrollTo({
                        top: 0,
                        left:0,
                        behavior: "smooth"
                    });
                } else {
                    data.gatewayTypeDetails.forApproval = true;
                    addOrUpdataGateway();
                }
            } else {
                setModalData({ 
                    modalState: true,
                    modalMessage: 'Adding a gateway without a provider will set its status to Inactive. Proceed ?'
                })
            }
        }
    }
    const closeModal = () => {
         setModalData({})
    }

    const addOrUpdataGateway = () => {
        dispatch(addOrUpdateGateway(data, accountUserId,  id, (respData={}) => {
            const { referenceId } = (respData.data || {} );
            if( respData.data.ccmErrorCode && respData.data.errorDescription && !respData.data.errorList ) {
                closeModal()
                setToastData({ 
                    toastState: true, 
                    toastMessage: `${respData.data.ccmErrorCode} - ${respData.data.errorDescription}`, 
                    toastType: "warning"
                });
                window.scrollTo({
                    top: 0,
                    left:0,
                    behavior: "smooth"
                });
            }
            else if( respData.data && respData.data.errorList && Object.values(respData.data.errorList).length> 0) {
                closeModal()
                let msg = '';
                
                if( respData.data.errorList && Object.values(respData.data.errorList).length > 0) {
                    Object.keys(respData.data.errorList).forEach((ele, index) => {
                        msg += `${ele} : ${respData.data.errorList[ele]}`
                        if( Object.values(respData.data.errorList).length -1 !== index){
                            msg +=","
                        } else {
                            msg += "."
                        }
                    })
                }
                setToastData({ toastState: true, toastMessage: msg, referenceId, toastType: "warning"});
                window.scrollTo({
                    top: 0,
                    left:0,
                    behavior: "smooth"
                });
            }
            else if( id === "add") {
                goBack({ toastMessage: `Gateway request submitted for approval . Reference number ${referenceId}`, toastState: true, toastType: 'success'})
            } else {
                setToastData({ toastState: true, toastMessage: `Gateway request submitted for approval . Reference number ${referenceId}`, toastType: "success"});
                closeModal();
                window.scrollTo({
                    top: 0,
                    left:0,
                    behavior: "smooth"
                });
            }
          }));
    }
    const modalFooterContent = (
        <>
            <BDOButton
                variant="secondary" 
                onClick={() => {
                   closeModal()
                }}>
                Cancel
            </BDOButton>
            <BDOButton
                variant="primary" 
                onClick={() => {
                    data.gatewayTypeDetails.status = false;
                    addOrUpdataGateway()
                }}>
                Add
            </BDOButton>
        </>
    )
    const isView = props.location.state && props.location.state.action === "view"
    return(
        <div className="viewLayout-gm">
            <div className="redirect">
                <div style={{cursor: "pointer"}} onClick={() => goBack()}>
                    <Image src={backIcon}  className="icon"/>
                </div>
                <b>{(id !== 'add' ? `${gatewayTypeDetails.gatewayCode} - ${gatewayTypeDetails.name}`: 'Add Gateway')}</b>
            </div>
            {
				toastObj.toastState && (
					<BDOToast  
						openState={toastObj.toastState}
						type={toastObj.toastType}
						bodyMessage={toastObj.toastMessage}
						onClose={() => setToastData({})} 
					/>
				)
			}
            {
                modalData.modalState && (
                    <BDOModal 
                        header={"Add Gateway"} 
                        body={modalData.modalMessage}
						openState={modalData.modalState}
						modalProps={{onHide: closeModal }}
                        footer={modalFooterContent}
					/>
                )
            }
            <Formik
                initialValues={{...gatewayTypeDetails, status: gatewayTypeDetails.status === undefined ? false: gatewayTypeDetails.status}}
                enableReinitialize
                validationSchema={Yup.object().shape(validationSchema)}
                onSubmit={(values, action) => {
                    handleSubmit(values, action);
                }}
                innerRef={formikRef}
            >
            {({ 
                errors, touched, values, handleChange,
                setFieldValue, handleBlur
            }) => (
                <Form onSubmit={handleSubmit}>
                   <div className="gtwayDetails">
                        { 
                            gatewayTypeDetails &&
                            <ViewGatewayDetails 
                                gateway={ gatewayTypeDetails}
                                handleChange={handleChange}
                                handleBlur={handleBlur}
                                setFieldValue={setFieldValue}
                                values={values}
                                formik={{errors, touched}}
                                gatewayId={id}
                                isView={isView}
                            />
                        }
                    </div>
                </Form>
              )}
            </Formik>
            <div className="subDetails">
                {
                    <ViewGatewaySubDetails
                        code={gatewayTypeDetails.gatewayCode}
                        gatewaySettingsList={gatewaySettingsList} 
                        gatewayProviderList={gatewayProviderList} 
                        maximumNoOfAllowablegwSettings={maximumNoOfAllowablegwSettings}
                        maximumNoOfAllowablegwProvider={maximumNoOfAllowablegwProvider}
                        setToastData={setToastData}   
                        isView={isView}
                        gatewayId={id}       
                    />
                }
            </div>
            {!isView ?
            (<div className="recordBtnBlock">
                <BDOButton variant="secondary" onClick={() => goBack()}>Cancel</BDOButton>
                <BDOButton variant="primary" onClick={() => formikRef.current.handleSubmit()} >Save</BDOButton>
            </div>):''}  
        </div>
    )
}

export default withRouter(ViewGatewayRecord);
