/* eslint-disable react-hooks/exhaustive-deps */
import React, { useEffect, useRef, useState } from 'react';
import { Image, Form } from 'react-bootstrap';
import ViewGatewayDetails from './ViewGatewayDetails';
import ViewGatewaySubDetails from './ViewGatewaySubDetails';
import { useDispatch, useSelector } from "react-redux";
import {
    retrieveGatewayRecord, updateLocalData, addGatewayRecord,
    addOrUpdateGateway
} from '../../actions/gatewaymanagement';
import { Link, withRouter } from "react-router-dom";

import BDOButton from '../Global/Button/BDOButton'
import backIcon from '../../assets/icons/backIcon.png'
import { Formik } from 'formik';
import BDOToast from '../Global/BDOToast/BDOToast';
import BDOModal from '../Global/BDOModal/BDOModal';
import './styles/viewGatewayRecord.scss';
import * as Yup from 'yup';

function ViewGatewayRecord(props) {
    const { history }= props;
    const dispatch = useDispatch();
    const [ toastObj, setToastData ] = useState({});
    const [ modalData, setModalData ] = useState({})
    const retData = useSelector( state => state.gatewayReducer);
    const {  match: {params: { id }}} = props;
    const { viewGateway={}, gatewayInitialData={} } = retData;
    const { data = {} } = viewGateway;
    let maximumNoOfAllowablegwSettings = ( gatewayInitialData.data && gatewayInitialData.data.maximumNoOfAllowablegwSettings) || data.maximumNoOfAllowablegwSettings
    let maximumNoOfAllowablegwProvider = ( gatewayInitialData.data && gatewayInitialData.data.maximumNoOfAllowablegwProvider) || data.maximumNoOfAllowablegwProvider
    let { 
        gatewayTypeDetails={}, gatewaySettingsList, gatewayProviderList
    } = data;
    
    useEffect(() => {
        const {
            location: { 
                dataFrom= {}, toastState= false, toastMessage ='', toastType = 'success',
                state={}
            }
        } = props;
        console.log('state', props);
        const { action = '' } = state;
        let listener=() => null;
        if( action !== 'view') {
            window.onbeforeunload = (e) => {
                e.preventDefault();
                e.returnValue= '';
            }
            listener = history.listen((loc) => {
                const allowedPath = [ "/gatewaymanagment/gatewayProviders", "/gatewaymanagment/gatewayProvidersGw","/gatewaymanagment/gatewaySettings"]
                const { location: { pathname }} = history;
                if(allowedPath.filter(ele => pathname.includes(ele)).length === 0 && pathname !==  `/gatewaymanagment/${id}`) {
                    if(!window.confirm("Leaving the page will discard any unsaved changes")) {
                        history.go(-1)
                    }
                } else {
                    window.onbeforeunload = undefined;
                }
            })
        }
        
        if( dataFrom !== "localState" && id !== "add" && Object.keys(data).length === 0)  {
            dispatch(retrieveGatewayRecord(id))
        }
        else {
            if( id === "add" && maximumNoOfAllowablegwSettings === undefined) {
                dispatch(addGatewayRecord())
            }
            if(toastState)  {
                setToastData({ toastState , toastMessage , toastType})
                window.scrollTo({
                    top: 0,
                    left:0,
                    behavior: "smooth"
                });
            }
        }
        return () => {
            window.onbeforeunload = undefined;
            return listener()
        }
    }, []);
    const goBack = ( toastData) => {
        history.push({
            pathname: '/gatewaymanagment', state: { toastData }
        });
        viewGateway.data = {};
    }
    console.log(history.location.pathname,'sad')
    const formikRef = useRef();
    if( id === "add") {
        if( !viewGateway.data || Object.keys(viewGateway.data).length === 0) {
            dispatch( updateLocalData({
                data: {
                    gatewayTypeDetails : { gatewayId: "add"},
                    gatewaySettingsList: [],
                    gatewayProviderList: []
                }
            }))
        }
    }
    const validationSchema = {
        gatewayCode: Yup.string()
            .matches(/^[a-z0-9\s]+$/i, { message: 'Enter only alpha numeric characters'})
            .max(50, 'Must be 50 characters or less')
            .required('Required field'),
        name: Yup.string()
            .matches(/^[a-z0-9\s_-]+$/i, { message: 'Enter only alpha numeric characters'})
            .max(50, 'Must be 50 characters or less')
            .required('Required field'),
        description: Yup.string()
            .max(50, 'Must be 300 characters or less')
            .required('Required field'),
        status: Yup.string().required('Required field'),
    }
    

    const handleSubmit = ( values , action ) => {
        if( data.gatewayProviderList.length === 0) {
            setModalData({ 
                modalState: true,
                modalMessage: 'Adding a gateway without a provider will set its status to Inactive. Proceed ?'
            })
        } else {
            const findActiveEle = gatewayProviderList.filter((ele) => ele.status === "active").map((retrnEle) =>
                retrnEle.distributionPercentage ? retrnEle.distributionPercentage : 0
            );
            if( findActiveEle.length > 0 ) {
                const calculateTotal = findActiveEle.reduce((prev, current) => prev + current);
                if( calculateTotal !== 100 ) {
                    setToastData({ toastState: true , toastMessage: 'Distribution percentage should be 100%' , toastType: 'warning'})
                    window.scrollTo({
                        top: 0,
                        left:0,
                        behavior: "smooth"
                    });
                } else {
                    addOrUpdataGateway();
                }
            } else {
                setModalData({ 
                    modalState: true,
                    modalMessage: 'Adding a gateway without a provider will set its status to Inactive. Proceed ?'
                })
            }
        }
    }
    const closeModal = () => {
         setModalData({})
    }

    const addOrUpdataGateway = () => {
        dispatch(addOrUpdateGateway(data, (respData) => {
            const { data : { message, referenceId }} = respData;
            if( id === "add") {
                goBack({ toastMessage: `${message} . Reference number ${referenceId}`, toastState: true, toastType: 'success'})
            } else {
                setToastData({ toastState: true, toastMessage: message, referenceId, toastType: "success"});
                closeModal();
                window.scrollTo({
                    top: 0,
                    left:0,
                    behavior: "smooth"
                });
            }
          }));
    }
    const modalFooterContent = (
        <>
            <BDOButton
                variant="secondary" 
                onClick={() => {
                   closeModal()
                }}>
                Cancel
            </BDOButton>
            <BDOButton
                variant="primary" 
                onClick={() => {
                    data.gatewayTypeDetails.status = "inactive"
                    addOrUpdataGateway()
                }}>
                Add
            </BDOButton>
        </>
    )
    const isView = props.location.state && props.location.state.action === "view"
    return(
        <div className="viewLayout-gm">
            <div className="redirect">
                <Link onClick={() => goBack()}>
                    <Image src={backIcon}  className="icon"/>
                </Link>
                <b>{(id !== 'add' ? `${gatewayTypeDetails.gatewayCode} - ${gatewayTypeDetails.name}`: 'Add Gateway')}</b>
            </div>
            {
				toastObj.toastState && (
					<BDOToast  
						openState={toastObj.toastState}
						type={toastObj.toastType}
						bodyMessage={toastObj.toastMessage}
						onClose={() => {setToastData({})}} 
					/>
				)
			}
            {
                modalData.modalState && (
                    <BDOModal 
                        header={"Add Gateway"} 
                        body={modalData.modalMessage}
						openState={modalData.modalState}
						modalProps={{onHide: closeModal }}
                        footer={modalFooterContent}
					/>
                )
            }
            <Formik
                initialValues={{...gatewayTypeDetails, status: gatewayTypeDetails.status === undefined ? 'inactive': gatewayTypeDetails.status}}
                enableReinitialize
                validationSchema={Yup.object().shape(validationSchema)}
                onSubmit={(values, action) => {
                    handleSubmit(values, action);
                }}
                innerRef={formikRef}
            >
            {({ 
                errors, touched, values, handleChange,
                setFieldValue, handleBlur
            }) => (
                <Form onSubmit={handleSubmit}>
                   <div className="gtwayDetails">
                        { 
                            gatewayTypeDetails &&
                            <ViewGatewayDetails 
                                gateway={ gatewayTypeDetails}
                                handleChange={handleChange}
                                handleBlur={handleBlur}
                                setFieldValue={setFieldValue}
                                values={values}
                                formik={{errors, touched}}
                                gatewayId={id}
                                isView={isView}
                            />
                        }
                    </div>
                </Form>
              )}
            </Formik>
            <div className="subDetails">
                {
                    <ViewGatewaySubDetails
                        code={gatewayTypeDetails.gatewayCode}
                        gatewaySettingsList={gatewaySettingsList} 
                        gatewayProviderList={gatewayProviderList} 
                        maximumNoOfAllowablegwSettings={maximumNoOfAllowablegwSettings}
                        maximumNoOfAllowablegwProvider={maximumNoOfAllowablegwProvider}
                        setToastData={setToastData}   
                        isView={isView}
                        gatewayId={id}       
                    />
                }
            </div>
            {!isView ?
            (<div className="recordBtnBlock">
                <BDOButton variant="secondary" onClick={() => goBack()}>Cancel</BDOButton>
                <BDOButton variant="primary" onClick={() => formikRef.current.handleSubmit()} >Save</BDOButton>
            </div>):''}  
        </div>
    )
}

export default withRouter(ViewGatewayRecord);
