import React, { useState } from 'react';
import { 
    Row, Button, Col, Image,
    Spinner
} from 'react-bootstrap';
import DataTable from '../Global/DataTable/DataTable';
import EditIcon from '../../assets/icons/icon-edit-outline.svg';
import DeleteIcon from '../../assets/icons/icon-delete.svg';
import Switch from '../Global/Switch/Switch';
import { Link , useHistory} from 'react-router-dom';

const codeDiv = (data, providerCode) => (
    <Link 
        className="modalLink"
        to={`/gatewaymanagment/gatewayProviders/${providerCode}/${data.code}`}
    >
        {data.code}
    </Link>
)

const actionDiv = ( ele , handleStatusChange , toggle , providercode) => (
    <div className="actionDiv" key={`action_${ele.code}`}>
        <Switch
                type="switch"
                id={`custom-switch-${ele.code}`}
                defaultChecked={ele.status === 'active'}
                onChange = {(e) => handleStatusChange(e.target.checked , ele.code)}
            />
        <div className="editDiv"><Image onClick={() => toggle('EDIT' , providercode , ele)} src={EditIcon} className="icon"/></div>
        <div className="deleteDiv">
            <Image src={DeleteIcon} className="icon" />
        </div>
    </div>
);
const sortByElement = ( rowA, rowB, colId, desc) => {
    const findFn = ( entry ) => entry.column && (entry.column.id ===  colId)
    const foundAData = rowA.cells.find(findFn);
    const foundBData = rowB.cells.find(findFn);
    const aValue =  typeof rowA.cells[0] !== "function" && foundAData && foundAData.value.props.children;
    const bValue =  typeof rowB.cells[0] !== "function" && foundBData && foundBData.value.props.children;
    return alphaNumericSorting( aValue, bValue, colId, desc)
}

const alphaNumericSorting = (frstValue, scndValue, colId, desc=false) => {
    if( frstValue && scndValue ){
        if( !desc ) return frstValue.localeCompare(scndValue)
        return (-1 *(scndValue.localeCompare(frstValue)))
    }
}

function ViewDetailsGatewayProviders(props) {
    let [ activeRow, setActiveRow] = useState([]);
    const history = useHistory();
    const { gatewayProviderSettings , providercode } = props;
    let [ providerData= gatewayProviderSettings, setProviderData ] = useState();  
    let toggle = (toggleaction , providercodeitem , datatochild ) => {
        if(toggleaction==="ADD"){
        history.push({pathname: `/gatewaymanagment/gatewayProviders/${providercodeitem}/ADD`, state: {toggleaction,datatochild }})
        }else if(toggleaction!=="ADD"){
            history.push({pathname: `/gatewaymanagment/gatewayProviders/${providercodeitem}/${datatochild.code}`, state: {toggleaction,datatochild }})
        }
      };
    const handleHeaderCheck = ( value ) => {
        if( value) setActiveRow( [...providerData.map((entry) => entry.code)]);
        else setActiveRow([]);
    }

    const handleStatusChange = ( value, code ) => {
        const finder = providerData.find(( ele ) => ele.code === code);
        finder["status"] = value?"active": "inactive";
        setProviderData([...providerData]);
    }

    const handleCheckList = ( value, code ) => {
        const idx = activeRow.indexOf( code );
        if( value) setActiveRow( [...activeRow, code ] );
        else {
            activeRow.splice( idx, 1);
            setActiveRow([...activeRow])
        }
    }

    let columns = [
        {
            Header: (
                <Switch
                    onClick={(e) => handleHeaderCheck(e.target.checked)} 
                />
            ),
            accessor: 'checkBox',
            disableSortBy: true
        },
        {
            Header: 'Code',
            accessor: 'code',
            selector: 'code',
            sortType: ( rowA, rowB, colId, desc ) => {
                return sortByElement(rowA, rowB, colId, desc)
            }
        },
        {
            Header: 'Description',
            accessor: 'name',      
        },
        {
            Header: 'Status',
            accessor: 'status',
            sortType: ( rowA, rowB, colId, desc ) => {
                return sortByElement(rowA, rowB, colId, desc)
            }
        }
    ];

    const statusDiv = (data) => {
        const { status } = data;
        let stat = 'Disabled';
        let className = 'status_disabled';
        if ( status === 'active' ) {
            stat = 'Enabled';
            className = 'status_enabled';
        }
        return (
            <div className={className}>{stat}</div>
        )
    }

    
    const localObj = providerData && providerData.map((ele) => {
        return {
            ...ele,
            code: codeDiv(ele ,  providercode),
            status: statusDiv(ele), 
            action: actionDiv(ele, handleStatusChange , toggle ,providercode),
            checkBox: (
                <Switch
                    onChange={(e) => handleCheckList(e.target.checked, ele.code)} 
                    checked={activeRow.indexOf(ele.code) !== -1}
                />),
            className: activeRow && activeRow.find((itr) => itr === ele.code)? 'activeRow' :''
        }
    });

    const isEnabled = providerData && activeRow.length !== 0 && ( [ ...providerData.filter((ele ) => activeRow.includes(ele.code))].filter(ele => ele.status === 'active').length === activeRow.length);
    const isDisabled = providerData && activeRow.length !== 0  && ( [ ...providerData.filter((ele ) => activeRow.includes(ele.code))].filter(ele => ele.status === 'inactive').length === activeRow.length);
    let btnText = '';
    if ( isEnabled ) {
        btnText = 'Disable';
    }  else if ( isDisabled ) {
        btnText = 'Enable';  
    } else {
        columns = [
            ...columns,
            {
                Header: 'Actions',
                accessor: 'action',
                disableSortBy: true,
                className: 'actionCol'
            },
        ];
    }
    return(
        <div className="gatewaySettings">
            <div className="searchCard">
                <Row className="mb10">
                    <Col sm={8}>
                        <b>Gateway Provider Setting</b>
                    </Col>
                    <Col className="alignRight">
                        <Button variant="add"  onClick={(e) => toggle('ADD' , providercode)}  >
                            Add Gateway Provider Setting
                        </Button>
                    </Col>
                </Row>
               {/* <SearchBar textPlaceHolder="Input provider code" categoryList={categoryList} handleClick={handleClick} /> */}
                <div className="btnBlock">
                    {
                        (activeRow.length > 0) 
                        ? (
                            <>
                                {btnText && <Button variant="primary" className="mr5">{btnText} </Button>}
                                <Button variant="primary" className="danger">Delete</Button>
                                <span className="highlighter">{activeRow.length} items selected</span>
                            </>
                        ) : ''
                    }
                </div>
                <div className="dataBlock">
                    {
                        localObj !== undefined
                        ?  (
                        <DataTable 
                            columns={columns}
                            data={localObj}
                            showPagination={true}
                            defaultPageSize={5}
                        />):(
                            <div className="alignCenter">
                                <Spinner animation="border" />
                            </div>
                        )
                    }
                </div>
            </div>
        </div>
    
    )
}

export default ViewDetailsGatewayProviders;
