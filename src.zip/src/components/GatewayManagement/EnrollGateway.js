/* eslint-disable react-hooks/exhaustive-deps */
import React, { useEffect } from "react";
import {
  Col,
  Form,
  Row,
  Card,
  Image,
} from 'react-bootstrap';
import { useDispatch, useSelector } from "react-redux";
import { useHistory  } from 'react-router-dom';
import { useFormik } from 'formik';
import * as Yup from 'yup';
import backIcon from '../../assets/icons/backIcon.png'
import BDOButton from '../Global/Button/BDOButton';
import InputText from '../Global/Input/InputText';
import Switch from '../Global/Switch/Switch';
import ViewGatewaySubDetails from './ViewGatewaySubDetails';
import { retrieveGatewayRecord } from '../../actions/gatewaymanagement';
import './styles/viewGatewayRecord.scss';
let initialValues = {};
let dataToBeEdited = {};

const getClassName = ( formik, paramName ) => formik.errors[(paramName)]? "input-text error":"input-text";

const renderError = ( formik, paramName) => {
  return(
    formik.errors[(paramName)] ? (
      <span className='mb-1 error-text'>
        {formik.errors[(paramName)]}
      </span>
    ) : null
  )
}
export default function EnrollGateway(props) {
  const history = useHistory();
  const dispatch = useDispatch();
    const retData = useSelector( state => state.gatewayReducer);
  let propsData = props?.location?.state;
    useEffect(() => {
      if(propsData.toggleaction === 'EDIT'){
        dispatch(retrieveGatewayRecord(propsData.datatochild.code))
      }
    }, [])
    dataToBeEdited = retData?.viewGateway?.data;
    let gatewaySettings= [];
    let gatewayproviders = [];

    if (propsData && propsData.datatochild && dataToBeEdited !== undefined ) {
      let dataToEdit = dataToBeEdited.gatewayTypeDetails; 
      initialValues.gatewaycode = dataToEdit.code || '';
      initialValues.gatewayname = dataToEdit.name || '';
      initialValues.gatewaydescription = dataToEdit.description || '';
      initialValues.gatewaystatus = dataToEdit?.status;
      gatewaySettings=dataToBeEdited.gatewaySettings;
      gatewayproviders=dataToBeEdited.gatewayProviderList;
    }
  const formik = useFormik({
    enableReinitialize: true, 
    initialValues,
    validationSchema: Yup.object({
        gatewaycode: Yup.string()
        .max(10, 'Must be 10 characters or less')
        .required('Required'),
        gatewayname: Yup.string()
        .matches(/^[A-Za-z ]*$/, 'Please enter valid name')
        .max(50, 'Must be 50 characters or less')
        .required('Required'),
        gatewaydescription: Yup.string()
        .max(200, 'Must be 200 characters or less')
        .required('Required'),
        gatewaystatus: Yup.string().required('Required')
    }),
    onSubmit: values => {
      history.push({pathname: '/gatewaymanagment', state: {values}})
    },
  });
    //To initially put gateway status as active for add
    if(propsData.toggleaction === 'ADD'){
      if(formik.values.gatewaystatus === undefined){ 
        formik.values.gatewaystatus ="active";}   
    }      
  const handleSwitchChange = (  name,value ) => {
    if(name === "gatewaystatus"){
      formik.setFieldValue(name, value ? 'active': 'inactive');
    }
}

  function closeModal() {
    formik.resetForm();
    initialValues={};
		history.push("/gatewaymanagment");
  }
  return (
    <div className="addCcm viewLayout-gm mt-2">
              <div className="headertitle">
                    <Image  onClick={closeModal} src={backIcon}  className="icon"/>
                    <h4>{propsData?.toggleaction === 'ADD'
                    ? 'Enroll Gateway'
                    : 'Edit Gateway'}</h4>
                </div>
                
            <Form  onSubmit={formik.handleSubmit}>

            <Card className="cardbodystyle border-0">
               <Card.Body >
                   <Row className="mt-2 mr-2 ml-2">
                        <Col xs='12' sm='12' ><h4>Gateway details</h4></Col>
                       <Col xs='12' sm='12' className="mt-2" >Provide the necessary details for the gateway you are adding.</Col>
                       <Col xs='12' sm='12' >Gateway settings and providers will be created once the gateway is added.</Col>
                       <Col xs='12' sm='12' className="mt-2" ><b>All fields are required</b></Col>
                   </Row>
              <Row  className="mt-2 mr-2 ml-2">
                <Col xs='2' sm='2' >
                  <div className=''>
                    <label htmlFor='gatewaycode' className=''>Gateway Code </label>
                        
                  </div>
                </Col>
                 <Col xs='5' sm='5'>
                   <InputText 
                          className={getClassName(formik, 'gatewaycode')}
                          value={formik.values.gatewaycode}
                          onChange={formik.handleChange}
                          onBlur={formik.handleBlur}
                          disabled={propsData.toggleaction==="EDIT"?true : false}
                          name='gatewaycode'
                          placeholder='Enter gateway code'
                        />
                        {renderError(formik, 'gatewaycode')}
                  </Col>
              </Row>

              <Row className="mt-2 mr-2 ml-2">
                <Col xs='2' sm='2' >
                  <div className=''>
                    <label htmlFor='gatewayname' className=''>Gateway Name </label>
                        
                  </div>
                </Col>
                 <Col xs='5' sm='5'>
                    <InputText
                     className={getClassName(formik, 'gatewayname')}
                          value={formik.values.gatewayname}
                          onChange={formik.handleChange}
                          onBlur={formik.handleBlur}
                          name='gatewayname'
                          placeholder='Enter gateway name'
                        />
                        {renderError(formik, 'gatewayname')}
                  </Col>
              </Row>

              <Row  className="mt-2 mr-2 ml-2">
                <Col xs='2' sm='2' >
                  <div className=''>
                    <label htmlFor='gatewaydescription' className=''>Gateway Description </label>
                  </div>
                </Col>
                 <Col xs='5' sm='5'>
                         <InputText
                         as="textarea"
                         rows={3}
                         className={getClassName(formik, 'gatewaydescription')}
                         value={formik.values.gatewaydescription}
                         onChange={formik.handleChange}
                         onBlur={formik.handleBlur}
                         name='gatewaydescription'
                         placeholder='Enter gateway description'/>
                        {renderError(formik, 'gatewaydescription')}
                  </Col>
              </Row>

              <Row  className="mt-2 mr-2 ml-2">
                <Col xs='2' sm='2' >
                  <div className=''>
                    <label htmlFor='gatewaystatus' className=''>Gateway Status</label>
                  </div>
                </Col>
                 <Col xs='5' sm='5'>
                 
            <div className="detailsActive">
            <Switch
                type="switch"
                id={`custom-switch-${formik?.values?.gatewaycode}`}
                onChange={(e) => handleSwitchChange( "gatewaystatus" , e.target.checked)}
                checked={formik.values.gatewaystatus === "active" ?true : false}
            />
                                    <div>{formik.values.gatewaystatus === "active" ? 'Active' : 'Inactive'}</div>
                                </div>
            {formik.errors.gatewaystatus ? (
                         <span className='mb-1 error-text'>
                            {formik.errors.gatewaystatus}
                          </span>
                        ) : null}
                       
                  </Col>
              </Row>
              </Card.Body>
              </Card>
              
              <div className="subDetails">
                
                    <ViewGatewaySubDetails
                        gatewaySettingsList = {gatewaySettings}
                        gatewayProviderList = {gatewayproviders}         
                    />
            </div>
            <div className='mt-4 mb-4 float-right'>
                <BDOButton  onClick={closeModal} title="Cancel" style1="style2 mr-3" />
                <BDOButton type="submit" title={propsData?.toggleaction === 'ADD'
                    ? 'Add'
                    : 'Save'} style1="style1" />
              </div>
            </Form>
    </div>
  );
}

