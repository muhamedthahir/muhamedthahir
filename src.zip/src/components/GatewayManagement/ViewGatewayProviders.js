/* eslint-disable react-hooks/exhaustive-deps */
import React, { useState, useEffect } from 'react';
import  { useDispatch, useSelector } from 'react-redux';
import DetailsLabel from './DetailsLabel';
import { Card, Image, Spinner, Row, Col, Button, Container } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import './styles/viewGatewayRecord.scss';
import Switch from '../Global/Switch/Switch';
import DataTable from '../Global/DataTable/DataTable';
import EditIcon from '../../assets/icons/icon-edit-outline.svg';
import DeleteIcon from '../../assets/icons/icon-delete.svg';
import backIcon from '../../assets/icons/backIcon.png';
import InputText from '../../components/Global/Input/InputText';
import { retrieveGatewayProviders } from '../../actions/gatewaymanagement';
import BDOButton from '../Global/Button/BDOButton'

const codeDiv = (data, providerCode) => (
    <Link 
        className="modalLink"
        to={`/gatewaymanagment/gatewayProviders/${providerCode}/${data.code}`}
    >
        {data.code}
    </Link>
)

const statusDiv = (settingsdata) => {
    let stat = 'Disabled';
    let className = 'status_disabled';
    if ( settingsdata.status === 'active' ) {
        stat = 'Enabled';
        className = 'status_enabled';
    }
    return (
        <div className={className}>{stat}</div>
    )
}
const actionDiv = ( ele , handleStatusChange) => (
    <div className="actionDiv" key={`action_${ele.code}`}>
        <Switch
                type="switch"
                id={`custom-switch-${ele.code}`}
                defaultChecked={ele.status === 'active'}
                onChange = {(e) => handleStatusChange(e.target.checked , ele.code)}
            />
        <div className="editDiv"><Image src={EditIcon} className="icon" /></div>
        <div className="deleteDiv">
            <Image src={DeleteIcon} className="icon" />
        </div>
    </div>
);

function ViewGatewayProviders(props) {
    let [ activeRow, setActiveRow] = useState([]);
    const dispatch = useDispatch();
    const { viewGatewayProviders={} } = useSelector( state => state.gatewayReducer);
    const { match: {params: { id }} } = props;
    useEffect(() => {
        dispatch(retrieveGatewayProviders(id))
    }, []);
    const { data = {}} = viewGatewayProviders;
    const [ settingsData = data, setData ] = useState()
    const { 
        code, description, providerURL,
        providerContextRoot, status, gatewayProviderSettings
    } = settingsData;

    const handleHeaderCheck = ( value ) => {
        if( value) setActiveRow( [...gatewayProviderSettings.map((entry) => entry.code)]);
        else setActiveRow([]);
    }

    const handleStatusChange = ( value, pscode ) => {
        const finder = gatewayProviderSettings.find(( ele ) => ele.code === pscode);
        finder["status"] = value?"active": "inactive";
        setData({...settingsData,gatewayProviderSettings:[...gatewayProviderSettings]});
    }

    const handleCheckList = ( value, pscode ) => {
        const idx = activeRow.indexOf( pscode );
        if( value) setActiveRow( [...activeRow, pscode ] );
        else {
            activeRow.splice( idx, 1);
            setActiveRow([...activeRow])
        }
    }
    const localData = gatewayProviderSettings && gatewayProviderSettings.map((ele) => {
        return {
            ...ele,
            code: codeDiv(ele,code),
            status: statusDiv(ele), 
            action: actionDiv(ele, handleStatusChange),
            checkBox: (
                <Switch
                    onChange={(e) => handleCheckList(e.target.checked, ele.code)} 
                    checked={activeRow.indexOf(ele.code) !== -1}
                />),
            className: activeRow && activeRow.find((itr) => itr === ele.code)? 'activeRow' :''
        }
    });

    const columns = [
        {
            Header: (
                <Switch
                    onClick={(e) => handleHeaderCheck(e.target.checked)} 
                />
            ),
            accessor: 'checkBox',
            disableSortBy: true
        },
        {
            Header: 'Code',
            accessor: 'code',
            selector: 'code',
            sortType: 'basic',
        },
        {
            Header: 'Name',
            accessor: 'name',
            
        },
        {
            Header: 'Value',
            accessor: 'value'
        },
        {
            Header: 'Status',
            accessor: 'status',
            disableSortBy: true
        },
        {
            Header: 'Actions',
            accessor: 'action',
            disableSortBy: true,
            className: 'actionCol'
        }
    ];

    const isEnabled = gatewayProviderSettings && activeRow.length !== 0 && ( [ ...gatewayProviderSettings.filter((ele ) => activeRow.includes(ele.code))].filter(ele => ele.status === 'active').length === activeRow.length);
    const isDisabled = gatewayProviderSettings && activeRow.length !== 0  && ( [ ...gatewayProviderSettings.filter((ele ) => activeRow.includes(ele.code))].filter(ele => ele.status === 'inactive').length === activeRow.length);
    let btnText = '';
    if ( isEnabled ) {
        btnText = 'Disable';
    }  else if ( isDisabled ) {
        btnText = 'Enable';  
    } 

    return(
        <div className="viewLayout-gm">
            <div className="redirect">
                <Link to={`/gatewaymanagment/:${id}`}>
                    <Image src={backIcon}  className="icon"/>
                </Link>
                <b>{code} - { description}</b>
            </div>
            <Card>
                <Card.Body>
                    <div className="cardHeader">
                        <Card.Title className="cardTitle">Gateway Provider Details</Card.Title>
                    </div>
                    <Card.Text>
                    <Container>
                    <DetailsLabel 
                            labelName={"Provider Code"} 
                            valueName={<InputText value={code} className="feildLabel" disabled/>}
                            labelClassName={"bodyRowLabel"}
                            valueClassName={"bodyRowValue"}
                            smValue={2}
                            rowClassName="rowMargin"
                        />
                        <DetailsLabel 
                            labelName={"Description"} 
                            valueName={<InputText value={description} className="feildLabel" />}
                            labelClassName={"bodyRowLabel"}
                            valueClassName={"bodyRowValue"}
                            smValue={2}
                            rowClassName="rowMargin"
                        />
                        <DetailsLabel 
                            labelName={"Provider URL"} 
                            valueName={<InputText value={providerURL} className="feildLabel" />}
                            labelClassName={"bodyRowLabel"}
                            valueClassName={"bodyRowValue"}
                            smValue={2}
                            rowClassName="rowMargin"
                        />
                        <DetailsLabel 
                            labelName={"Provider Context Root"} 
                            valueName={<InputText value={providerContextRoot} className="feildLabel" />}
                            labelClassName={"bodyRowLabel"}
                            valueClassName={"bodyRowValue"}
                            smValue={2}
                            rowClassName="rowMargin"
                        />
                        <DetailsLabel 
                            labelName={"Status"} 
                            valueName={
                                <div className="flex">
                                    <Switch 
                                        type="switch"
                                        id={`custom-switch-${code}-active-modal`}
                                        defaultChecked={status === "active"}
                                    />
                                    <span className="mt2">{status?"Enabled":"Disabled"}</span>
                                </div>
                            }
                            labelClassName={"bodyRowLabel"}
                            valueClassName={"bodyRowValue"}
                            smValue={2}
                            rowClassName="rowMargin"
                        />
                    </Container>
                    </Card.Text>
                </Card.Body>
            </Card>
            <div className="tableBlock">
                <Card className="mt16">
                    <Card.Body>
                    <div className="gatewaySettings">    
                        <div className="searchCard">
                            <Row className="mb15">
                                <Col sm={8}>
                                    <b>Gateway Provider Details</b>
                                </Col>
                                <Col className="alignRight">
                                    <BDOButton variant="secondary" >
                                        Add Provider Setting
                                    </BDOButton>
                                </Col>
                            </Row>
                            <div className="btnBlock">
                                {
                                    (activeRow.length > 0) 
                                    ? (
                                        <>
                                            {btnText && <BDOButton variant="primary" className="mr5">{btnText} </BDOButton>}
                                            <BDOButton variant="primary" className="danger">Delete</BDOButton>
                                            <span className="highlighter">{activeRow.length} items selected</span>
                                        </>
                                    ) : ''
                                }
                            </div>
                            
                            <div className="dataBlock">
                                {
                                    localData !== undefined
                                    ?  (
                                    <DataTable 
                                        columns={columns}
                                        data={localData}
                                        showPagination={true}
                                    />):(
                                        <div className="alignCenter">
                                            <Spinner animation="border" />
                                        </div>
                                    )
                                }
                            </div>
                        </div>
                    </div>
                    </Card.Body>
                </Card>
            </div>
        </div>
    )
}
export default ViewGatewayProviders;
