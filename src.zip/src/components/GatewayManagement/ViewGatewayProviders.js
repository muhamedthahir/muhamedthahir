/* eslint-disable react-hooks/exhaustive-deps */
import React, { useState, useEffect, useRef } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import DetailsLabel from './DetailsLabel';
import {
    Card, Image, Spinner, Row,
    Col, Container, Form
} from 'react-bootstrap';
import { Link, useHistory } from 'react-router-dom';
import './styles/viewGatewaySettings.scss';
import Switch from '../Global/Switch/Switch';
import DataTable from '../Global/DataTable/DataTable';
import EditIcon from '../../assets/icons/icon-edit-outline.svg';
import DeleteIcon from '../../assets/icons/icon-delete.svg';
import BDOToast from '../Global/BDOToast/BDOToast';
import backIcon from '../../assets/icons/backIcon.png';
import { Formik } from 'formik';
import BDOButton from '../Global/Button/BDOButton'
import * as Yup from 'yup';
import InputText from '../../components/Global/Input/InputText';
import {
    retrieveGatewayProvidersApi, updateGwProviderLocalData , addProvider
} from '../../actions/gatewaymanagement';
import { useMsal  } from "@azure/msal-react";


const codeDiv = (data, providerName, idx, isView) => (
    <Link
        className="modalLink"
        to={{
            pathname: `/gatewaymanagment/gatewayProvider/${providerName}/${data.code}`,
            state: { storage: "local", idx, action: 'view', parentIsView: isView }
        }}
    >
        {data.code}
    </Link>
)

const statusDiv = (settingsdata) => {
    let stat = 'Disabled';
    let className = 'status_disabled';
    if (settingsdata.status) {
        stat = 'Enabled';
        className = 'status_enabled';
    }
    if (settingsdata.forApproval) {
        stat = 'For Approval';
        className = 'forApproval';
    }
    return (
        <div className={className}>{stat}</div>
    )
}

const actionDiv = (ele, handleStatusChange, id, history, rIdx, handleDelete, isView) => (
    (!ele.forApproval) ? (
        <div className="actionDiv" key={`action_${ele.code}`}>
            <Switch
                type="switch"
                id={`custom-switch-${ele.code}`}
                disabled={isView ? true : false}
                checked={ele.status}
                onChange={(e) => handleStatusChange(e.target.checked, ele.code)}
            />
            {!isView && <div className="editDiv" onClick={
                () => history.push({
                    pathname: `/gatewaymanagment/gatewayProvider/${id}/${ele.code}`,
                    state: { storage: "local", idx: rIdx }
                })}>
                <Image src={EditIcon} className="icon" />
            </div>}
            {ele.code === "To be generated" ? (
                <div className="deleteDiv">
                    <Image onClick={() => handleDelete(rIdx)} src={DeleteIcon} className="icon" />
                </div>
            ) : ''}
        </div>
    ) : ''
);

const renderError = (formik, paramname) => (
    formik.errors[(paramname)] ? (
        <span className='mb-1 error-text'>
            {formik.errors[(paramname)]}
        </span>
    ) : null
)

const getClassName = (formik, paramname) => {
    let returnMsg = "input-text";
    if (formik.errors[(paramname)]) return returnMsg + " error"
    return returnMsg
}

let pageProperty = {}

function ViewGatewayProviders(props) {
    const dispatch = useDispatch();
    const history = useHistory();
    const formikRef = useRef();
    const { instance } = useMsal();
    const accounts = instance.getAllAccounts();
    const accountUserId = (accounts && accounts[0]?.localAccountId) || "us-02";

    const {
        viewGatewayProviderRecord ={}
    } = useSelector(stateRed => stateRed.gatewayReducer);
    const { match: { params: { id } }, location: { state = {} } } = props;
    const { storage, action ,totalElements} = state;
    const [toastObj, setToastData] = useState({});
    const isView = action === "view"
    useEffect(() => {
        if( id !== "ADD") {
            dispatch(retrieveGatewayProvidersApi(id ,totalElements))
        } else  {
            if( viewGatewayProviderRecord && Object.keys(viewGatewayProviderRecord).length === 0) {
                dispatch(updateGwProviderLocalData({ 
                    data :{
                        gatewayProviderSettingList:[],
                    }
                }))
            }
        }
        if (props.location.toastObj) {
            setToastData(props.location.toastObj)
            window.scrollTo({
                top: 0,
                left: 0,
                behavior: "smooth"
            })
        }
        if (!isView) {
            window.onbeforeunload = (e) => {
                e.preventDefault();
                e.returnValue = '';
            }
            const listener = history.listen((loc) => {
                const allowedPath = ["/gatewaymanagment/gatewayProvider"]
                const { location: { pathname } } = history;
                if (allowedPath.filter(ele => pathname.includes(ele)).length === 0 && pathname !== `/gatewaymanagment/gatewayProviders/${id}`) {
                    if (!window.confirm("Leaving the page will discard any unsaved changes")) {
                        history.go(-1);
                    } else {
                        clearData();
                    }
                } else {
                    window.onbeforeunload = undefined;
                }
            })
            return () => {
                window.onbeforeunload = undefined;
                return listener()
            }
        }

    }, []);
    const { data = {} } = viewGatewayProviderRecord;
    const recData = data;
    const [settingsData = recData, setData] = useState()
    const {
        gatewayProviderSettingList = [], fieldCode, fieldName
    } = (settingsData || {});
    const validationSchema = {
        //fieldCode: Yup.string().max(20, 'Must be 20 characters or less'),
        fieldName: Yup.string()
        .matches(/^[A-Za-z0-9 _]*$/, 'Please enter valid name')
        .max(30, 'Must be 30 characters or less')
        .required('Required field'),
        fieldDescription: Yup.string()
        .max(50, 'Must be 50 characters or less')
        .required('Required field'),
        // clientId: Yup.string(),
        // secretId: Yup.string(),
        gatewayDomain: Yup.string().required('Required field'),
        gatewayPort: Yup.string().required('Required field'),
        reason: Yup.string().max(50, 'Must be 50 characters or less').required('Required field'),
    }
    const handleStatusChange = (value, pscode) => {
        const finder = gatewayProviderSettingList.find((ele) => ele.code === pscode);
        finder["status"] = value;
        finder["isUpdate"] = true;
        setData({ ...settingsData, gatewayProviderSettingList: [...gatewayProviderSettingList] });
    }
    const clearData = () => {
        dispatch(updateGwProviderLocalData({}))
    }
    const handleDelete = (rIdx) => {
        gatewayProviderSettingList.splice(rIdx, 1);
        setData({ ...recData, gatewayProviderSettingList: gatewayProviderSettingList })
    }
    const returnPageProperty = (pgSize, pgIndex) => {
        pageProperty["pageNo"] = pgIndex + 1;
        pageProperty["pageSize"] = pgSize;
    }
    const handleSubmitProvider = (storageType, values) => {
        dispatch(addProvider(values, accountUserId,  (respData={}) => {
            const { referenceId } = (respData.data || {});
            if( respData.data.ccmErrorCode && respData.data.errorDescription) {
                setToastData({ 
                    toastState: true, 
                    toastMessage: `${respData.data.ccmErrorCode} - ${respData.data.errorDescription}`, 
                    toastType: "warning"
                });
                window.scrollTo({
                    top: 0,
                    left:0,
                    behavior: "smooth"
                });
            }
            else if( respData.data && respData.data.errorList && Object.values(respData.data.errorList).length> 0) {
                setToastData({ toastState: true, toastMessage: Object.values(respData.data.errorList).join("\n"), referenceId, toastType: "warning"});
                window.scrollTo({
                    top: 0,
                    left:0,
                    behavior: "smooth"
                });
            }
            else if( id === "ADD") {
                goBack({ toastMessage: `Gateway Provider submitted for approval . Reference number ${referenceId}`, toastState: true, toastType: 'success'})
            }
          }));
    }
    const goBack = (toastData) => {
        clearData();
        history.push({ pathname:`/gatewaymanagment/providers` ,  state: { toastData }});
    }
    const localObj = gatewayProviderSettingList && gatewayProviderSettingList.map((ele, rIdx) => {
        return {
            ...ele,
            code: codeDiv(ele, id, rIdx, isView),
            status: statusDiv(ele),
            action: actionDiv(ele, handleStatusChange, id, history, rIdx, handleDelete, isView),
        }
    });
    const addProviderSetting = (values, setErrors) => {
        if (!values.fieldName) {
            setErrors({ fieldName: 'Provider Name is required' })
        } else {
            history.push({
                pathname: `/gatewaymanagment/gatewayProvider/${id}/ADD`,
                state: {
                    storage: "local"
                }
            })
        }

    }
    const columns = [
        {
            Header: 'Code',
            accessor: 'code',
            selector: 'code',
            sortType: 'basic',
        },
        {
            Header: 'Name',
            accessor: 'fieldName',

        },
        {
            Header: 'Value',
            accessor: 'fieldValue'
        },
        {
            Header: 'Status',
            accessor: 'status',
            disableSortBy: true
        },
        {
            Header: 'Actions',
            accessor: 'action',
            disableSortBy: true,
            className: 'actionCol'
        }
    ];
    return (
        <div className="viewLayout-gm gatewaySettings">
            <div className="redirect">
                <div style={{ cursor: 'pointer' }} onClick={() => goBack()}>
                    <Image src={backIcon} className="icon" />
                </div>
                <b>{(id === "ADD") ? "Add Gateway Provider" : `${fieldCode} - ${fieldName}`}</b>
            </div>
            {
                toastObj.toastState && (
                    <BDOToast
                        openState={toastObj.toastState}
                        type={toastObj.toastType}
                        bodyMessage={toastObj.toastMessage}
                        onClose={() => { setToastData({}) }}
                    />
                )
            }
            <Formik
                initialValues={{ status: false, internalApiIntegration: false, ...settingsData, code: settingsData?.gatewayProvider?.code || settingsData?.code}}
                enableReinitialize
                validationSchema={Yup.object().shape(validationSchema)}
                innerRef={formikRef}
                onSubmit={(values) => {
                    handleSubmitProvider(storage, values)
                }}
            >
                {({
                    errors, touched, values, handleChange,
                    setFieldValue, handleBlur, setErrors
                }) => (
                    <Form>
                        <Card>
                            <Card.Body>
                                <div className="cardHeader">
                                    <Card.Title className="cardTitle">Gateway Provider Details</Card.Title>
                                </div>
                                <Card.Text>
                                    <Container>
                                        { id !== "ADD" &&
                                        <DetailsLabel
                                            labelName={"Provider Code"}
                                            valueName={
                                                <>
                                                    <InputText
                                                        className={`feildLabel ${getClassName({ values,  errors}, 'fieldCode')}`}
                                                        value={values.fieldCode}
                                                        onChange={(e) => {
                                                            data["fieldCode"] = e.target.value;
                                                            handleChange(e)
                                                        }}
                                                        onBlur={handleBlur}
                                                        disabled={true}
                                                        name='fieldCode'
                                                        placeholder='Enter Gateway Code'
                                                    />
                                                    {renderError({ values,  errors}, 'fieldCode')}
                                                </> 
                                            }
                                            labelClassName={"bodyRowLabel"}
                                            valueClassName={"bodyRowValue"}
                                            smValue={2}
                                            rowClassName="rowMargin"
                                        /> }
                                        <DetailsLabel
                                            labelName={"Provider Name"}
                                            valueName={
                                                <>
                                                    <InputText
                                                        className={`feildLabel ${getClassName({ values,  errors}, 'fieldName')}`}
                                                        value={values.fieldName}
                                                        onChange={(e) => {
                                                            data["fieldName"] = e.target.value;
                                                            handleChange(e)
                                                        }}
                                                        onBlur={handleBlur}
                                                        disabled={isView ? true : false}
                                                        name='fieldName'
                                                        placeholder='Enter Provider Name'
                                                    />
                                                    {renderError({ values,  errors}, 'fieldName')}
                                                </> 
                                            }
                                            labelClassName={"bodyRowLabel"}
                                            valueClassName={"bodyRowValue"}
                                            smValue={2}
                                            rowClassName="rowMargin"
                                        />
                                        <DetailsLabel
                                            labelName={"Provider Description"}
                                            valueName={
                                                <>
                                                    <InputText
                                                        as="textarea"
                                                        rows={3}
                                                        className={`feildLabel ${getClassName({ values,  errors}, 'fieldDescription')}`}
                                                        value={values.fieldDescription}
                                                        onChange={(e) => {
                                                            data["fieldDescription"] = e.target.value;
                                                            handleChange(e)
                                                        }}
                                                        onBlur={handleBlur}
                                                        name='fieldDescription'
                                                        disabled={isView ? true : false}
                                                        placeholder='Enter Provider Description' 
                                                    />
                                                    {renderError({ values,  errors}, 'fieldDescription')}
                                                </>
                                            }
                                            labelClassName={"bodyRowLabel"}
                                            valueClassName={"bodyRowValue"}
                                            smValue={2}
                                            rowClassName="rowMargin"
                                        />
                                        <DetailsLabel
                                            labelName={"Internal Api Integration"}
                                            valueName={
                                                    <div className="flex">
                                                        <Switch
                                                            type="switch"
                                                            id={`custom-internalApiIntegration-${fieldCode}-active-modal`}
                                                            onChange={(e) => {
                                                                data["internalApiIntegration"] = e.target.checked;
                                                                setFieldValue("internalApiIntegration" , e.target.checked)
                                                            }}
                                                            name='internalApiIntegration'
                                                            disabled={isView ? true : false}
                                                            checked={(values.internalApiIntegration === undefined || values.internalApiIntegration === false)? false : true}
                                                        />
                                                        <span className="mt2">{values.internalApiIntegration?'True': 'False'}</span>
                                                    </div>
                                            }
                                            labelClassName={"bodyRowLabel"}
                                            valueClassName={"bodyRowValue"}
                                            smValue={2}
                                            rowClassName="rowMargin"
                                        />
                                        <DetailsLabel
                                            labelName={"Client ID"}
                                            valueName={
                                            <>
                                            <InputText
                                                className={`feildLabel ${getClassName({ values,  errors}, 'clientId')}`}
                                                value={values.clientId}
                                                onChange={(e) => {
                                                    data["clientId"] = e.target.value;
                                                    handleChange(e)
                                                }}
                                                onBlur={handleBlur}
                                                disabled={isView ? true : false}
                                                name='clientId'
                                                placeholder='Enter ClientID'
                                            />
                                            {renderError({ values,  errors}, 'clientId')}
                                        </> 
                                        }
                                            labelClassName={"bodyRowLabel"}
                                            valueClassName={"bodyRowValue"}
                                            smValue={2}
                                            rowClassName="rowMargin"
                                        />
                                        <DetailsLabel
                                            labelName={"Secret ID"}
                                            valueName={
                                            <>
                                            <InputText
                                                className={`feildLabel ${getClassName({ values,  errors}, 'secretId')}`}
                                                value={values.secretId}
                                                onChange={(e) => {
                                                    data["secretId"] = e.target.value;
                                                    handleChange(e)
                                                }}
                                                onBlur={handleBlur}
                                                disabled={isView ? true : false}
                                                name='secretId'
                                                placeholder='Enter SecretID'
                                            />
                                            {renderError({ values,  errors}, 'secretId')}
                                        </> 
                                        }
                                            labelClassName={"bodyRowLabel"}
                                            valueClassName={"bodyRowValue"}
                                            smValue={2}
                                            rowClassName="rowMargin"
                                        />
                                        
                                        <DetailsLabel
                                            labelName={"Gateway URL"}
                                            valueName={
                                            <>
                                            <InputText
                                                className={`feildLabel ${getClassName({ values,  errors}, 'gatewayDomain')}`}
                                                value={values.gatewayDomain}
                                                onChange={(e) => {
                                                    data["gatewayDomain"] = e.target.value;
                                                    handleChange(e)
                                                }}
                                                onBlur={handleBlur}
                                                disabled={isView ? true : false}
                                                name='gatewayDomain'
                                                placeholder='Enter Gateway Domain'
                                            />
                                            {renderError({ values,  errors}, 'gatewayDomain')}
                                        </> 
                                        }
                                            labelClassName={"bodyRowLabel"}
                                            valueClassName={"bodyRowValue"}
                                            smValue={2}
                                            rowClassName="rowMargin"
                                        />
                                        <DetailsLabel
                                            labelName={"Gateway Port"}
                                            valueName={
                                            <>
                                            <InputText
                                                className={`feildLabel ${getClassName({ values,  errors}, 'gatewayPort')}`}
                                                value={values.gatewayPort}
                                                onChange={(e) => {
                                                    data["gatewayPort"] = e.target.value;
                                                    handleChange(e)
                                                }}
                                                onBlur={handleBlur}
                                                disabled={isView ? true : false}
                                                name='gatewayPort'
                                                placeholder='Enter Gateway Port'
                                            />
                                            {renderError({ values,  errors}, 'gatewayPort')}
                                        </> 
                                        }
                                            labelClassName={"bodyRowLabel"}
                                            valueClassName={"bodyRowValue"}
                                            smValue={2}
                                            rowClassName="rowMargin"
                                        />
                                        <DetailsLabel
                                            labelName={"Status"}
                                            valueName={
                                                (values.forApproval===false || values.forApproval === undefined)? (
                                                    <div className="flex">
                                                        <Switch
                                                            type="switch"
                                                            id={`custom-switch-${fieldCode}-active-modal`}
                                                            onChange={(e) => {
                                                                data["status"] = e.target.checked;
                                                                setFieldValue("status" , e.target.checked)
                                                            }}
                                                            name='status'
                                                            disabled={isView ? true : false}
                                                            checked={(values.status === undefined || values.status === false)? false : true}
                                                        />
                                                        <span className="mt2">{values.status?'Enabled': 'Disabled'}</span>
                                                    </div>
                                                ): (
                                                    <InputText  className="feildLabel" value="For Approval" disabled/>
                                                )
                                            }
                                            labelClassName={"bodyRowLabel"}
                                            valueClassName={"bodyRowValue"}
                                            smValue={2}
                                            rowClassName="rowMargin"
                                        />
                                        { !isView && <DetailsLabel
                                            labelName={"Reason"}
                                            valueName={
                                            <>
                                            <InputText
                                                className={`feildLabel ${getClassName({ values,  errors}, 'reason')}`}
                                                value={values.reason}
                                                onChange={(e) => {
                                                    data["reason"] = e.target.value;
                                                    handleChange(e)
                                                }}
                                                onBlur={handleBlur}
                                                disabled={isView ? true : false}
                                                name='reason'
                                                placeholder='Enter Reason'
                                            />
                                            {renderError({ values,  errors}, 'reason')}
                                        </> 
                                        }
                                            labelClassName={"bodyRowLabel"}
                                            valueClassName={"bodyRowValue"}
                                            smValue={2}
                                            rowClassName="rowMargin"
                                        />}
                                    </Container>
                                </Card.Text>
                            </Card.Body>
                        </Card>
                        <div className="tableBlock">
                            <Card className="mt16">
                                <Card.Body>
                                    <div className="gatewaySettings">
                                        <div className="searchCard">
                                            <Row className="mb15">
                                                <Col sm={8}>
                                                    <b>Gateway Provider Settings</b>
                                                </Col>
                                                <Col className="alignRight">
                                                    {!isView && <BDOButton variant="secondary" onClick={() => addProviderSetting(values, setErrors)}>
                                                        Add Provider Setting
                                                    </BDOButton>}
                                                </Col>
                                            </Row>
                                            <div className="dataBlock">
                                                {
                                                    localObj !== undefined
                                                        ? (
                                                            <DataTable
                                                                columns={columns}
                                                                data={localObj}
                                                                showPagination={true}
                                                                returnPageProperty={returnPageProperty}
                                                                pageProperty={pageProperty}
                                                            />) : (
                                                            <div className="alignCenter">
                                                                <Spinner animation="border" />
                                                            </div>
                                                        )
                                                }
                                            </div>
                                        </div>
                                    </div>
                                </Card.Body>
                            </Card>
                        </div>
                    </Form>
                )}
            </Formik>
            {!isView && <div className="settingsBtnBlock">
                <BDOButton variant="secondary" onClick={() => goBack()} >Cancel</BDOButton>
                <BDOButton variant="primary" onClick={() => formikRef.current.handleSubmit()}>{(id === 'ADD') ? 'Add' : 'Save'}</BDOButton>
            </div>}
        </div>
    )
}
export default ViewGatewayProviders;
