/* eslint-disable react-hooks/exhaustive-deps */
import React, { useEffect, useState, useRef } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Card, Row, Col, Image, ListGroup } from "react-bootstrap";
import BDOButton from "../Global/Button/BDOButton";
import UnlockIcon from "../../assets/icons/unlock-outline.svg";
import BDOModal from "../Global/BDOModal/BDOModal";
import BDOToast from "../Global/BDOToast/BDOToast";
import WarningIcon from "../../assets/icons/icon-surface-notifstatus-warning.svg";
import BlockedIcon from "../../assets/icons/Icon-blocked.svg";
import UnblockModalBody from "./UnblockModalBody";
import Moment from "moment";
import {
  retrieveAllChannal,
  updateChannelStatus,
  retrieveChannelSummary,
} from "../../actions/gatewaymanagement";
import ChannelList from "./ChannelList.js";
import "./styles/viewAllChannal.scss";

const statusDiv = (rowData) => {
  const { status, for_approval } = rowData;
  let className = "";
  let text = "";
  if (status === "AUTO_BLOCKED_BY_CCM") {
    className = "statusblocked";
    text = "Auto Blocked by CCM";
  }
  if (status === "REJECTION_THRESHOLD_BREACHED") {
    className = "channelstatusforapproval";
    text = "Rejection Threshold Breached";
  }
  if (for_approval === true) {
    className = "channelstatusforapproval";
    text = "For Approval";
  }
  return (
    <div className={className}>
      <b>{text}</b>
    </div>
  );
};

const unlockImgDiv = (rowData, openHandler) => {
  const { status, for_approval } = rowData;
  let ele = "";
  if (status === "AUTO_BLOCKED_BY_CCM" && for_approval === false) {
    ele = (
      <div className={`pointerClass unblockedimg`}>
        <Image
          src={UnlockIcon}
          className="icon"
          onClick={() => openHandler(rowData)}
        />
      </div>
    );
  }
  return ele;
};
const rateDiv = (rowData) => {
  const { status, for_approval } = rowData;
  return (
    <span
      className={
        status === "AUTO_BLOCKED_BY_CCM" || for_approval === true
          ? "name-blocked"
          : ""
      }
    >
      {rowData.rate}%
    </span>
  );
};
function ViewAllChannels(props) {
  const { canUnblocked } = props;
  const dispatch = useDispatch();
  const retData = useSelector((state) => state.gatewayReducer);
  let { viewAllChannal = {}, channelSummary = {} } = retData;
  const {
    data = [],
    currentPageNumber = 1,
    totalPages = 1,
    errorResponse = {},
  } = viewAllChannal;
  const { channel_summary = {} } = channelSummary.data || {};
  let errorDiv = "";
  if (errorResponse) {
    errorDiv = (
      <span>
        {errorResponse.ccmErrorCode}- {errorResponse.errorDescription}
      </span>
    );
  }
  useEffect(() => {
    dispatch(retrieveAllChannal(`?page=${1}&size=${10}`));
    dispatch(retrieveChannelSummary());
  }, []);
  const formIkRef = useRef();
  let [localData = data, setData] = useState();
  let [activeBlock, setActiveBlock] = useState("");
  const [isPageChanged, movePage] = useState(false);
  const [toastState, setToastState] = useState(false);
  const [toastData, setToastData] = useState({});
  const [modalState, setModalState] = useState(false);
  const [modalData, setModalData] = useState({});
  let columns = [
    {
      Header: "Channel Code",
      accessor: "code",
      selector: "code",
      sortType: "basic",
    },
    {
      Header: "Sender",
      accessor: "sender",
      sortType: "basic",
    },
    {
      Header: "Gateway Type",
      accessor: "gateway_type",
      sortType: "basic",
    },
    {
      Header: "Rate",
      accessor: "rate",
      sortType: "basic",
    },
    {
      Header: "Max. Rate",
      accessor: "max_rate",
      sortType: "basic",
    },
    {
      Header: "Thres. Rate",
      accessor: "thres_rate",
      sortType: "basic",
    },
    {
      Header: "Status",
      accessor: "status",
      disableSortBy: true,
    },
    {
      Header: "Update Date",
      accessor: "update_date",
      sortType: "basic",
    },
  ];
  if (canUnblocked) {
    columns = [
      ...columns,
      {
        Header: "",
        accessor: "blockImg",
        disableSortBy: true,
      },
    ];
  }
  const handleServerSidePagination = (pageNo, pageSize) => {
    dispatch(retrieveAllChannal(`?page=${pageNo}&size=${pageSize}`));
  };

  const handleClick = (category, ipText) => {
    const categoryFilterdData = [...data].filter((ele) => ele.code === ipText);
    setData(categoryFilterdData);
  };

  const openHandler = (rwData) => {
    setModalState(true);
    setModalData(rwData);
  };

  const formatDate = (date) => {
    let returnDate = "0000/00/00";
    if (date) returnDate = Moment(date).format("MM/DD/YYYY");
    return returnDate;
  };

  const localObj =
    localData &&
    localData.map((ele) => {
      return {
        ...ele,
        rate: rateDiv(ele),
        max_rate: ele.max_rate + "%",
        thres_rate: ele.thres_rate + "%",
        status: statusDiv(ele),
        blockImg: unlockImgDiv(ele, openHandler),
        update_date: formatDate(ele.update_date),
        className:
          ele.status === "AUTO_BLOCKED_BY_CCM" || ele.for_approval === true
            ? "blocked"
            : "",
      };
    });

  const handleBlockedList = () => {
    const tempData = data.filter(
      (elem) =>
        elem.status === "AUTO_BLOCKED_BY_CCM" && elem.for_approval === false
    );
    setData(tempData);
    setActiveBlock("blocked");
  };

  const handleReachedThresholdList = () => {
    const tempData = data.filter(
      (elem) =>
        elem.status !== "AUTO_BLOCKED_BY_CCM" &&
        elem.for_approval === false &&
        Number(elem.rate.replace("%", "")) >=
          Number(elem.thres_rate.replace("%", ""))
    );
    setData(tempData);
    setActiveBlock("threshold");
  };

  const handleOnChangeStatus = (reqObj) => {
    dispatch(
      updateChannelStatus(reqObj, (respData) => {
        const { responseStatus, referenceId } = respData;
        if (responseStatus === "200 OK") {
          setToastState(true);
          dispatch(retrieveChannelSummary());
          dispatch(retrieveAllChannal(`?page=${1}&size=${10}`));
          setToastData({
            message: "Channel unblock request submitted for approval",
            reference_number: referenceId,
            type: "success",
          });
          closeModal(true);
          window.scrollTo({
            top: 0,
            left: 0,
            behavior: "smooth",
          });
        }
        if (respData.errorResponse) {
          setToastState(true);
          let msg = respData.errorResponse.errorDescription;
          dispatch(retrieveChannelSummary());
          dispatch(retrieveAllChannal(`?page=${1}&size=${10}`));
          setToastData({
            message: `${respData.errorResponse.ccmErrorCode} : ${msg}`,
            type: "warning",
          });
          closeModal(true);
          window.scrollTo({
            top: 0,
            left: 0,
            behavior: "smooth",
          });
        }
      })
    );
  };

  const closeModal = (noUpdate = false) => {
    setModalData({});
    setModalState(false);
    if (!noUpdate) {
      setData([...localData]);
    }
  };

  const modalFooterContent = (
    <div>
      <BDOButton variant="secondary" onClick={closeModal}>
        Cancel
      </BDOButton>
      <BDOButton
        variant="primary"
        onClick={() => formIkRef.current.handleSubmit()}
      >
        Unblock
      </BDOButton>
    </div>
  );

  const onToastClose = () => {
    setToastState(false);
    setToastData({});
  };

  return (
    <div className="gateWayTypeManagement">
      <div className="headerBlock">
        <div>
          <b>View Channel Status</b>
        </div>
      </div>
      {toastState && (
        <BDOToast
          openState={toastState}
          type={toastData.type}
          bodyMessage={`${toastData.message}. ${
            toastData.reference_number
              ? "Reference No: " + toastData.reference_number
              : ""
          }`}
          onClose={onToastClose}
        />
      )}
      <div className="tableBlock">
        <Row>
          <Col sm={3}>
            <div className="leftBox">
              <Card>
                <Card.Body>
                  <b>Channel Summary </b>
                  <ListGroup
                    className={`mt15 ${
                      activeBlock === "blocked" ? "active" : ""
                    }`}
                    onClick={() => handleBlockedList()}
                  >
                    <ListGroup.Item className="flexDiv blocked">
                      <div>
                        <Image src={BlockedIcon} className="blockIcon" />
                        <b>Blocked</b>
                      </div>
                      <div>
                        <b>{channel_summary.blocked_total}</b>
                      </div>
                    </ListGroup.Item>
                    {channel_summary.blocked &&
                      Object.keys(channel_summary.blocked).map((ele) => (
                        <ListGroup.Item className="flexDiv">
                          <div>{ele.toUpperCase()}</div>
                          <div>
                            <b>{channel_summary.blocked[ele]}</b>
                          </div>
                        </ListGroup.Item>
                      ))}
                  </ListGroup>
                  <ListGroup
                    className={`thresBox ${
                      activeBlock === "threshold" ? "active" : ""
                    }`}
                    onClick={() => handleReachedThresholdList()}
                  >
                    <ListGroup.Item className="flexDiv threshold">
                      <div>
                        <Image src={WarningIcon} className="blockIcon" />
                        <b>Reached Threshold</b>
                      </div>
                      <div>
                        <b>{channel_summary.reached_threashold_total}</b>
                      </div>
                    </ListGroup.Item>
                    {channel_summary.reached_threashold &&
                      Object.keys(channel_summary.reached_threashold).map(
                        (ele) => (
                          <ListGroup.Item className="flexDiv">
                            <div>{ele.toUpperCase()}</div>
                            <div>
                              <b>{channel_summary.reached_threashold[ele]}</b>
                            </div>
                          </ListGroup.Item>
                        )
                      )}
                  </ListGroup>
                </Card.Body>
              </Card>
            </div>
          </Col>
          <Col sm={9} className="padding0">
            <div className="rightBox">
              <Card>
                <Card.Body>
                  <ChannelList
                    data={localObj || []}
                    col={columns}
                    handleClick={handleClick}
                    errorResponse={errorResponse}
                    totalPages={totalPages}
                    currentPageNumber={currentPageNumber}
                    isPageChanged={isPageChanged}
                    movePage={movePage}
                    handleServerSidePagination={handleServerSidePagination}
                    errorDiv={errorDiv}
                  />
                </Card.Body>
              </Card>
            </div>
          </Col>
        </Row>
      </div>
      {modalState && (
        <BDOModal
          header={"Unblock Channel"}
          body={
            <UnblockModalBody
              modalData={modalData}
              setModalData={setModalData}
              formIkRef={formIkRef}
              handleOnChangeStatus={handleOnChangeStatus}
            />
          }
          footer={modalFooterContent}
          openState={modalState}
          modalProps={{ onHide: closeModal }}
        />
      )}
    </div>
  );
}
export default ViewAllChannels;
