import React, { useEffect, useState, useRef } from 'react';
import { useDispatch, useSelector } from "react-redux";
import {
    Card, Row, Col,
    Image, ListGroup,
} from 'react-bootstrap';
import BDOButton from '../Global/Button/BDOButton'
import UnlockIcon from '../../assets/icons/unlock-outline.svg';
import BDOModal from '../Global/BDOModal/BDOModal';
import BDOToast from '../Global/BDOToast/BDOToast';
import UnblockModalBody from './UnblockModalBody';
import { retrieveAllChannal, updateChannelStatus }  from '../../actions/gatewaymanagement';
import ChannelList from './ChannelList.js';
import './styles/viewAllChannal.scss';
    
const statusDiv = (rowData) => {
    const { status } = rowData;
    let className = '';
    let text = '';
    if( status === "blocked") {
        className = "status"+status;
        text= status[0].toUpperCase() + status.substring(1, status.length)
    }
    return ( <div className={className}><b>{text}</b></div>)
};

const unlockImgDiv = (rowData, openHandler) => {
    const { status } = rowData;
    let ele = '';
    if( status === "blocked") {
        ele = (
            <div className={`pointerClass un${status}img`}>
                <Image 
                    src={UnlockIcon}
                    className="icon"
                    onClick={() => openHandler(rowData)}
                />
            </div>
        )
    }
    return (ele)
};

function ViewAllChannels(props) { 
    const dispatch = useDispatch();
    const retData = useSelector( state => state.gatewayReducer);
    let { viewAllChannal=[] }  = retData;
    const { data={}, totalPages=1} = viewAllChannal;
    const {channel_list = [], channel_summary = {}} = data
    useEffect(() => {
        dispatch(retrieveAllChannal(`page=${0}&size=${10}`));           
    }, []);
    const formIkRef = useRef();
    let [ localData=channel_list, setData] = useState();
    const [ toastState, setToastState ] = useState(false);
	const [ toastData, setToastData ] = useState({});
    const [ modalState, setModalState ] = useState(false);
	const [ modalData, setModalData ] = useState({});
    let columns = [
        {
            Header: 'Channel Code',
            accessor: 'code',
            selector: 'code',
            sortType: 'basic',
        },
        {
            Header: 'Sender',
            accessor: 'sender',
            sortType: 'basic',
        },
        {
            Header: 'Gateway Type',
            accessor: 'gateway_type',
            sortType: 'basic',
        },
        {
            Header: 'Rate',
            accessor: 'rate',
            sortType: 'basic',
        },
        {
            Header: 'Max. Rate',
            accessor: 'max_rate',
            sortType: 'basic',
        },
        {
            Header: 'Thres. Rate',
            accessor: 'thres_rate',
            sortType: 'basic',
        },
        {
            Header: 'Status',
            accessor: 'status',
            disableSortBy: true,
        },
        {
            Header: 'Update Date',
            accessor: 'update_date',
            sortType: 'basic',
        },
        {
            Header: '',
            accessor: 'blockImg',
            disableSortBy: true,
        },
    ];
    const handleServerSidePagination = ( pageNo, pageSize ) => {
        dispatch(retrieveAllChannal(`page=${pageNo}&size=${pageSize}`));
    }
    
    const  handleClick = ( category, ipText ) => {
        const categoryFilterdData = [ ...data ].filter(( ele ) => ele.code === ipText);
        setData(categoryFilterdData );
    }

    const openHandler = ( rwData ) => {
        setModalState(true);
        setModalData(rwData);
    }

    const localObj = localData && localData.map((ele) => {
            return {
                ...ele,
                status: statusDiv(ele),
                blockImg: unlockImgDiv(ele, openHandler),
                className: (ele.status === 'blocked' ) ? 'blocked' :'',
            }
        });
        
    const handleBlockedList = () => {
        const tempData = channel_list.filter(elem => elem.status === "blocked")
        setData(tempData);
    }

    const handleReachedThresholdList = () => {
        const tempData = channel_list.filter(elem => elem.status !== "blocked" && (Number(elem.rate.replace("%","")) >= Number(elem.thres_rate.replace("%",""))))
        setData(tempData);
    }

    const handleOnChangeStatus = ( reqObj ) => {
		dispatch(updateChannelStatus(reqObj, (respData) => {
            const { data : { message, reference_number }} = respData;
            let filteredList = [];
            if ( message) {
                filteredList = channel_list.filter(( ele ) => ele.code !== reqObj.code);
                setData([...filteredList]);
            }
            setToastState(true);
            setToastData({ message, reference_number, type: "success"});
            closeModal(true);
            window.scrollTo({
                top: 0,
                left:0,
                behavior: "smooth"
            });
        }));
	}

    const closeModal = ( noUpdate = false) => {
		setModalData({});
		setModalState(false);
        if( !noUpdate ) {
		    setData([...localData]);
        }
	}

    const modalFooterContent = (
		<div>
			<BDOButton variant="secondary" onClick={closeModal}>Cancel</BDOButton>
			<BDOButton variant="primary" onClick={() => formIkRef.current.handleSubmit()}>
				Unblock
			</BDOButton>
		</div>
	);
    
    const onToastClose = () => {
		setToastState(false);
        setToastData({});
	}

    const blockedTotal = channel_summary.blocked && Object.keys(channel_summary.blocked).reduce((ele,nextele) => channel_summary.blocked[ele] + channel_summary.blocked[nextele])
    const reachedThreasholdTot = channel_summary.reached_threashold && Object.keys(channel_summary.reached_threashold).reduce((ele,nextele) => channel_summary.reached_threashold[ele] + channel_summary.reached_threashold[nextele])
    return(
        <div className="gateWayTypeManagement">
            <div className="headerBlock">
                <div>
                    <b>View Channel Status</b>
                </div>
            </div>
            {
				toastState && (
					<BDOToast  
						openState={toastState}
						type={"success"}
						bodyMessage={`${toastData.message}. Reference No: ${toastData.reference_number}`}
						onClose={onToastClose} 
					/>
				)
			}
            <div className="tableBlock">
                <Row>
                    <Col sm={3}> 
                        <div className='leftBox'>
                            <Card>
                                <Card.Body>
                                    <b>Channel Summary </b>
                                    <ListGroup className="mt15" onClick={() => handleBlockedList()}> 
                                        <ListGroup.Item className="flexDiv blocked"><div><b>Blocked</b></div><div><b>{blockedTotal}</b></div></ListGroup.Item>
                                        {channel_summary.blocked && Object.keys(channel_summary.blocked).map(ele => (
                                            <ListGroup.Item className="flexDiv"><div>{ele.toUpperCase()}</div><div><b>{channel_summary.blocked[ele]}</b></div></ListGroup.Item>
                                        ))}
                                    </ListGroup>
                                    <ListGroup className="thresBox" onClick={() => handleReachedThresholdList()}> 
                                        <ListGroup.Item className="flexDiv threshold"><div><b>Reached Threshold</b></div><div><b>{reachedThreasholdTot}</b></div></ListGroup.Item>
                                        {channel_summary.reached_threashold && Object.keys(channel_summary.reached_threashold).map(ele => (
                                            <ListGroup.Item className="flexDiv"><div>{ele.toUpperCase()}</div><div><b>{channel_summary.reached_threashold[ele]}</b></div></ListGroup.Item>
                                        ))}
                                    </ListGroup>
                                </Card.Body>
                            </Card>
                        </div>
                    </Col>
                    <Col sm={9} className="padding0"> 
                        <div className='rightBox'>
                            <Card>
                                <Card.Body >
                                    <ChannelList data={localObj} col={columns} handleClick={handleClick} />
                                </Card.Body>
                            </Card>
                        </div>
                    </Col>
                </Row>
            </div>
            {
                modalState && (
                    <BDOModal
                        header={"Unblock Channel"}
                        body={
                            <UnblockModalBody 
                                modalData={modalData} 
                                setModalData={setModalData} 
                                formIkRef={formIkRef}
                                handleOnChangeStatus={handleOnChangeStatus}
                            />}
                        footer={modalFooterContent}
                        openState={modalState}
                        modalProps={{onHide:closeModal}}
                    />
                )
            }
        </div>
    )
}
export default ViewAllChannels;
