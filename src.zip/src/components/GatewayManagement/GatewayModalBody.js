import React, { useState } from "react";
import Switch from '../../components/Global/Switch/Switch';
import BDOButton from '../Global/Button/BDOButton';
import InputText from '../Global/Input/InputText';
import DataTable from "../Global/DataTable/DataTable";
import "./styles/viewAllGatewayType.scss";

const GatewayModalBody = (props) => {
    const { bodyData, selData = {}, closeModal,  onSubmitHandler } = props;
    const { gatewayProviderList } = selData;
    const [headerText, setHeaderText] = useState();
    const [headerClass, setHeaderClass] = useState();
    const setMessage = () => {
        if (gatewayProviderList && gatewayProviderList.length > 0) {
            const findActiveEle = gatewayProviderList
                .filter((ele) => ele.status)
                .map((retrnEle) =>
                    retrnEle.distributionPercentage ? retrnEle.distributionPercentage : 0
                );
            console.log('findActiveEle', gatewayProviderList)
            if (findActiveEle.length !== 0) {
                const calculateTotal = findActiveEle.reduce(
                    (prev, current) => prev + current
                );
                if (
                    calculateTotal > 100 &&
                    headerText !== `Excess :${calculateTotal - 100} %`
                ) {
                    setHeaderText(`Excess :${calculateTotal - 100} %`);
                    setHeaderClass("warningText");
                } else if (
                    calculateTotal < 100 &&
                    headerText !== `Remaining :${100 - calculateTotal} %`
                ) {
                    setHeaderText(`Remaining :${100 - calculateTotal} %`);
                    setHeaderClass("warningText");
                } else if (calculateTotal === 100 && headerText !== `Remaining : 0 %`) {
                    setHeaderText(`Remaining : 0 %`);
                    setHeaderClass("successText");
                }
            } else if (headerText !== `Remaining :100 %`) {
                setHeaderText(`Remaining :100 %`);
                setHeaderClass("warningText");
            }
        }
    }
    setMessage();
    
    let total = 0
    gatewayProviderList && gatewayProviderList.forEach(ele => {
        if( ele.status) total += (ele.distributionPercentage?ele.distributionPercentage:0)         
    })
    
    const ModalFooterContent = () => {
        let isButtonDisabled = false;
        isButtonDisabled = (total === 100 
            && (selData?.gatewayTypeDetails?.reason ?true:false)
        )
        console.log('isButtonDisabled22',isButtonDisabled, total)
        return (
            <>
                <BDOButton 
                    title="Cancel"
                    variant="secondary"
                    onClick={() => closeModal()} 
                />
                <BDOButton 
                    title="Reactivate"
                    variant="primary"
                    className="ml8"
                    disabled={!isButtonDisabled}
                    onClick={() => {
                        onSubmitHandler(selData)
                    }} 
                />
            </>
        )
    }
    const columns = [
        {
            accessor: "checkBox",
            disableSortBy: true,
        },
        {
            Header: "Code",
            accessor: "code",
            selector: "code"
        },
        {
            Header: "Description",
            accessor: "description",
        },
        {
            Header: () => (
                <>
                    <span>Distribution</span>
                    <p className={headerClass}>{headerText}</p>
                </>
            ),
            accessor: "distributionPercentage",
            disableSortBy: true,
        }
    ]
    const checkBoxDiv = (ele, code) => {
        return (
            <Switch
                onClick={(e) => {
                    gatewayProviderList.find(elem => elem.code === code).status = e.target.checked
                    setMessage()
                }}
                id={ele.code}
                defaultChecked={ele.status}
            />
        )
    }

    const constructInputDiv = (ele, idx) => {
        let divEle = '';
        if( ele.status) {
            divEle = (
                <div className="flex mr5">
                    <InputText
                        value={parseInt(ele.distributionPercentage ? ele.distributionPercentage : 0)}
                        onChange={(e) =>  {
                            gatewayProviderList[idx].distributionPercentage = parseInt(e.target.value)
                            setMessage()
                        }}
                        type={"number"}
                        className="feildDistribution"
                        min={0}
                        max={100}
                    />
                    <div className="percentageBlock">%</div>
                </div>
            )
        }
        return divEle
    };
    const localObj = gatewayProviderList && gatewayProviderList.map((ele, idx) => {
        return {
            ...ele,
            checkBox: checkBoxDiv(ele, ele.code),
            distributionPercentage: constructInputDiv(ele, idx)
        }
    })
    return (
        <>
            <div className="gatewayModal">
                <div className="contentBlock">
                    <span>To reactivate {bodyData.value?.name}. 
                        select  gateway providers to reactivate and enter the distribution  weights.
                        The distribution should total 100% before you can proceed.
                    </span>
                </div>
                <div className="dataBlock">
                    <DataTable
                        columns={columns}
                        data={localObj || []}
                        showPagination={false}
                        key={"gwprforgwtype"}
                        defaultPageSize={5}
                    />
                </div>
                <div>
                    <InputText 
                        onChange={(e) => {
                            selData.gatewayTypeDetails.reason = e.target.value;
                            setMessage()
                        }} 
                        placeholder="Enter reason"
                    />
                </div>
            </div>
            <hr />
            <div className="footerbox">
                <ModalFooterContent  />
            </div>
        </>
    )

}

export default GatewayModalBody;
