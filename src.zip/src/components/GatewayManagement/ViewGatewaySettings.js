import React, { useState, useEffect, useRef } from 'react';
import  {  useSelector, useDispatch } from 'react-redux';
import DetailsLabel from './DetailsLabel';
import { 
    Card,Image, Form,
} from 'react-bootstrap';
import BDOButton from '../Global/Button/BDOButton'
import { Link, useHistory } from 'react-router-dom';
import './styles/viewGatewaySettings.scss';
import Switch from '../Global/Switch/Switch';
import backIcon from '../../assets/icons/backIcon.png';
import { 
    retreiveAllSettingsCode, retrieveGatewaySettings, retrieveAllGatewayType,
    updateLocalValue
} from '../../actions/gatewaymanagement';
import InputText from '../../components/Global/Input/InputText';
import { Formik }  from 'formik';
import DateTimePicker from '../Global/DateTimePicker/DateTimePicker';
import PlusIcon from '../../assets/icons/plus_icon.svg'
import * as Yup from 'yup';

const dataTypeList = [
    { key: "String", value: "string" },
    { key: "Integer", value: "integer" },
    { key: "Decimal", value: "decimal" },
    { key: "Check Box", value: "checkBox" },
    { key: "List", value: "list" },
    { key: "Time", value: "time" },
    { key: "Date", value: "date" },
    { key: "DateTime", value: "dateTime" },
];

const renderError = ( formik, paramname) => (
        formik.errors[(paramname)] ? (
            <span className='mb-1 error-text'>
                {formik.errors[(paramname)]} 
            </span>
        ) : null
    )

  
const getClassName = (formik, paramname) => {
    let returnMsg = "input-text";
    if( formik.errors[(paramname)] ) return returnMsg+" error"
    return returnMsg
}

const handleDataChange = (setFieldValue, val, setErrors, setNumber) => {
    setFieldValue('dataType', val)
    setFieldValue('value', '')
    if( val === '') setErrors('dataType', false)
    else setErrors('dataType', true)
    setFieldValue('dataType', val)
    setFieldValue('dataFormat', dataFormat[val])
    if( val === 'string' ) {
        setFieldValue('defaultValue', '');
        setFieldValue('value', '');
        setNumber(false)
    }
    else if( val === 'integer' || val === 'decimal'){
        setFieldValue('defaultValue', 0)
        setFieldValue('value', 0);
        setNumber(true)
    } else {
        setFieldValue('defaultValue', '');
        setNumber(false)
    }
}

const categoryOption = (
    (dataTypeList.length > 0)
    ?( 
        <>
            <option key="Select category" value="">Select data type</option>
            {dataTypeList.map((ele) => <option key={ele.value} value={ele.value}>{ele.key}</option>)}
        </>
    )
    :''
)

const dataFormat = { string: '#AANNLL', integer: 'NNNNNN', decimal: '#N.NN', date: 'MM-DD-YYYY', time: 'HH:MM:SS(UTC)', dateTime: 'YYYY-MM-DDThh:mm:ss+0000 (UTC)'}
const formatFinder = { string: 'text', checkBox: 'switch', integer: 'number', decimal: 'number', date: 'date', time: 'time', dateTime: 'date'}

const FindInputType = ({ dataType, className, handleChange, name, placeholder, value, dataObj, disabled }) => {
    const [ ipText, setInputText ] = useState();
    const [ errorMsg, setErrorMessage ] = useState();
    const type = formatFinder[dataType];
    let inputEle = '';
    if( dataType === 'dateTime' || dataType === 'date' || dataType === 'time') {
        
        inputEle = (
            <DateTimePicker 
                onClose={(e) => {
                    if( dataType === 'date' && e._d) dataObj.setFieldValue(name, `${e._d.getUTCFullYear()}-${(e._d.getUTCMonth() +1).toString().padStart(2,'0')}-${e._d.getUTCDate().toString().padStart(2,'0')} `)
                    else if( dataType === 'time' && e._d) dataObj.setFieldValue(name, `${e._d.getUTCHours().toString().padStart(2,'0')}:${e._d.getUTCMinutes().toString().padStart(2,'0')}`)
                    else if(e._d) dataObj.setFieldValue(name, e._d.toUTCString().replace("GMT","UTC"))
                }}
                initialValue={value} 
                dateFormat={dataType === 'time'? false: "YYYY-MM-DD"}
                timeFormat={dataType === "date"? false: "hh:mm A"}
                className={`datePicker`}
                key={`${name}_${dataType}`}
                utc={true}
                isDisabled={disabled}
            />
        )
    }
    else if( dataType === 'checkBox') {
        inputEle = (
            <div className="flex gatewaySettingSpl">
                <Form.Group controlId="formBasicCheckbox" className="checkboxGrp">
                    <Form.Check type="checkbox" checked={value} className="yesCheck" name={name} label="Yes" onChange={(e) => dataObj.setFieldValue(name,!value)}/>
                    <Form.Check type="checkbox" checked={!value} className="noCheck" name={name} label="No" onChange={(e) => dataObj.setFieldValue(name,!value)}/> 
                </Form.Group>
            </div>
        )
    } else if(dataType === 'list') {
        inputEle = (
            <>
                <div className="flex">
                    <InputText 
                        name='dataText'
                        type="text"
                        labelClassName={"labelClass"}
                        valueClassName={"valueClass"}
                        smValue={2}
                        onChange={(e) => { setErrorMessage('');setInputText(e.target.value)}}
                        rowClassName="rowMargin"
                        className={className} 
                        placeholder={"Enter value for data list"}
                        value={ipText}
                    />
                    <Image className="plusIcon" src={PlusIcon} onClick={() => {
                        if( ipText && ipText.length > 0 ) {
                            setInputText('');
                            let tempObj = ( dataObj.values.dataList && [...dataObj.values.dataList]) || []
                            dataObj.setFieldValue('dataList', [...tempObj, ipText])
                        } else {
                            setErrorMessage('Please enter value')
                        }
                    }} />
                </div>   
                <span className='mb-1 error-text'>
                    {errorMsg} 
                </span>
            </>
        )
    } else {
        inputEle = (
            <InputText 
                name={name}
                type={type}
                labelClassName={"labelClass"}
                valueClassName={"valueClass"}
                smValue={2}
                onChange={handleChange}
                rowClassName="rowMargin"
                className={className}
                placeholder={placeholder}
                value={value}
                disabled={disabled}
            />
        )
    }
    return (
        inputEle
    )
}


function ViewGatewaySettings(props) {
    const history = useHistory();
    const dispatch = useDispatch();
    const retData = useSelector( stateRed => stateRed.gatewayReducer);
    const { 
        viewGateway={} , viewAllSettingCode = {}, viewGatewaySettings={},
        viewAllGatewayType = {},
    } = retData
    const { match: {params: { id }} , location: { state = {}}} = props;
    const {  storage, idx , action, parentIsView} = state;
    const isView = action === 'view'
    console.log('isView', action, props);
    const { data = {}} = viewGateway;
    const { gatewaySettingsList = [], gatewayTypeDetails = {}} = data;
    const recData = gatewaySettingsList[idx] || {}
    const existingData = viewGatewaySettings.data;
    const gatewayCode = gatewayTypeDetails.gatewayId;
    const [ settingsData = (existingData || recData), setData] = useState()
    const [ isNumber, setNumber ] = useState(false)
    const [ selectOrIp, setSelectOrInput ] = useState();
    useEffect(() => {
        if( !isView) {
            window.onbeforeunload = (e) => {
                e.preventDefault();
                e.returnValue= '';
            }
            const listener = history.listen((loc) => {
                const allowedPath = [ "/gatewaymanagment/gatewayProviders", "/gatewaymanagment/gatewayProvidersGw","/gatewaymanagment/"]
                const { location: { pathname }} = history;
                if(allowedPath.filter(ele => pathname.includes(ele)).length === 0 && pathname !==  `/gatewaymanagment/gatewaySettings/${id}`) {
                    if(!window.confirm("Leaving the page will discard any unsaved changes")) {
                        collectValue();
                        history.go(-1);
                        const { localValue={} } = retData;
                        setData(localValue);                   
                    } else {
                        viewGatewaySettings.data = undefined;
                    }
                } else {
                    window.onbeforeunload = undefined;
                }
            })
            return () => {
                window.onbeforeunload = undefined;
                return listener()
            }
        }
    },[])
    const { 
        gatewaySettingsCode, fieldName,
    } = settingsData;
    const handleSubmit = ( storageType,values ) => {
        clearData();
        if( storageType === "local") {
            let toastMessage = '';
            const tempObj = viewGateway;
            if( id === "add") {
                tempObj.data.gatewaySettingsList.push({ ...values, gatewaySettingsCode: "To be generated", isUpdate: true, isNewlyAdded: true });
                toastMessage = 'Gateway setting added';
            } else {
                tempObj.data.gatewaySettingsList[idx] ={...values, isUpdate: true };
                toastMessage = 'Gateway setting updated';
            }
            goBack({ toastState: true, toastMessage: toastMessage, toastType: 'success' })
        }
    }
    const handleExistingHandler = (e) => { 
        if(e.target.checked){
            dispatch(retrieveAllGatewayType());
            setSelectOrInput(true)
        } else {
            setSelectOrInput(false)
        }
    }
    const formIkRef = useRef();
    const clearData = () => {
        viewGatewaySettings.data = undefined;
    }
    const goBack = ( toastObj) => {
        clearData();
        if( id === 'add' && gatewayCode === undefined) {
            history.goBack();
        }
        if( storage === "local") {
            history.push({ 
                pathname: `/gatewaymanagment/${gatewayCode?gatewayCode:gatewayTypeDetails?.gatewayCode}`, 
                ...toastObj,
                dataFrom: "localState",
                state: { action: parentIsView?"view":""}
            });
        }
        else {
            console.log('in 3')
            history.push({
                pathname: `/gatewaymanagment/${gatewayCode?gatewayCode:''}`,
                state: { action : parentIsView?"view":""}
            });
        }
    }
    let validationSchema = {
        fieldName: Yup.string()
            .matches(/^[a-z0-9\s]+$/i, { message: 'Enter only alpha numeric characters'})
            .max(50, 'Must be 50 characters or less')
            .required('Required field'),
        dataType: Yup.string().required('Required field'),
        status: Yup.string().required('Required field'),
        affectedModule: Yup.string()
            .max(200, 'Must be 200 characters or less')
            .required('Required field'),
        description: Yup.string()
            .max(200, 'Must be 200 characters or less')
            .required('Required field'),
        reason: Yup.string()
            .max(200, 'Must be 200 characters or less')
            .required('Required field'),
        fieldValue: Yup.mixed()
            .required('Required field'),
    };
    if( isNumber ) {
        validationSchema = {
            ...validationSchema,
            maximumValue: Yup.number().required('Required field'),
            minimumValue: Yup.number().required('Required field')
        }
    } else {
        validationSchema = { ...validationSchema }
    }
    let addInitialValue = {}; 
    let headerEle = '';
    if( id !== 'add') {
        addInitialValue= { reason: settingsData?.reason?settingsData.reason:""}
    } else {
        headerEle = (
            <div>
                <div>
                    <span>You can either use settings from other gateways or fill out the feilds to create a new one</span>
                    <div><b>All feilds are required</b></div>
                </div>
                <div className="flex mt8">
                    <Form.Check 
                        onChange={(e) => handleExistingHandler(e)}
                    />
                    Use existing value
                </div>
            </div>
        )
    }

    const retriveGatewaySetting = ( settingCode ) => {
        dispatch(retrieveGatewaySettings(settingCode))
    }
    const renderValue = (values, handleBlur, errors, touched, handleChange) => {
        let categoryList = [];
        let settingsList = [];
        if( selectOrIp) {
            const gatewayTypeList = viewAllGatewayType.data || [];
            categoryList = gatewayTypeList.map((ele) => <option value={ele.gatewayCode}>{`${ele.gatewayCode}  ${ele.name}`}</option>)
            categoryList.unshift(<option>Select Gateway Code</option>)
            const { settingCodeList =[] } = (viewAllSettingCode && viewAllSettingCode.data ) || {};
            settingsList = settingCodeList.map((ele) => <option value={ele.code}>{`${ele.code}  ${ele.name}`}</option>)
            settingsList.unshift(<option>Select Setting Code</option>)
        }
        
        return(
            (selectOrIp)?(
                <>
                    <DetailsLabel 
                        labelName={"Gateway Code"} 
                        valueName={
                            <>
                                <Form.Control 
                                    name="gatewayCode"
                                    as="select"
                                    onChange={(e) => dispatch(retreiveAllSettingsCode(e.target.value))}
                                    className={`feildLabel`}
                                    disabled={isView}
                                >
                                    {categoryList}
                                </Form.Control>
                            </>}
                        labelClassName={"labelClass"}
                        valueClassName={"valueClass"}
                        smValue={2}
                        rowClassName="rowMargin"
                    />
                    <DetailsLabel 
                        labelName={"Existing Setting Code"} 
                        valueName={
                            <>
                                <Form.Control 
                                    as="select"
                                    name="existingSettingCode"
                                    className={`feildLabel`}
                                    onChange={(e) => retriveGatewaySetting(e.target.value)}
                                >
                                    {settingsList}
                                </Form.Control>
                            </>}
                        labelClassName={"labelClass"}
                        valueClassName={"valueClass"}
                        smValue={2}
                        rowClassName="rowMargin"
                    />
                    <DetailsLabel 
                        labelName={"Setting Code"} 
                        valueName={
                            <>
                                <InputText 
                                    value={values.gatewaySettingsCode} 
                                    name="gatewaySettingsCode"
                                    onBlur={handleBlur}
                                    className={`feildLabel ${getClassName({ errors, touched }, 'gatewaySettingsCode')}`}
                                    disabled
                                    onChange={ handleChange}
                                    placeholder={"Enter Setting Code"}
                                />
                                {renderError({errors, touched }, 'gatewaySettingsCode')}
                            </>}
                        labelClassName={"labelClass"}
                        valueClassName={"valueClass"}
                        smValue={2}
                        rowClassName="rowMargin"
                    />
                </>
            ):''
        )
    }
    const getValueText = ( value ) => value ==="active" ?"Enabled":"Disabled"
    const getRequiredText = ( value ) => value ?"Yes":"No"
    let collectValue = '';
    return(
        <div className="gatewaySettingBody">
            <div className="redirect">
                <div style={{cursor: "pointer"}} onClick={() => goBack()}>
                    <Image src={backIcon}  className="icon"/>
                </div>
                <b>{ (id==='add')? `Add Gateway Settings`: `${gatewaySettingsCode} - ${ fieldName}`}</b>
            </div>
            <Card>
                <div className="cardHeader">
                    Gateway Settings Detail
                </div>
                <Card.Body>
                    <Card.Text>
                        <Formik
                            initialValues={{status:false, required:false, ...settingsData,...addInitialValue}}
                            enableReinitialize
                            validationSchema={Yup.object().shape(validationSchema)}
                            onSubmit={(values) => {
                                handleSubmit(storage,values)
                            }}
                            innerRef={formIkRef}
                        >
                            {({ 
                                errors, touched, values, handleChange,
                                setFieldValue, handleBlur, setErrors
                            }) => (
                                <Form>
                                    {headerEle}
                                    {collectValue = () => dispatch(updateLocalValue(values))}
                                    {renderValue(values, handleBlur, errors, touched, handleChange)}
                                    <DetailsLabel 
                                        labelName={"Name"} 
                                        valueName={
                                            <>
                                                <InputText
                                                    placeholder={"Enter Setting name"} 
                                                    onChange={ handleChange} 
                                                    name="fieldName"
                                                    onBlur={handleBlur}
                                                    disabled={isView}
                                                    value={values.fieldName} 
                                                    className={`feildLabel ${getClassName({ errors, touched }, 'fieldName')}`}
                                                />
                                                {renderError({errors, touched }, 'fieldName')}
                                            </>
                                        }
                                        labelClassName={"labelClass"}
                                        valueClassName={"valueClass"}
                                        smValue={2}
                                        rowClassName="rowMargin"
                                    />
                                    <DetailsLabel 
                                        labelName={"Description"} 
                                        valueName={
                                            <>
                                                <InputText 
                                                    placeholder={"Enter Setting Description"} 
                                                    onChange={ handleChange} 
                                                    name="description"
                                                    onBlur={handleBlur}
                                                    disabled={isView}
                                                    as="textarea" 
                                                    value={values.description} 
                                                    rows={3} 
                                                    className={`feildLabel ${getClassName({ errors, touched }, 'description')}`}  
                                                />
                                                {renderError({errors, touched }, 'description')}
                                            </>
                                        }
                                        labelClassName={"labelClass"}
                                        valueClassName={"valueClass"}
                                        smValue={2}
                                        rowClassName="rowMargin"
                                    />
                                    <DetailsLabel 
                                        labelName={"Data Type"} 
                                        valueName={
                                            <>
                                                <Form.Control 
                                                    as="select" 
                                                    name="dataType" 
                                                    aria-label="Select Category" 
                                                    value={values.dataType}
                                                    disabled={isView}
                                                    onBlur={handleBlur} 
                                                    onChange={(e) => {
                                                        handleDataChange( setFieldValue, e.target.value, setErrors, setNumber )
                                                    }}
                                                    className={`feildLabel select ${getClassName({ errors, touched }, 'dataType')}`}
                                                >
                                                    {categoryOption}
                                                </Form.Control>
                                                {renderError({errors, touched }, 'dataType')}
                                            </>
                                        }
                                        labelClassName={"labelClass"}
                                        valueClassName={"valueClass"}
                                        smValue={2}
                                        rowClassName="rowMargin"
                                    />
                                    {
                                        ( values.dataType !== 'list' && values.dataType !== 'checkBox')
                                        ? (
                                            <>
                                                <DetailsLabel 
                                                    labelName={"Data Format"} 
                                                    valueName={
                                                        <>
                                                            <InputText 
                                                                name="dataFormat"
                                                                placeholder={"Enter Data format"} 
                                                                onBlur={handleBlur}
                                                                onChange={ handleChange} 
                                                                disabled={isView}
                                                                value={values.dataFormat} 
                                                                className={`feildLabel ${getClassName({ errors, touched }, 'dataFormat')}`} 
                                                            />
                                                            {renderError({errors, touched }, 'dataFormat')}
                                                        </>
                                                    }
                                                    labelClassName={"labelClass"}
                                                    valueClassName={"valueClass"}
                                                    smValue={2}
                                                    rowClassName="rowMargin"
                                                />
                                            </>
                                        ): ''
                                    }
                                    {                                    
                                        (values.dataType !== 'list' && values.dataType !== 'checkBox')
                                        ? (
                                            <>
                                                <DetailsLabel 
                                                    labelName={"Default Value"} 
                                                    valueName={
                                                        <>
                                                            <FindInputType
                                                                dataType={values.dataType}
                                                                handleChange={(e) => {
                                                                    handleChange(e)
                                                                    setFieldValue('value', e.target.value)
                                                                }}
                                                                onBlur={handleBlur}
                                                                disabled={isView}
                                                                name={"defaultValue"}
                                                                placeholder={'Enter Default Value'}
                                                                dataObj={{setFieldValue,  values}}
                                                                value={values.defaultValue}
                                                                className={`feildLabel ${getClassName({ errors, touched }, 'defaultValue')}`} 
                                                            />
                                                            {renderError({errors, touched }, 'defaultValue')}
                                                        </>
                                                    }
                                                    labelClassName={"labelClass"}
                                                    valueClassName={"valueClass"}
                                                    smValue={2}
                                                    rowClassName="rowMargin"
                                                />
                                            </>
                                        ): null
                                    }
                                    {                                    
                                        (values.dataType === 'integer' || values.dataType === 'decimal')
                                        ? (
                                            <>
                                                <DetailsLabel 
                                                    labelName={"Minimum Value"} 
                                                    valueName={
                                                        <>
                                                            <FindInputType
                                                                dataType={values.dataType}
                                                                handleChange={handleChange}
                                                                disabled={isView}
                                                                onBlur={handleBlur}
                                                                name={"minimumValue"}
                                                                placeholder={'Enter Minimum Value'}
                                                                value={values.minimumValue}
                                                                className={`feildLabel ${getClassName({ errors, touched }, 'minimumValue')}`} 
                                                            />
                                                            {renderError({errors, touched }, 'minimumValue')}
                                                        </>
                                                    }
                                                    labelClassName={"labelClass"}
                                                    valueClassName={"valueClass"}
                                                    smValue={2}
                                                    rowClassName="rowMargin"
                                                />
                                            </>
                                        ):''
                                    }
                                    {                                    
                                        (values.dataType === 'integer'|| values.dataType === 'decimal')
                                        ? (
                                            <>
                                                <DetailsLabel 
                                                    labelName={"Maximum Value"} 
                                                    valueName={
                                                        <>
                                                            <FindInputType
                                                                dataType={values.dataType}
                                                                handleChange={handleChange}
                                                                disabled={isView}
                                                                onBlur={handleBlur}
                                                                name={"maximumValue"}
                                                                placeholder={'Enter Maximum Value'}
                                                                value={values.maximumValue}
                                                                className={`feildLabel ${getClassName({ errors, touched }, 'maximumValue')}`} 
                                                            />
                                                            {renderError({errors, touched }, 'maximumValue')}
                                                        </>
                                                    }
                                                    labelClassName={"labelClass"}
                                                    valueClassName={"valueClass"}
                                                    smValue={2}
                                                    rowClassName="rowMargin"
                                                />
                                            </>
                                        ): ''
                                    }
                                    <DetailsLabel 
                                        labelName={values.dataType !== "list"? "Value":"Datalist Value"} 
                                        valueName={
                                            <>
                                                <FindInputType
                                                    dataType={values.dataType}
                                                    handleChange={handleChange}
                                                    disabled={isView}
                                                    name={values.dataType !== "list"?"fieldValue":"dataList"}
                                                    onBlur={handleBlur}
                                                    placeholder={'Enter Value'}
                                                    value={(values.fieldValue !== undefined ? values?.fieldValue : values.defaultValue)}
                                                    dataObj={{setFieldValue,  values}}
                                                    className={`feildLabel ${getClassName({ errors, touched }, values.dataType !== "list"?"fieldValue":"dataList")}`} 
                                                />
                                                {renderError({errors, touched }, values.dataType !== "list"?"fieldValue":"dataList")}
                                            </>
                                        }
                                        labelClassName={"labelClass"}
                                        valueClassName={"valueClass"}
                                        smValue={2}
                                        rowClassName="rowMargin"
                                    />
                                    {
                                        (values.dataType === 'list') ? (
                                            <DetailsLabel 
                                                labelName={"Value"} 
                                                valueName={
                                                    <>
                                                        <Form.Control 
                                                            as="select" 
                                                            disabled={isView}
                                                            name={"value"}
                                                            aria-label="Select Category" 
                                                            value={values.value} 
                                                            onBlur={handleBlur}
                                                            onChange={handleChange}
                                                            className={`feildLabel select ${getClassName({ errors, touched }, "value")}`} 
                                                        >
                                                            {
                                                                <>
                                                                    <option value="">Select value</option>
                                                                    {( values.dataList && values.dataList.map((elem) => (
                                                                        <option value={elem}>{elem}</option>
                                                                    )))}
                                                                </>
                                                            }
                                                        </Form.Control>
                                                        {renderError({errors, touched }, "value")}
                                                    </>
                                                }
                                                labelClassName={"labelClass"}
                                                valueClassName={"valueClass"}
                                                smValue={2}
                                                rowClassName="rowMargin"
                                            />
                                        ): ''
                                    }
                                    <DetailsLabel 
                                        labelName={"Required"} 
                                        valueName={
                                            <>
                                                <div className="flex">
                                                    <Switch 
                                                        type="switch"
                                                        name="required"
                                                        onChange={(e) => setFieldValue('required', e.target.checked)}
                                                        id={`custom-switch-${gatewaySettingsCode}-modal`}
                                                        checked={values.required}
                                                        disabled={isView}
                                                    />
                                                    <span className="mt2">{getRequiredText(values.required)}</span>
                                                </div>
                                                {renderError({errors, touched }, 'required')}
                                            </>
                                        }
                                        labelClassName={"labelClass"}
                                        valueClassName={"valueClass"}
                                        smValue={2}
                                        rowClassName="rowMargin"
                                    />
                                    <DetailsLabel 
                                        labelName={"Affected Module"} 
                                        valueName={
                                        <>
                                            <InputText 
                                                name="affectedModule"
                                                onChange={ handleChange}
                                                onBlur={handleBlur} 
                                                disabled={isView}
                                                placeholder={"Enter Affected Module"} 
                                                value={values.affectedModule}
                                                className={`feildLabel ${getClassName({ errors, touched }, 'affectedModule')}`}  
                                            />
                                            {renderError({errors, touched }, 'affectedModule')}
                                        </>
                                        }
                                        labelClassName={"labelClass"}
                                        valueClassName={"valueClass"}
                                        smValue={2}
                                        rowClassName="rowMargin"
                                    />
                                    <DetailsLabel 
                                        labelName={"Status"} 
                                        valueName={
                                            <>
                                                <div className="flex">
                                                    <Switch 
                                                        name="status"
                                                        type="switch"
                                                        disabled={isView}
                                                        onChange={(e) => {
                                                            setFieldValue('status',e.target.checked?"active":"inactive")}
                                                        }
                                                        id={`custom-switch-${gatewaySettingsCode}-status-modal`}
                                                        checked={values.status === "active"}
                                                    />
                                                    <span className="mt2">{getValueText(values.status)}</span>
                                                </div>
                                                {renderError({errors, touched }, 'status')}
                                            </>
                                        }
                                        labelClassName={"labelClass"}
                                        valueClassName={"valueClass"}
                                        smValue={2}
                                        rowClassName="rowMargin"
                                    />
                                   <DetailsLabel 
                                        labelName={"Reason"} 
                                        valueName={
                                            <>
                                                <InputText
                                                    onChange={ handleChange} 
                                                    placeholder={"Enter Reason"} 
                                                    value={values.reason}
                                                    onBlur={handleBlur}
                                                    disabled={isView}
                                                    name="reason"
                                                    className={`feildLabel ${getClassName({ errors, touched }, 'reason')}`}  
                                                />
                                                {renderError({errors, touched }, 'reason')}
                                            </>
                                        }
                                        labelClassName={"labelClass"}
                                        valueClassName={"valueClass"}
                                        smValue={2}
                                        rowClassName="rowMargin"
                                    />
                                </Form>
                            )}
                        </Formik>
                    </Card.Text>
                </Card.Body>
            </Card>
            {!isView &&<div className="settingsBtnBlock">
                <BDOButton variant="secondary" onClick={() => goBack()} >Cancel</BDOButton>
                <BDOButton variant="primary" onClick={() => formIkRef.current.handleSubmit()}>{(id === 'add')? 'Add': 'Save'}</BDOButton>
            </div>}
        </div>
    )
}
export default ViewGatewaySettings;
