/* eslint-disable react-hooks/exhaustive-deps */
import React, { useState, useEffect, useRef } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import DetailsLabel from './DetailsLabel';
import {
    Card, Image, Form,
} from 'react-bootstrap';
import { useHistory } from 'react-router-dom';
import './styles/viewGatewaySettings.scss';
import Switch from '../Global/Switch/Switch';
import backIcon from '../../assets/icons/backIcon.png';
import InputText from '../../components/Global/Input/InputText';
import { Formik } from 'formik';
import DateTimePicker from '../Global/DateTimePicker/DateTimePicker';
import PlusIcon from '../../assets/icons/plus_icon.svg'
import MinusIcon from '../../assets/icons/icon-delete.svg'
import BDOButton from '../Global/Button/BDOButton'
import * as Yup from 'yup';
import { updateLocalGwProviderValue } from '../../actions/gatewaymanagement';
import BDOSelect from "../Global/Select/BDOSelect";

const dataTypeList = [
    { label: "String", value: "string" },
    { label: "Integer", value: "integer" },
    { label: "Decimal", value: "decimal" },
    { label: "Check Box", value: "checkBox" },
    { label: "List", value: "list" },
    { label: "Time", value: "time" },
    { label: "Date", value: "date" },
    { label: "DateTime", value: "dateTime" },
];

const renderError = (formik, paramname) => (
    formik.errors[(paramname)] ? (
        <span className='mb-1 error-text'>
            {formik.errors[(paramname)]}
        </span>
    ) : null
)


const getClassName = (formik, paramname) => {
    let returnMsg = "input-text";
    if (formik.errors[(paramname)]) return returnMsg + " error"
    return returnMsg
}

const handleDataChange = (setFieldValue, val, setErrors, setNumber, setDecimal) => {
    setFieldValue('dataType', val)
    setFieldValue('value', '')
    if( val === '') setErrors('dataType', false)
    else setErrors('dataType', true)
    setFieldValue('dataType', val)
    setFieldValue('dataFormat', dataFormat[val])
    if( val === 'string' ) {
        setFieldValue('defaultValue', '');
        setFieldValue('fieldValue', '');
        setFieldValue('maximumValue', '')
        setFieldValue('minimumValue', '');
        setNumber(false);
        setDecimal(false);
    }
    if (val === 'list') {
        setFieldValue('fieldValue', "null");
        setFieldValue('maximumValue', '')
        setFieldValue('minimumValue', '');
        setNumber(false);
        setDecimal(false);
    }
    else if (val === 'integer') {
        setFieldValue('defaultValue', 0)
        setFieldValue('fieldValue', 0);
        setFieldValue('maximumValue', '')
        setFieldValue('minimumValue', '');
        setNumber(true);
        setDecimal(false);
    }
    else if (val === 'decimal') {
        setFieldValue('defaultValue', 0.00)
        setFieldValue('fieldValue', 0.00);
        setFieldValue('maximumValue', '')
        setFieldValue('minimumValue', '');
        setNumber(false);
        setDecimal(true);
    } else {
        setFieldValue('defaultValue', '');
        setFieldValue('maximumValue', '')
        setFieldValue('minimumValue', '');
        setNumber(false);
        setDecimal(false);
    }
}

const dataFormat = { string: '#AANNLL', integer: 'NNNNNN', decimal: '#N.NN', date: 'MM-DD-YYYY', time: 'HH:MM:SS(UTC)', dateTime: 'YYYY-MM-DDThh:mm:ss+0000 (UTC)' }
const formatFinder = { string: 'text', checkBox: 'switch', integer: 'number', decimal: 'number', date: 'date', time: 'time', dateTime: 'date' }

const FindInputType = ({ dataType, className, handleChange, name, placeholder, value, dataObj, disabled }) => {
    const [ipText, setInputText] = useState();
    const [errorMsg, setErrorMessage] = useState();
    const type = formatFinder[dataType];
    let inputEle = '';
    if (dataType === 'dateTime' || dataType === 'date' || dataType === 'time') {
        let constructedDate;
        if (dataType === 'time' && value) {
            constructedDate = new Date();
            constructedDate.setUTCHours(value.split(":")[0])
            constructedDate.setUTCMinutes(value.split(":")[1])
            constructedDate.setUTCSeconds(value.split(":")[2])
        }
        if (dataType === 'date') {
            let splitList = value.split("-")
            constructedDate = new Date(Date.UTC(splitList[2], parseInt(splitList[0]) - 1, splitList[1]))
        }
        if (dataType === 'dateTime') {
            let [datesplitList, timesplitList = ""] = value.split("T")
            let datelist = datesplitList.split("-")
            let timelist = timesplitList.split(":")
            constructedDate = new Date(Date.UTC(datelist[0], parseInt(datelist[1]) - 1, datelist[2]))
            constructedDate.setUTCHours(timelist[0])
            constructedDate.setUTCMinutes(timelist[1])
            constructedDate.setUTCSeconds(timelist[2])
        }
        inputEle = (
            <DateTimePicker
                onChange={(e) => {
                    if (dataType === 'date' && e._d) {
                        dataObj.setFieldValue(name, `${(e._d.getUTCMonth() + 1).toString().padStart(2, '0')}-${e._d.getUTCDate().toString().padStart(2, '0')}-${e._d.getUTCFullYear()}`)
                        if (name === 'defaultValue') {
                            dataObj.setFieldValue('fieldValue', `${(e._d.getUTCMonth() + 1).toString().padStart(2, '0')}-${e._d.getUTCDate().toString().padStart(2, '0')}-${e._d.getUTCFullYear()}`)
                        }
                    }
                    else if (dataType === 'time' && e._d) {
                        dataObj.setFieldValue(name, `${e._d.getUTCHours().toString().padStart(2, '0')}:${e._d.getUTCMinutes().toString().padStart(2, '0')}:${e._d.getUTCSeconds().toString().padStart(2, '0')}`)
                        if (name === 'defaultValue') {
                            dataObj.setFieldValue('fieldValue', `${e._d.getUTCHours().toString().padStart(2, '0')}:${e._d.getUTCMinutes().toString().padStart(2, '0')}:${e._d.getUTCSeconds().toString().padStart(2, '0')}`)
                        }
                    }
                    else if (e._d) {
                        dataObj.setFieldValue(name, `${e._d.getUTCFullYear()}-${(e._d.getUTCMonth() + 1).toString().padStart(2, '0')}-${e._d.getUTCDate().toString().padStart(2, '0')}T${e._d.getUTCHours().toString().padStart(2, '0')}:${e._d.getUTCMinutes().toString().padStart(2, '0')}:${e._d.getUTCSeconds().toString().padStart(2, '0')}`)
                        if (name === 'defaultValue') {
                            dataObj.setFieldValue('fieldValue', `${e._d.getUTCFullYear()}-${(e._d.getUTCMonth() + 1).toString().padStart(2, '0')}-${e._d.getUTCDate().toString().padStart(2, '0')}T${e._d.getUTCHours().toString().padStart(2, '0')}:${e._d.getUTCMinutes().toString().padStart(2, '0')}:${e._d.getUTCSeconds().toString().padStart(2, '0')}`)
                        }
                    }
                }}
                initialValue={value}
                inputProps={{ disabled: disabled }}
                value={constructedDate}
                dateFormat={dataType === 'time' ? false : (dataType === 'dateTime' ? "YYYY-MM-DD" : "MM-DD-YYYY")}
                timeFormat={dataType === "date" ? false : "hh:mm A"}
                className={`datePicker ${className}`}
                key={`${name}_${dataType}`}
                utc={true}
            />
        )
    }
    else if (dataType === 'checkBox') {
        inputEle = (
            <div className="flex gatewaySettingSpl">
                <Form.Group controlId="formBasicCheckbox" className="checkboxGrp">
                    <Form.Check type="checkbox" checked={value} className="yesCheck" name={name} label="Yes" onChange={(e) => dataObj.setFieldValue(name, !value)} />
                    <Form.Check type="checkbox" checked={!value} className="noCheck" name={name} label="No" onChange={(e) => dataObj.setFieldValue(name, !value)} />
                </Form.Group>
            </div>
        )
    } else if (dataType === 'list') {
        inputEle = (
            <>
                <div className="flex">
                    <InputText
                        name='dataText'
                        type="text"
                        labelClassName={"labelClass"}
                        valueClassName={"valueClass"}
                        disabled={disabled}
                        smValue={2}
                        onChange={(e) => { setErrorMessage(''); setInputText(e.target.value) }}
                        rowClassName="rowMargin"
                        className={className}
                        placeholder={"Enter Value For Data List"}
                        value={ipText}
                    />
                    <Image className="plusIcon" src={PlusIcon} disabled={disabled} onClick={() => {
                        if (ipText && ipText.length > 0) {
                            setInputText('');
                            let tempObj = (dataObj.values.dataList && [...dataObj.values.dataList]) || []
                            if( tempObj.length < 50) {
                                dataObj.setFieldValue('dataList', [...tempObj, ipText])
                            } else {
                                setErrorMessage('Datalist cannot add more than 50 values in the list') // this thing alone we need to discuss
                            }
                        } else {
                            setErrorMessage('Please enter value')
                        }
                    }} />
                </div>
                <span className='mb-1 error-text'>
                    {errorMsg}
                </span>
            </>
        )
    } else {
        inputEle = (
            <InputText
                name={name}
                type={type}
                onChange={handleChange}
                labelClassName={"labelClass"}
                valueClassName={"valueClass"}
                smValue={2}
                rowClassName="rowMargin"
                className={className}
                step={dataType === "Decimal" ? "0.01" : 1}
                disabled={disabled}
                placeholder={placeholder}
                value={value}
            />
        )
    }
    return (
        inputEle
    )
}


function ViewGatewayProviderSettings(props) {
    const history = useHistory();
    const retData = useSelector(stateRed => stateRed.gatewayReducer);
    const dispatch = useDispatch();
    let {
        viewGateway = {}, providerSettings = {}
    } = retData;
    const { match: { params: { id, providerCode } }, location: { state = {} } } = props;
    const { storage, providerIdx, idx, action, parentIsView } = state;
    const { data = {} } = viewGateway;
    const { gatewayProviderList = [] } = data;
    const recData = (gatewayProviderList[providerIdx] && (gatewayProviderList[providerIdx].gatewayProviderSettingList[idx] || {})) || {}
    const [settingsData = (providerSettings.data || recData),] = useState()
    const [isNumber, setNumber] = useState(false)
    const [isDecimal, setDecimal ] = useState(false)
    const {
        code, fieldName,
    } = settingsData;
    let collectValue;
    const isView = action === "view";
    useEffect(() => {
        if (!isView) {
            window.onbeforeunload = (e) => {
                e.preventDefault();
                e.returnValue = '';
            }
            const listener = history.listen((loc) => {
                const allowedPath = ["/gatewaymanagment/gatewayProviders", "/gatewaymanagment/gatewayProvidersGw", "/gatewaymanagment/gatewaySettings"]
                const { location: { pathname } } = history;
                if (allowedPath.filter(ele => pathname.includes(ele)).length === 0 && pathname !== `/gatewaymanagment/gatewayProviders/${providerCode}/${id}`) {
                    if (!window.confirm("Leaving the page will discard any unsaved changes")) {
                        collectValue();
                        history.go(-1);
                    } else {
                        providerSettings.data = undefined;
                    }
                } else {
                    window.onbeforeunload = undefined;
                }
            })
            return () => {
                window.onbeforeunload = undefined;
                return listener()
            }
        }
    }, []);

    const handleSubmit = (storageType, values) => {
        if (values.fieldValue === "null") values.fieldValue = null;
        if (values.dataType === "checkBox") { values["dataList"] = ["Yes", "No"]; values.fieldDefaultValue = null; }
        if (storageType === "local") {
            let toastMessage = '';
            const tempObj = viewGateway;
            if (id === "add") {
                tempObj.data.gatewayProviderList[providerIdx].gatewayProviderSettingList.push({
                    ...values, code: "To be generated", isUpdate: true, isNewlyAdded: true, forApproval: false
                });
                toastMessage = 'Gateway provider setting added';
            } else {
                tempObj.data.gatewayProviderList[providerIdx].gatewayProviderSettingList[idx] = { ...values, isUpdate: true, forApproval: false };
                toastMessage = 'Gateway provider setting updated';
            }
            goBack({ toastState: true, toastMessage: toastMessage, toastType: 'success' })
        }
    }

    const formIkRef = useRef();
    const goBack = (toastObj) => {
        if (storage === "local") {
            history.push({
                pathname: `/gatewaymanagment/gatewayProvidersGw/${providerCode ? providerCode : ''}`,
                dataFrom: "localState",
                toastObj,
                state: { idx: providerIdx, storage: 'local', action: parentIsView ? "view" : "" }
            });
        }
        else {
            history.push(`/gatewaymanagment/gatewayProvidersGw/${providerCode ? providerCode : ''}`);
        }
        providerSettings.data = undefined;
    }
    let validationSchema = {
        fieldName: Yup.string()
        .matches(/^[A-Za-z0-9 _]*$/, 'Please enter valid name')
        .max(50, 'Must be 50 characters or less')
        .required('Required'),
        fieldValue: Yup.string()
        .required('Required'),
        description: Yup.string()
        .max(200, 'Must be 200 characters or less')
        .required('Required'),
        dataType: Yup.string().required('Required'),
        affectedModule: Yup.string()
        .max(200, 'Must be 200 characters or less')
        .required('Required'),
        reason: Yup.string()
        .max(50, 'Must be 50 characters or less')
        .required('Required'),
        status: Yup.string().required('Required')
    };
    if (isNumber) {
        validationSchema = {
            ...validationSchema,
            maximumValue: Yup.number().required('Required field'),
            minimumValue: Yup.number().required('Required field')
        }
    } else if( isDecimal) {
        validationSchema = {
            ...validationSchema,
            maximumValue: Yup.number()
            .typeError("That doesn't look like a number")
            .positive("Number can't be negative or 0")
            .max(99999, 'Must be 99999 or less')
            .integer("Number can't include a decimal point")
            .required('Required'),
          minimumValue: Yup.number()
            .typeError("That doesn't look like a number")
            .positive("Number can't be negative or 0")
            .max(99999, 'Must be 99999 or less')
            .integer("Number can't include a decimal point")
            .required('Required'),
          fieldValue: Yup.number()
          .typeError("That doesn't look like a number")
          .positive("Number can't be negative or 0")
          .integer("Number can't include a decimal point")
          .required('Required'),
        }
    } else {
        validationSchema = { ...validationSchema }
    }
    let addInitialValue = {};
    if (id !== 'add') {
        addInitialValue = { reason: settingsData?.reason ? settingsData.reason : "" }
    }
    const getValueText = (value) => value ? "Enabled" : "Disabled"
    const removeFromDataList = (e, index, list, setFieldValue) => {
        e.stopPropagation();
        list.splice(index, 1);
        setFieldValue('dataList', [...list]);
    }
    const optionList = [];
    return (
        <div className="gatewaySettingBody">
            <div className="redirect">
                <div style={{ cursor: "pointer" }} onClick={() => goBack()}>
                    <Image src={backIcon} className="icon" />
                </div>
                <b>{(id === 'add') ? `Add Gateway Provider Settings` : `${code} - ${fieldName}`}</b>
            </div>
            <Card>
                <div className="cardHeader">
                    <Card.Title className="cardTitle gsHeader">Mapping Provider Setting Details</Card.Title>
                </div>
                <Card.Body>
                    <Card.Text>
                        <Formik
                            initialValues={{ status: false, ...settingsData, ...addInitialValue }}
                            enableReinitialize
                            validationSchema={Yup.object().shape(validationSchema)}
                            onSubmit={(values) => {
                                handleSubmit(storage, values)
                            }}
                            validate= { values => {
                                let errors = {};
                                if ((values.dataType === 'integer' || values.dataType === 'decimal') && values.minimumValue && values.maximumValue) {
                                  if (values.minimumValue > values.maximumValue) {
                                    errors.minimumValue = 'Minimum value should not be greater than maximum value';
                                  }
                                  if (values.fieldValue < values.minimumValue || values.fieldValue > values.maximumValue) {
                                    errors.fieldValue = 'Parameter value should be between minimum and maximum values';
                                  }
                                }
                                return errors;
                            }}
                            innerRef={formIkRef}
                        >
                            {({
                                errors, touched, values, handleChange,
                                setFieldValue, handleBlur, setErrors
                            }) => (
                                <Form>
                                    {
                                        (values.dataList && values.dataList.map((elem, index) => (
                                            optionList.push({
                                            label: (
                                                <div className="flexDivLabel">
                                                <div>{elem}</div>
                                                {!isView &&
                                                 <Image
                                                  onClick={(e) => removeFromDataList(e, index, values.dataList, setFieldValue)}
                                                  className="icon rightIcon" height={10} width={10} src={MinusIcon} 
                                                />}
                                                </div>
                                            ), value: elem , isdisabled :true 
                                            })
                                        )))
                                    }
                                    {collectValue = () => dispatch(updateLocalGwProviderValue(values))}
                                    <DetailsLabel
                                        labelName={"Name"}
                                        valueName={
                                            <>
                                                <InputText
                                                    placeholder={"Enter Setting Name"}
                                                    onChange={handleChange}
                                                    name="fieldName"
                                                    onBlur={handleBlur}
                                                    disabled={isView}
                                                    value={values.fieldName}
                                                    className={`feildLabel ${getClassName({ errors, touched }, 'fieldName')}`}
                                                />
                                                {renderError({ errors, touched }, 'fieldName')}
                                            </>
                                        }
                                        labelClassName={"labelClass"}
                                        valueClassName={"valueClass"}
                                        smValue={2}
                                        rowClassName="rowMargin"
                                    />
                                    <DetailsLabel
                                        labelName={"Description"}
                                        valueName={
                                            <>
                                                <InputText
                                                    placeholder={"Enter Setting Description"}
                                                    onChange={handleChange}
                                                    name="description"
                                                    onBlur={handleBlur}
                                                    disabled={isView}
                                                    as="textarea"
                                                    value={values.description}
                                                    rows={3}
                                                    className={`feildLabel ${getClassName({ errors, touched }, 'description')}`}
                                                />
                                                {renderError({ errors, touched }, 'description')}
                                            </>
                                        }
                                        labelClassName={"labelClass"}
                                        valueClassName={"valueClass"}
                                        smValue={2}
                                        rowClassName="rowMargin"
                                    />
                                    <DetailsLabel
                                        labelName={"Data Type"}
                                        valueName={
                                            <>
                                                <BDOSelect
                                                    value={values.dataType}
                                                    onBlur={handleBlur}
                                                    isDisabled={isView}
                                                    name="dataType"
                                                    options={dataTypeList}
                                                    placeholder={"Select Datatype"}
                                                    onChange={(e) => {
                                                        handleDataChange(setFieldValue, e.value, setErrors, setNumber, setDecimal)
                                                    }}
                                                    className={
                                                        `feildLabel selectDropDown ${props.className} ${getClassName({ errors, touched }, 'dataType')} ${isView ? 'disabled' : ''}`
                                                    }
                                                />
                                                {renderError({ errors, touched }, 'dataType')}
                                            </>
                                        }
                                        labelClassName={"labelClass"}
                                        valueClassName={"valueClass"}
                                        smValue={2}
                                        rowClassName="rowMargin"
                                    />
                                    {
                                        (values.dataType !== 'list' && values.dataType !== 'checkBox')
                                            ? (
                                                <>
                                                    <DetailsLabel
                                                        labelName={"Data Format"}
                                                        valueName={
                                                            <>
                                                                <InputText
                                                                    name="dataFormat"
                                                                    placeholder={"Enter Data Format"}
                                                                    onBlur={handleBlur}
                                                                    disabled={isView || values.dataType === "time" || values.dataType === "date" || values.dataType === "dateTime"}
                                                                    onChange={handleChange}
                                                                    value={values.dataFormat}
                                                                    className={`feildLabel ${getClassName({ errors, touched }, 'dataFormat')}`}
                                                                />
                                                                {renderError({ errors, touched }, 'dataFormat')}
                                                            </>
                                                        }
                                                        labelClassName={"labelClass"}
                                                        valueClassName={"valueClass"}
                                                        smValue={2}
                                                        rowClassName="rowMargin"
                                                    />
                                                </>
                                            ) : ''
                                    }
                                    {
                                        (values.dataType !== 'list' && values.dataType !== 'checkBox')
                                            ? (
                                                <>
                                                    <DetailsLabel
                                                        labelName={"Default Value"}
                                                        valueName={
                                                            <>
                                                                <FindInputType
                                                                    dataType={values.dataType}
                                                                    disabled={isView}
                                                                    handleChange={(e) => {
                                                                        handleChange(e)
                                                                        setFieldValue('fieldValue', e.target.value)
                                                                    }}
                                                                    onBlur={handleBlur}
                                                                    name={"defaultValue"}
                                                                    placeholder={'Enter Default Value'}
                                                                    dataObj={{ setFieldValue, values }}
                                                                    value={values.defaultValue}
                                                                    className={`feildLabel ${getClassName({ errors, touched }, 'defaultValue')}`}
                                                                />
                                                                {renderError({ errors, touched }, 'defaultValue')}
                                                            </>
                                                        }
                                                        labelClassName={"labelClass"}
                                                        valueClassName={"valueClass"}
                                                        smValue={2}
                                                        rowClassName="rowMargin"
                                                    />
                                                </>
                                            ) : null
                                    }
                                    {
                                        (values.dataType === 'integer' || values.dataType === 'decimal')
                                            ? (
                                                <>
                                                    <DetailsLabel
                                                        labelName={"Minimum Value"}
                                                        valueName={
                                                            <>
                                                                <FindInputType
                                                                    disabled={isView}
                                                                    dataType={values.dataType}
                                                                    handleChange={handleChange}
                                                                    onBlur={handleBlur}
                                                                    name={"minimumValue"}
                                                                    placeholder={'Enter Minimum Value'}
                                                                    value={values.minimumValue}
                                                                    className={`feildLabel ${getClassName({ errors, touched }, 'minimumValue')}`}
                                                                />
                                                                {renderError({ errors, touched }, 'minimumValue')}
                                                            </>
                                                        }
                                                        labelClassName={"labelClass"}
                                                        valueClassName={"valueClass"}
                                                        smValue={2}
                                                        rowClassName="rowMargin"
                                                    />
                                                </>
                                            ) : ''
                                    }
                                    {
                                        (values.dataType === 'integer' || values.dataType === 'decimal')
                                            ? (
                                                <>
                                                    <DetailsLabel
                                                        labelName={"Maximum Value"}
                                                        valueName={
                                                            <>
                                                                <FindInputType
                                                                    disabled={isView}
                                                                    dataType={values.dataType}
                                                                    handleChange={handleChange}
                                                                    onBlur={handleBlur}
                                                                    name={"maximumValue"}
                                                                    placeholder={'Enter Maximum Value'}
                                                                    value={values.maximumValue}
                                                                    className={`feildLabel ${getClassName({ errors, touched }, 'maximumValue')}`}
                                                                />
                                                                {renderError({ errors, touched }, 'maximumValue')}
                                                            </>
                                                        }
                                                        labelClassName={"labelClass"}
                                                        valueClassName={"valueClass"}
                                                        smValue={2}
                                                        rowClassName="rowMargin"
                                                    />
                                                </>
                                            ) : ''
                                    }
                                    <DetailsLabel
                                        labelName={values.dataType !== "list" ? "Value" : "Datalist Value"}
                                        valueName={
                                            <>
                                                <FindInputType
                                                    disabled={isView}
                                                    dataType={values.dataType}
                                                    handleChange={handleChange}
                                                    name={values.dataType !== "list" ? "fieldValue" : "dataList"}
                                                    onBlur={handleBlur}
                                                    placeholder={'Enter Value'}
                                                    value={(values.fieldValue !== undefined ? values?.fieldValue : values.defaultValue)}
                                                    dataObj={{ setFieldValue, values }}
                                                    className={`feildLabel ${getClassName({ errors, touched }, values.dataType !== "list" ? "fieldValue" : "dataList")}`}
                                                />
                                                {renderError({ errors, touched }, values.dataType !== "list" ? "fieldValue" : "dataList")}
                                            </>
                                        }
                                        labelClassName={"labelClass"}
                                        valueClassName={"valueClass"}
                                        smValue={2}
                                        rowClassName="rowMargin"
                                    />
                                    {
                                        (values.dataType === 'list') ? (
                                            <DetailsLabel
                                                labelName={"Value"}
                                                valueName={
                                                    <>
                                                        <BDOSelect
                                                            name="fieldValue"
                                                            className={isView? 'disabled' : ''}
                                                            value={values.fieldValue}
                                                            onBlur={handleBlur}
                                                            options={optionList}
                                                            isOptionDisabled= {(option)=> option.isdisabled}
                                                        />
                                                        {renderError({ errors, touched }, "value")}
                                                    </>
                                                }
                                                labelClassName={"labelClass"}
                                                valueClassName={"valueClass"}
                                                smValue={2}
                                                rowClassName="rowMargin"
                                            />
                                        ) : ''
                                    }
                                    <DetailsLabel
                                        labelName={"Affected Module"}
                                        valueName={
                                            <>
                                                <InputText
                                                    disabled={isView}
                                                    name="affectedModule"
                                                    onChange={handleChange}
                                                    onBlur={handleBlur}
                                                    placeholder={"Enter Affected Module"}
                                                    value={values.affectedModule}
                                                    className={`feildLabel ${getClassName({ errors, touched }, 'affectedModule')}`}
                                                />
                                                {renderError({ errors, touched }, 'affectedModule')}
                                            </>
                                        }
                                        labelClassName={"labelClass"}
                                        valueClassName={"valueClass"}
                                        smValue={2}
                                        rowClassName="rowMargin"
                                    />
                                    <DetailsLabel
                                        labelName={"Status"}
                                        valueName={
                                            (!values.forApproval) ? (
                                                <>
                                                    <div className="flex">
                                                        <Switch
                                                            disabled={isView}
                                                            name="status"
                                                            type="switch"
                                                            onChange={(e) => {
                                                                setFieldValue('status', e.target.checked)
                                                            }
                                                            }
                                                            id={`custom-switch-${code}-status-modal`}
                                                            checked={values.status}
                                                        />
                                                        <span className="mt2">{getValueText(values.status)}</span>
                                                    </div>
                                                    {renderError({ errors, touched }, 'status')}
                                                </>
                                            ) : (
                                                <InputText className="feildLabel" value="For Approval" disabled />
                                            )
                                        }
                                        labelClassName={"labelClass"}
                                        valueClassName={"valueClass"}
                                        smValue={2}
                                        rowClassName="rowMargin"
                                    />
                                    <DetailsLabel
                                        labelName={"Reason"}
                                        valueName={
                                            <>
                                                <InputText
                                                    disabled={isView}
                                                    onChange={handleChange}
                                                    placeholder={"Enter Reason"}
                                                    value={values.reason}
                                                    onBlur={handleBlur}
                                                    name="reason"
                                                    className={`feildLabel ${getClassName({ errors, touched }, 'reason')}`}
                                                />
                                                {renderError({ errors, touched }, 'reason')}
                                            </>
                                        }
                                        labelClassName={"labelClass"}
                                        valueClassName={"valueClass"}
                                        smValue={2}
                                        rowClassName="rowMargin"
                                    />
                                </Form>
                            )}
                        </Formik>
                    </Card.Text>
                </Card.Body>
            </Card>
            {!isView && <div className="settingsBtnBlock">
                <BDOButton variant="secondary" onClick={() => goBack()} >Cancel</BDOButton>
                <BDOButton variant="primary" onClick={() => formIkRef.current.handleSubmit()}>{(id === 'add') ? 'Add' : 'Save'}</BDOButton>
            </div>}
        </div>
    )
}
export default ViewGatewayProviderSettings;
