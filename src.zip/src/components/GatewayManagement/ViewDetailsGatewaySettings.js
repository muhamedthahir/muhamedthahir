import React, { useState, useEffect } from "react";
import { Row, Col, Image, Spinner } from "react-bootstrap";
import DataTable from "../Global/DataTable/DataTable";
import EditIcon from "../../assets/icons/icon-edit-outline.svg";
import DeleteIcon from "../../assets/icons/icon-delete.svg";
import Switch from "../Global/Switch/Switch";
import { Link, useHistory } from "react-router-dom";
import BDOButton from "../Global/Button/BDOButton";

const editIcon = <Image src={EditIcon} className="icon" />;
const actionDiv = (ele, handleStatusChange, history, idx, handleDelete, isView, accessMap) => {
  let isDelete = false;
  if (ele.gatewaySettingsCode === "To be generated") isDelete = true;
  return (
    (!ele.forApproval)?(
      <div className="actionDiv" key={`action_${ele.gatewaySettingsCode}`}>
        <Switch
          type="switch"
          id={`custom-switch-${ele.gatewaySettingsCode}`}
          defaultChecked={ele.status}
          onChange={(e) =>
            handleStatusChange(e.target.checked, ele.gatewaySettingsCode, accessMap)
          }
        />
        {(!isView &&  accessMap.canUpdate) && <div
          className="editDiv"
          onClick={() =>
            history.push({
              pathname: `/gatewaymanagment/gatewaySettings/${ele.gatewaySettingsCode}`,
              state: { storage: "local", idx},
            })
          }
        >
          {editIcon}
        </div>}
        {isDelete && (
          <div className="deleteDiv">
            <Image
              onClick={() => handleDelete(idx)}
              src={DeleteIcon}
              className="icon"
            />
          </div>
        )}
    </div>
  ):'')
};

const sortByElement = (rowA, rowB, colId, desc) => {
  const findFn = (entry) => entry.column && entry.column.id === colId;
  const foundAData = rowA.cells.find(findFn);
  const foundBData = rowB.cells.find(findFn);
  const aValue =
    typeof rowA.cells[0] !== "function" &&
    foundAData &&
    foundAData.value.props.children;
  const bValue =
    typeof rowB.cells[0] !== "function" &&
    foundBData &&
    foundBData.value.props.children;
  return alphaNumericSorting(aValue, bValue, colId, desc);
};

const alphaNumericSorting = (frstValue, scndValue, colId, desc = false) => {
  if (frstValue && scndValue) {
    if (!desc) return frstValue.localeCompare(scndValue);
    return -1 * scndValue.localeCompare(frstValue);
  }
};

const statusDiv = (data) => {
  const { status, forApproval } = data;
  let stat = "Disabled";
  let className = "status_disabled";
  if (status === true ) {
    stat = "Enabled";
    className = "status_enabled";
  }
  if( forApproval ) {
    stat = "For Approval"
    className = "forApproval"
  }
  return <div className={className}>{stat}</div>;
};
const codeDiv = (data, idx, isView, access) => (
  (access) ? (
    <Link
      className="modalLink"
      to={{
        pathname: `/gatewaymanagment/gatewaySettings/${data.gatewaySettingsCode}`,
        state: { storage: "local", idx,  action: 'view', parentIsView: isView },
      }}
    >
      {data.gatewaySettingsCode}
    </Link>
  ):(
    <span>{data.gatewaySettingsCode}</span>
  )
);
let pageProperty = {}
function ViewDetailsGatewaySettings(props) {
  const {
    gatewaySettingsList,
    canCreate, canUpdate, canEnable, canDisable,
    canViewRecord,
    maximumNoOfAllowablegwSettings,
    setToastData,
    isView
  } = props;
  let [settingData = gatewaySettingsList, setSettingData] = useState();
  const handleStatusChange = (value, code, accessMap) => {
    const countOfUpdate = gatewaySettingsList.filter(
      (ele) => ele.isUpdate
    ).length;
    if( accessMap.canEnable || accessMap.canDisable) {
      if (countOfUpdate < maximumNoOfAllowablegwSettings) {
        const finder = gatewaySettingsList.find(
          (ele) => ele.gatewaySettingsCode === code
        );
        finder["status"] = value;
        if( finder["isUpdate"] === undefined) {
          finder["isUpdate"] = true;
        }
        setSettingData([...gatewaySettingsList]);
      } else {
        setToastData({
          toastState: true,
          toastType: "warning",
          toastMessage: "Unable to add/update more Gateway Settings",
        });
        window.scrollTo({
          top: 0,
          left: 0,
          behavior: "smooth",
        });
      }
    } else {
      setToastData({
        toastState: true,
        toastType: "warning",
        toastMessage: "Unauthorized Access for this  action. Please contact admin",
      });
      window.scrollTo({
        top: 0,
        left: 0,
        behavior: "smooth",
      });
    }
  };
  const history = useHistory();
  const addSettings = () => {
    const countOfUpdate = gatewaySettingsList.filter(
      (ele) => ele.isUpdate
    ).length;
    if (countOfUpdate < maximumNoOfAllowablegwSettings) {
      history.push({
        pathname: "/gatewaymanagment/gatewaySettings/add",
        state: { storage: "local" },
      });
    } else {
      setToastData({
        toastState: true,
        toastType: "warning",
        toastMessage: "Unable to add/update more Gateway Settings",
      });
      window.scrollTo({
        top: 0,
        left: 0,
        behavior: "smooth",
      });
    }
  };
  let columns = [
    {
      Header: "Code",
      accessor: "gatewaySettingsCode",
      selector: "code",
      sortType: (rowA, rowB, colId, desc) => {
        return sortByElement(rowA, rowB, colId, desc);
      },
    },
    {
      Header: "Name",
      accessor: "fieldName",
    },
    {
      Header: "Value",
      accessor: "fieldValue",
    },
    {
      Header: "Status",
      accessor: "status",
      sortType: (rowA, rowB, colId, desc) => {
        return sortByElement(rowA, rowB, colId, desc);
      },
    },
    {
      Header: "Actions",
      accessor: "action",
    }
  ];

  useEffect(()=> {
    return (() => pageProperty={})
  }, [])

  const handleDelete = (idx) => {
    gatewaySettingsList.splice(idx, 1);
    setSettingData([...gatewaySettingsList]);
  };
  const localObj =
    settingData &&
    settingData.map((ele, idx) => {
      return {
        ...ele,
        gatewaySettingsCode: codeDiv(ele, idx, isView, canViewRecord),
        status: statusDiv(ele),
        action: actionDiv(
          ele, handleStatusChange, history, idx,
          handleDelete, isView, {canEnable , canDisable, canUpdate}
        ),
      };
    });
  const returnPageProperty = (pgSize, pgIndex) => {
    pageProperty["pageNo"]= pgIndex + 1;
    pageProperty["pageSize"]= pgSize;
  }
  return (
    <div className="gatewaySettings">
      <div className="searchCard">
        <Row className="mb10">
          <Col sm={8}>
            <b>Gateway Settings</b>
          </Col>
          <Col className="alignRight">
            {(canCreate  && !isView) && (
              <BDOButton variant="add" onClick={() => addSettings()}>
                Add Gateway Settings
              </BDOButton>
            )}
          </Col>
        </Row>
        <div className="dataBlock">
          {localObj !== undefined ? (
            <DataTable
              columns={columns}
              data={localObj || []}
              showPagination={true}
              defaultPageSize={5}
              returnPageProperty={returnPageProperty}
              pageProperty={pageProperty}
            />
          ) : (
            <div className="alignCenter">
              <Spinner animation="border" />
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default ViewDetailsGatewaySettings;
