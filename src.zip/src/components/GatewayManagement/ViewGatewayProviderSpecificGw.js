/* eslint-disable react-hooks/exhaustive-deps */
import React, { useState, useEffect, useRef } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import DetailsLabel from './DetailsLabel';
import {
    Card, Image, Spinner, Row,
    Col, Container, Form
} from 'react-bootstrap';
import { Link, useHistory } from 'react-router-dom';
import './styles/viewGatewaySettings.scss';
import Switch from '../Global/Switch/Switch';
import DataTable from '../Global/DataTable/DataTable';
import EditIcon from '../../assets/icons/icon-edit-outline.svg';
import DeleteIcon from '../../assets/icons/icon-delete.svg';
import BDOToast from '../Global/BDOToast/BDOToast';
import backIcon from '../../assets/icons/backIcon.png';
import { Formik } from 'formik';
import BDOButton from '../Global/Button/BDOButton'
import * as Yup from 'yup';
import InputText from '../../components/Global/Input/InputText';
import {
    retrieveAllGatewayProvider, retrieveGatewayProviders
} from '../../actions/gatewaymanagement';
import BDOSelect from "../Global/Select/BDOSelect";

const getProviderStatus = values => values.gatewayProviderStatus?'Enabled': 'Disabled'

const codeDiv = (data, providerCode, providerIdx, idx, isView) => (
    <Link
        className="modalLink"
        to={{
            pathname: `/gatewaymanagment/gatewayProviders/${providerCode}/${data.code}`,
            state: { storage: "local", providerIdx, idx, action: 'view', parentIsView: isView }
        }}
    >
        {data.code}
    </Link>
)

const statusDiv = (settingsdata) => {
    let stat = 'Disabled';
    let className = 'status_disabled';
    if (settingsdata.status) {
        stat = 'Enabled';
        className = 'status_enabled';
    }
    if (settingsdata.forApproval) {
        stat = 'For Approval';
        className = 'forApproval';
    }
    return (
        <div className={className}>{stat}</div>
    )
}

const actionDiv = (ele, handleStatusChange, providerCode, history, idx, rIdx, { handleDelete, isView}) => (
    (!ele.forApproval) ? (
        <div className="actionDiv" key={`action_${ele.code}`}>
            <Switch
                type="switch"
                id={`custom-switch-${ele.code}`}
                defaultChecked={ele.status}
                onChange={(e) => handleStatusChange(e.target.checked, ele.code)}
            />
            {!isView && <div className="editDiv" onClick={
                () => history.push({
                    pathname: `/gatewaymanagment/gatewayProviders/${providerCode}/${ele.gatewayProviderSettingCode}`,
                    state: { storage: "local", providerIdx: idx, idx: rIdx }
                })}>
                <Image src={EditIcon} className="icon" />
            </div>}
            {ele.code === "To be generated" && (
                <div className="deleteDiv">
                    <Image onClick={() => handleDelete(rIdx)} src={DeleteIcon} className="icon" />
                </div>
            )}
        </div>
    ) : ''
);

const renderError = (formik, paramname) => (
    formik.errors[(paramname)] ? (
        <span className='mb-1 error-text'>
            {formik.errors[(paramname)]}
        </span>
    ) : null
)

const getClassName = ( formik, paramname) => formik.errors[(paramname)] ? 'err-border': ''

let pageProperty = {}

function ViewGatewayProviderSpecificGw(props) {
    const dispatch = useDispatch();
    const history = useHistory();
    const formikRef = useRef();

    const {
        viewGateway = {}, viewGatewayProviders = {}, viewAllGatewayProvider = [],
        gatewayInitialData = {}
    } = useSelector(stateRed => stateRed.gatewayReducer);
    const { match: { params: { id } }, location: { state = {} } } = props;
    const { storage, idx, action, parentIsView } = state;
    const [toastObj, setToastData] = useState({});
    const isView = action === "view"
    console.log('viewAllGatewayProvider', viewAllGatewayProvider)
    useEffect(() => {
        if (id === "add" && viewAllGatewayProvider.length === 0) {
            dispatch(retrieveAllGatewayProvider())
        }
        if (props.location.toastObj) {
            setToastData(props.location.toastObj)
            window.scrollTo({
                top: 0,
                left: 0,
                behavior: "smooth"
            })
        }
        if (!isView) {
            window.onbeforeunload = (e) => {
                e.preventDefault();
                e.returnValue = '';
            }
            const listener = history.listen((loc) => {
                const allowedPath = ["/gatewaymanagment/gatewayProviders", "/gatewaymanagment/gatewayProvidersGw", "/gatewaymanagment/"]
                const { location: { pathname } } = history;
                if (allowedPath.filter(ele => pathname.includes(ele)).length === 0 && pathname !== `/gatewaymanagment/gatewayProvidersGw/${id}`) {
                    if (!window.confirm("Leaving the page will discard any unsaved changes")) {
                        history.go(-1);
                    } else {
                        clearData();
                    }
                } else {
                    window.onbeforeunload = undefined;
                }
            })
            return () => {
                window.onbeforeunload = undefined;
                return listener()
            }
        }

    }, []);
    const { data = {} } = viewGateway;
    const { gatewayProviderList = [], gatewayTypeDetails = {} } = data;
    let maximumNoOfAllowablegwProviderSettings = (gatewayInitialData.data && gatewayInitialData.data.maximumNoOfAllowablegwProviderSettings) || data.maximumNoOfAllowablegwProviderSettings
    const recData = gatewayProviderList[idx] || viewGatewayProviders.data;
    const gatewayCode = gatewayTypeDetails.gatewayId;
    const [settingsData = recData, setData] = useState()
    const {
        gatewayProviderSettingList = [], code, description
    } = (settingsData || {});
    const validationSchema = {
        code: Yup.string().required('Required field'),
    }
    const handleStatusChange = (value, pscode) => {
        const finder = gatewayProviderSettingList.find((ele) => ele.code === pscode);
        finder["status"] = value;
        finder["isUpdate"] = true;
        setData({ ...settingsData, gatewayProviderSettingList: [...gatewayProviderSettingList] });
    }
    const clearData = () => {
        viewGatewayProviders.data = undefined;
    }

    const handleDelete = (rIdx) => {
        gatewayProviderSettingList.splice(rIdx, 1);
        setData({ ...recData, gatewayProviderSettingList: gatewayProviderSettingList })
    }

    const returnPageProperty = (pgSize, pgIndex) => {
        pageProperty["pageNo"] = pgIndex + 1;
        pageProperty["pageSize"] = pgSize;
    }
    const handleSubmitProvider = (storageType, values) => {
        clearData();
        if (storageType === "local") {
            let toastMessage = '';
            const tempObj = viewGateway;
            if (id === "add") {
                if (tempObj.data.gatewayProviderList.length === 0) {
                    let childList = values.gatewayProviderSettingList || []
                    tempObj.data.gatewayProviderList.push({
                        ...values, distributionPercentage: 0, gatewayProviderSettingList: childList, templyPushed: false, gatewaySettingsCode: "To be generated",
                        isUpdate: true, isNewlyAdded: true, forApproval: false
                    })
                } else {
                    tempObj.data.gatewayProviderList[idx] = {
                        ...values, gatewaySettingsCode: "To be generated", templyPushed: false, isUpdate: true, isNewlyAdded: true, forApproval: false
                    };
                }
                toastMessage = 'Gateway Provider added';
            } else {
                tempObj.data.gatewayProviderList[idx] = { ...values, isUpdate: true, forApproval: false };
                toastMessage = 'Gateway Provider updated';
            }
            goBack({ toastState: true, toastMessage: toastMessage, toastType: 'success' })
        }
    }
    const goBack = (toastObject) => {
        clearData();
        if (!toastObject) {
            viewGateway.data.gatewayProviderList = viewGateway.data.gatewayProviderList.filter(ele => !ele.templyPushed);
        }
        if (storage === "local") {
            history.push({
                pathname: `/gatewaymanagment/${gatewayCode ? gatewayCode : gatewayTypeDetails.gatewayCode}`,
                dataFrom: "localState",
                ...toastObject,
                storage: "local",
                state: { action: parentIsView ? "view" : "" }
            });
        }
        else {
            history.push(`/gatewaymanagment/${gatewayCode ? gatewayCode : ''}`);
        }
    }
    const localObj = gatewayProviderSettingList && gatewayProviderSettingList.map((ele, rIdx) => {
        return {
            ...ele,
            code: codeDiv(ele, code, idx, rIdx, isView),
            status: statusDiv(ele),
            action: actionDiv(ele, handleStatusChange, code, history, idx, rIdx, { handleDelete , isView}),
        }
    });
    const onChangeHandler = ( value, codeList) => {
        dispatch(retrieveGatewayProviders(value, codeList))
    }
    if( viewGatewayProviders && viewGatewayProviders.data) {
        gatewayProviderList[idx] = {
            ...viewGatewayProviders.data,
            templyPushed: true
        }
    }

    const addProviderSetting = (values, setErrors) => {
        if (values.code) {
            const countOfUpdate = gatewayProviderSettingList.filter(ele => ele.isUpdate).length;
            if (countOfUpdate < maximumNoOfAllowablegwProviderSettings) {
                gatewayProviderList[idx] = { gatewayProviderSettingList: [], ...gatewayProviderList[idx], ...values, templyPushed: true }
                history.push({
                    pathname: `/gatewaymanagment/gatewayProviders/${id}/add`,
                    state: {
                        storage: "local",
                        providerIdx: idx
                    }
                })
            } else {
                setToastData({ toastState: true, toastType: "warning", toastMessage: "Unable to add/ update more Gateway Provider Mapping Settings" })
                window.scrollTo({
                    top: 0,
                    left: 0,
                    behavior: "smooth"
                })
            }

        } else {
            setErrors({ code: 'Code is required' })
        }

    }
    const columns = [
        {
            Header: 'Code',
            accessor: 'code',
            selector: 'code',
            sortType: 'basic',
        },
        {
            Header: 'Name',
            accessor: 'fieldName',

        },
        {
            Header: 'Value',
            accessor: 'fieldValue'
        },
        {
            Header: 'Status',
            accessor: 'status',
            disableSortBy: true
        },
        {
            Header: 'Actions',
            accessor: 'action',
            disableSortBy: true,
            className: 'actionCol'
        }
    ];
    const providerCodeList = viewAllGatewayProvider || [];
    console.log('providerCodeList', providerCodeList)
    return (
        <div className="viewLayout-gm gatewaySettings">
            <div className="redirect">
                <div style={{ cursor: 'pointer' }} onClick={() => goBack()}>
                    <Image src={backIcon} className="icon" />
                </div>
                <b>{(id === "add") ? "Map Gateway Provider" : `${code} - ${description}`}</b>
            </div>
            {
                toastObj.toastState && (
                    <BDOToast
                        openState={toastObj.toastState}
                        type={toastObj.toastType}
                        bodyMessage={toastObj.toastMessage}
                        onClose={() => { setToastData({}) }}
                    />
                )
            }
            <Formik
                initialValues={{ gatewayProviderStatus: false, ...settingsData, code: settingsData?.gatewayProvider?.code || settingsData?.code}}
                enableReinitialize
                validationSchema={Yup.object().shape(validationSchema)}
                innerRef={formikRef}
                onSubmit={(values) => {
                    handleSubmitProvider(storage, values)
                }}
            >
                {({
                    errors, touched, values, handleChange,
                    setFieldValue, handleBlur, setErrors
                }) => (
                    <Form>
                        <Card>
                            <Card.Body>
                                <div className="cardHeader">
                                    <Card.Title className="cardTitle">Gateway Provider Mapping Details</Card.Title>
                                </div>
                                <Card.Text>
                                    <Container>
                                        <DetailsLabel
                                            labelName={"Provider Code"}
                                            valueName={
                                                <>
                                                    {(id === "add") ? (
                                                        <BDOSelect
                                                            name="code"
                                                            options={providerCodeList && providerCodeList.map(ele => { return { label: ele.name, value: ele.code } })}
                                                            placeholder={"Select Provider Code"}
                                                            onChange={(e) => {
                                                                setFieldValue('code', e.value)
                                                                onChangeHandler(e.value, providerCodeList)
                                                            }}
                                                            value={values.code}
                                                            className={
                                                                `feildLabel selectDropDown ${props.className} ${isView  && 'disabled'} ${getClassName({ errors}, 'code')}`
                                                            }
                                                        />
                                                    ) : (
                                                        <InputText value={values.code} className="feildLabel" disabled />
                                                    )}
                                                    {renderError({ errors, touched }, 'code')}
                                                </>
                                            }
                                            labelClassName={"bodyRowLabel"}
                                            valueClassName={"bodyRowValue"}
                                            smValue={2}
                                            rowClassName="rowMargin"
                                        />
                                        <DetailsLabel
                                            labelName={"Provider Name"}
                                            valueName={<InputText value={values.name} className="feildLabel" disabled />}
                                            labelClassName={"bodyRowLabel"}
                                            valueClassName={"bodyRowValue"}
                                            smValue={2}
                                            rowClassName="rowMargin"
                                        />
                                        <DetailsLabel
                                            labelName={"Provider Description"}
                                            valueName={<InputText value={values.description} className="feildLabel" disabled />}
                                            labelClassName={"bodyRowLabel"}
                                            valueClassName={"bodyRowValue"}
                                            smValue={2}
                                            rowClassName="rowMargin"
                                        />
                                        <DetailsLabel
                                            labelName={"Internal Api Integration"}
                                            valueName={<InputText value={values.apiIntegration} className="feildLabel" disabled />}
                                            labelClassName={"bodyRowLabel"}
                                            valueClassName={"bodyRowValue"}
                                            smValue={2}
                                            rowClassName="rowMargin"
                                        />
                                        <DetailsLabel
                                            labelName={"Gateway Scheme"}
                                            valueName={<InputText value={values.providerUrl} className="feildLabel" disabled />}
                                            labelClassName={"bodyRowLabel"}
                                            valueClassName={"bodyRowValue"}
                                            smValue={2}
                                            rowClassName="rowMargin"
                                        />
                                        <DetailsLabel
                                            labelName={"Gateway Port"}
                                            valueName={<InputText value={values.gatewayPort} className="feildLabel" disabled />}
                                            labelClassName={"bodyRowLabel"}
                                            valueClassName={"bodyRowValue"}
                                            smValue={2}
                                            rowClassName="rowMargin"
                                        />
                                        <DetailsLabel
                                            labelName={"Status"}
                                            valueName={
                                                (values.gatewayProviderForApproval || values.gatewayProviderForApproval === undefined)? (
                                                    <div className="flex">
                                                        <Switch
                                                            type="switch"
                                                            id={`custom-switch-${code}-active-modal`}
                                                            checked={values.gatewayProviderStatus}
                                                            disabled
                                                        />
                                                        <span className="mt2">{getProviderStatus( values)}</span>
                                                    </div>
                                                ): (
                                                    <InputText  className="feildLabel" value="For Approval" disabled />
                                                )
                                            }
                                            labelClassName={"bodyRowLabel"}
                                            valueClassName={"bodyRowValue"}
                                            smValue={2}
                                            rowClassName="rowMargin"
                                        />
                                    </Container>
                                </Card.Text>
                            </Card.Body>
                        </Card>
                        <div className="tableBlock">
                            <Card className="mt16">
                                <Card.Body>
                                    <div className="gatewaySettings">
                                        <div className="searchCard">
                                            <Row className="mb15">
                                                <Col sm={8}>
                                                    <b>Gateway Mapping Provider Settings</b>
                                                </Col>
                                                <Col className="alignRight">
                                                    {!isView && <BDOButton variant="add" onClick={() => addProviderSetting(values, setErrors)}>
                                                        Add Mapping Provider Setting
                                                    </BDOButton>}
                                                </Col>
                                            </Row>
                                            <div className="dataBlock">
                                                {
                                                    localObj !== undefined
                                                        ? (
                                                            <DataTable
                                                                columns={columns}
                                                                data={localObj}
                                                                showPagination={true}
                                                                returnPageProperty={returnPageProperty}
                                                                pageProperty={pageProperty}
                                                            />) : (
                                                            <div className="alignCenter">
                                                                <Spinner animation="border" />
                                                            </div>
                                                        )
                                                }
                                            </div>
                                        </div>
                                    </div>
                                </Card.Body>
                            </Card>
                        </div>
                    </Form>
                )}
            </Formik>
            {!isView && <div className="settingsBtnBlock">
                <BDOButton variant="secondary" onClick={() => goBack()} >Cancel</BDOButton>
                <BDOButton variant="primary" onClick={() => formikRef.current.handleSubmit()}>{(id === 'add') ? 'Add' : 'Save'}</BDOButton>
            </div>}
        </div>
    )
}
export default ViewGatewayProviderSpecificGw;
