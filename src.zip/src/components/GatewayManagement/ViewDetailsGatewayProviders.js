import React, { useEffect, useState } from "react";
import { Row, Col, Image, Spinner } from "react-bootstrap";
import DataTable from "../Global/DataTable/DataTable";
import InputText from "../Global/Input/InputText";
import EditIcon from "../../assets/icons/icon-edit-outline.svg";
import DeleteIcon from "../../assets/icons/icon-delete.svg";
import Switch from "../Global/Switch/Switch";
import { Link, useHistory } from "react-router-dom";
import BDOButton from '../Global/Button/BDOButton'


const editIcon = <Image src={EditIcon} className="icon" />;
const actionDiv = (
  ele,
  handleStatusChange,
  history,
  idx,
  handleDeleteChange,
  isView,
  accessMap
) => (
  (!ele.forApproval)?(
  <div className="actionDiv" key={`action_${ele.code}`}>
    <Switch
      type="switch"
      id={`custom-switch-${ele.code}_${idx}`}
      defaultChecked={ele.status}
      onChange={(e) => handleStatusChange(e.target.checked, idx, accessMap)}
    />
    {(!isView && accessMap.canUpdate) && <div
      className="editDiv"
      onClick={() =>
        history.push({
          pathname: `/gatewaymanagment/gatewayProvidersGw/${ele.code}`,
          state: { storage: "local", idx },
        })
      }
    >
      {editIcon}
    </div>}
    {ele.gatewaySettingsCode === "To be generated" && (
      <div className="deleteDiv">
        <Image
          onClick={() => handleDeleteChange(idx)}
          src={DeleteIcon}
          className="icon"
        />
      </div>
    )}
  </div>
  ):''
);

const constructSpanMsg = ( gatewayProviderList, headerText, setHeaderText, setHeaderClass) => {
  const findActiveEle = gatewayProviderList
  .filter((ele) => ele.status)
  .map((retrnEle) =>
    retrnEle.distributionPercentage ? retrnEle.distributionPercentage : 0
  );
  if (findActiveEle.length !== 0) {
    const calculateTotal = findActiveEle.reduce(
      (prev, current) => prev + current
    );
    if (
      calculateTotal > 100 &&
      headerText !== `Excess :${calculateTotal - 100} %`
    ) {
      setHeaderText(`Excess :${calculateTotal - 100} %`);
      setHeaderClass("warningText");
    } else if (
      calculateTotal < 100 &&
      headerText !== `Remaining :${100 - calculateTotal} %`
    ) {
      setHeaderText(`Remaining :${100 - calculateTotal} %`);
      setHeaderClass("warningText");
    } else if (calculateTotal === 100 && headerText !== `Remaining : 0 %`) {
      setHeaderText(`Remaining : 0 %`);
      setHeaderClass("successText");
    }
  } else if(headerText !== `Remaining :100 %`) {
    setHeaderText(`Remaining :100 %`);
    setHeaderClass("warningText");
  }
}

const sortByElement = (rowA, rowB, colId, desc) => {
  const findFn = (entry) => entry.column && entry.column.id === colId;
  const foundAData = rowA.cells.find(findFn);
  const foundBData = rowB.cells.find(findFn);
  const aValue =
    typeof rowA.cells[0] !== "function" &&
    foundAData &&
    foundAData.value.props.children;
  const bValue =
    typeof rowB.cells[0] !== "function" &&
    foundBData &&
    foundBData.value.props.children;
  return alphaNumericSorting(aValue, bValue, colId, desc);
};

const alphaNumericSorting = (frstValue, scndValue, colId, desc = false) => {
  if (frstValue && scndValue) {
    if (!desc) return frstValue.localeCompare(scndValue);
    return -1 * scndValue.localeCompare(frstValue);
  }
};

const codeDiv = (data, idx, isView, access) => (
  (access) ? (
    <Link
      className="modalLink"
      to={{
        pathname: `/gatewaymanagment/gatewayProvidersGw/${data.code}`,
        state: { storage: "local", idx , action: 'view', parentIsView: isView},
      }}
    >
      {data.code}
    </Link>
  ): (
    <span>{data.code}</span>
  )
);

const constructInputDiv = (ele, idx, onChangeHandler, isView) => {
  let divEle = ele.distributionPercentage + " %";
  if( !isView) {
    divEle = (
      <div className="flex mr5">
        <InputText
          value={parseInt(ele.distributionPercentage ? ele.distributionPercentage : 0)}
          onChange={(e) => onChangeHandler(parseInt(e.target.value), idx)}
          type={"number"}
          className="feildDistribution"
          min={0}
          max={100}
        />
        <div className="percentageBlock">%</div>
      </div>
    )
  }
  return divEle
};
let pageProps = {}
function ViewDetailsGatewayProviders(props) {
  const {
    gatewayProviderList,
    canUpdate,canCreate, canEnable, canDisable,
    canViewRecord,
    maximumNoOfAllowablegwProvider,
    setToastData,
    isView
  } = props;
  const history = useHistory();
  const [headerText, setHeaderText] = useState();
  const [headerClass, setHeaderClass] = useState();
  let [providerData = gatewayProviderList, setProviderData] = useState();
  const handleStatusChange = (value, idx, accessMap) => {
    const countOfUpdate = gatewayProviderList.filter(
      (ele) => ele.isUpdate
    ).length;
    if ( accessMap.canEnable || accessMap.canDisable) {
      if (countOfUpdate < maximumNoOfAllowablegwProvider||  gatewayProviderList[idx]["isUpdate"]) {
        gatewayProviderList[idx]["status"] = value ;
        if( gatewayProviderList[idx]["isUpdate"] === undefined) {
          gatewayProviderList[idx]["isUpdate"] = true
        }
        setProviderData([...gatewayProviderList]);
      } else {
        setToastData({
          toastState: true,
          toastType: "warning",
          toastMessage: "Unable to map more Gateway Providers",
        });
        window.scrollTo({
          top: 0,
          left: 0,
          behavior: "smooth",
        });
        setProviderData([...gatewayProviderList]);
      }
    } else {
      setToastData({
        toastState: true,
        toastType: "warning",
        toastMessage: "Unauthorized Access for this  action. Please contact admin",
      });
      window.scrollTo({
        top: 0,
        left: 0,
        behavior: "smooth",
      });
    }
  };

  const returnPageProperty = (pgSize, pgIndex) => {
    pageProps["pageNo"]= pgIndex + 1;
    pageProps["pageSize"]= pgSize;
  }

  const addProviders = () => {
    const countOfUpdate = gatewayProviderList.filter(
      (ele) => ele.isUpdate
    ).length;
    if (countOfUpdate < maximumNoOfAllowablegwProvider) {
      history.push({
        pathname: "/gatewaymanagment/gatewayProvidersGw/add",
        state: { storage: "local", idx: gatewayProviderList.length },
      });
    } else {
      setToastData({
        toastState: true,
        toastType: "warning",
        toastMessage: "Unable to map more Gateway Providers",
      });
      window.scrollTo({
        top: 0,
        left: 0,
        behavior: "smooth",
      });
    }
  };
  if (gatewayProviderList && gatewayProviderList.length > 0) {
    constructSpanMsg(gatewayProviderList, headerText, setHeaderText, setHeaderClass)
     
  }
  let columns = [
    {
      Header: "Code",
      accessor: "code",
      selector: "code",
      sortType: (rowA, rowB, colId, desc) => {
        return sortByElement(rowA, rowB, colId, desc);
      },
    },
    {
      Header: "Description",
      accessor: "description",
    },
    {
      Header: () => (
        <>
          <span>Distribution</span>
          <p className={headerClass}>{headerText}</p>
        </>
      ),
      accessor: "distributionPercentage",
      disableSortBy: true,
    },
    {
      Header: "Status",
      accessor: "status",
      sortType: (rowA, rowB, colId, desc) => {
        return sortByElement(rowA, rowB, colId, desc);
      },
    },
    {
      Header: "Action",
      accessor: "action",
      disableSortBy: true,
    },
  ];

  const statusDiv = (rData) => {
    const { status, forApproval } = rData;
    let stat = "Disabled";
    let className = "status_disabled";
    if (status) {
      stat = "Enabled";
      className = "status_enabled";
    }
    if ( forApproval) {
      stat = "For Approval"
      className = "forApproval"
    }
    return <div className={className}>{stat}</div>;
  };

  const handleDeleteChange = (idx) => {
    gatewayProviderList.splice(idx, 1);
    setProviderData([...gatewayProviderList]);
  };
  // To remove page props
  useEffect(()=> {
    return (() => pageProps={})
  }, [])

  const onChangeHandler = (value, idx) => {
    gatewayProviderList[idx]["distributionPercentage"] = Number(value);
    gatewayProviderList[idx]["isUpdate"] = true;
    const findActiveEle = gatewayProviderList
      .filter((ele) => ele.status)
      .map((retrnEle) =>
        retrnEle.distributionPercentage ? retrnEle.distributionPercentage : 0
      );
    if (findActiveEle.length !== 0) {
      const calculateTotal = findActiveEle.reduce(
        (prev, current) => prev + current
      );
      if (
        calculateTotal > 100 &&
        headerText !== `Excess :${calculateTotal - 100} %`
      ) {
        setHeaderText(`Excess :${calculateTotal - 100} %`);
        setHeaderClass("warningText");
      } else if (
        calculateTotal < 100 &&
        headerText !== `Remaining :${100 - calculateTotal} %`
      ) {
        setHeaderText(`Remaining :${100 - calculateTotal} %`);
        setHeaderClass("warningText");
      } else if (calculateTotal === 100 && headerText !== `Remaining : 0 %`) {
        setHeaderText(`Remaining : 0 %`);
        setHeaderClass("successText");
      }
    } else if(headerText !== `Remaining :100 %`) {
      setHeaderText(`Remaining :100 %`);
      setHeaderClass("warningText");
    } 
    setProviderData([...gatewayProviderList]);
  };

  const localObj =
    providerData &&
    providerData.map((ele, idx) => {
      return {
        ...ele,
        code: codeDiv(ele, idx, isView, canViewRecord),
        status: statusDiv(ele),
        action: actionDiv(
          ele,
          handleStatusChange,
          history,
          idx,
          handleDeleteChange,
          isView,
          {canUpdate, canEnable, canDisable}
        ),
        distributionPercentage: constructInputDiv(ele, idx, onChangeHandler, isView),
      };
    });

  return (
    <div className="gatewaySettings">
      <div className="searchCard">
        <Row className="mb10">
          <Col sm={8}>
            <b>Gateway Provider Mapping</b>
          </Col>
          <Col className="alignRight">
              { (canCreate && !isView) && 
                <BDOButton variant="add" onClick={() => addProviders()}>
                  Map Gateway Provider
                </BDOButton>
              }
          </Col>
        </Row>
        <div className="dataBlock">
          {localObj !== undefined ? (
            <DataTable
              columns={columns}
              data={localObj || []}
              showPagination={true}
              key={"gwprforgwtype"}
              returnPageProperty={returnPageProperty}
              pageProperty={pageProps}
              defaultPageSize={5}
            />
          ) : (
            <div className="alignCenter">
              <Spinner animation="border" />
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default ViewDetailsGatewayProviders;
