import React from 'react';
import {
    Card,
    Container,
} from 'react-bootstrap';
import InputText from '../../components/Global/Input/InputText';
import Switch from '../../components/Global/Switch/Switch';
import DetailsLabel from './DetailsLabel';

const renderError = ( formik, paramname) => (
    formik.errors[(paramname)] ? (
        <span className='mb-1 error-text'>
            {formik.errors[(paramname)]} 
        </span>
    ) : null
)
const getClassName = (formik, paramname) => {
    let returnMsg = "input-text";
    if( formik.errors[(paramname)] ) return returnMsg+" error"
    return returnMsg
}


function ViewGatewayDetails(props){
    const {
        values: { gatewayCode, description, name, status, forApproval },
        handleChange, setFieldValue, gateway, gatewayId, formik,
        handleBlur, isView
    } = props;

    const handleSwitchChange = ( value ) => {
        setFieldValue('status',value);
    }
    
    return(
        <Card>
            <Card.Body>
                <div className="cardHeader">
                    <Card.Title className="cardTitle">Gateway Details</Card.Title>
                </div>
                <Card.Text>
                    {
                        (gatewayId === 'add') ? (
                            <>
                                <div className="mb16">
                                    <div className="guideText">Provide the necessary details for the gateway you are adding</div>
                                    <div className="guideText">Gateway setting and providers will be created once the gateway is added</div>
                                </div>
                                <div className="boldText mb16">All fields are required</div>
                            </>
                        ) : ''
                    }
                    <Container>
                        <DetailsLabel 
                            labelClassName="bodyRowLabel" 
                            labelName="Gateway Code" 
                            valueName={
                                <>
                                    <InputText
                                        name="gatewayCode" 
                                        value={gatewayCode|| ''} 
                                        onChange={(e) => {
                                            handleChange(e)
                                            gateway["gatewayCode"] = e.target.value;
                                        }} 
                                        className={`feildLabel textArea ${getClassName(formik, 'gatewayCode')} ${gatewayId !== "add"?'disabled':''}`} 
                                        placeholder="Enter Gateway Code"
                                        disabled={gatewayId !== "add"}
                                        onBlur={handleBlur}
                                    />
                                    {renderError(formik, 'gatewayCode')}
                                </>
                            }
                            valueClassName="bodyRowValue"
                            rowClassName="rowMargin"
                        />
                        <DetailsLabel 
                            labelClassName="bodyRowLabel" 
                            labelName="Gateway Name" 
                            valueName={
                                <>
                                    <InputText 
                                        name="name"
                                        value={name|| ''}
                                        onChange={(e) => {
                                            handleChange(e)
                                            gateway["name"] = e.target.value;
                                        }} 
                                        onBlur={handleBlur}
                                        disabled={isView}
                                        placeholder="Enter Gateway Name"
                                        className={`feildLabel textArea ${getClassName(formik, 'name')}`} 
                                    />
                                    {renderError(formik, 'name')}
                                </>
                            }
                            valueClassName="bodyRowValue"
                            rowClassName="rowMargin"
                        />
                        <DetailsLabel 
                            labelClassName="bodyRowLabel" 
                            labelName="Description" 
                            valueName={
                                <>
                                    <InputText 
                                        name="description" 
                                        as="textarea" 
                                        value={description || ''} 
                                        rows={3} 
                                        placeholder="Enter Gateway Description"
                                        onChange={(e) => {
                                            handleChange(e)
                                            gateway["description"] = e.target.value;
                                        }} 
                                        disabled={isView}
                                        onBlur={handleBlur}
                                        className={`textAreaLabel textArea ${getClassName(formik, 'description')}`} 
                                    />
                                    {renderError(formik, 'description')}
                                </>
                            }
                            valueClassName="bodyRowValue"
                            rowClassName="rowMargin"
                        />
                        <DetailsLabel 
                            labelClassName="bodyRowLabel" 
                            labelName="Status" 
                            valueName={
                                <div className="detailsActive">
                                    {(!forApproval)?(
                                        <>
                                            <Switch 
                                                type="switch" 
                                                id={`${gatewayCode}_${gatewayId}`}
                                                name="status" 
                                                disabled={isView}
                                                checked={status} 
                                                onChange={(e) => {
                                                    gateway["status"] = e.target.checked;
                                                    handleSwitchChange(e.target.checked)}
                                                }
                                            />
                                            <div>{status?'Active': 'Inactive'}</div>
                                        </>
                                    ):(
                                        <InputText 
                                            className={"feildLabel"}
                                            disabled
                                            value={"For Approval"}
                                        />
                                    )}   
                                </div>
                            }
                            valueClassName="bodyRowValue"
                            rowClassName="rowMargin"
                        />
                    </Container>
                </Card.Text>
            </Card.Body>
        </Card>
    )
}

export default ViewGatewayDetails;
