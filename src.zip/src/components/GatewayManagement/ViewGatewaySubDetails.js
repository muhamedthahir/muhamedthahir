import React from 'react';
import { Card } from 'react-bootstrap';
import ViewDetailsGatewaySettings from './ViewDetailsGatewaySettings';
import ViewDetailsGatewayProviders from './ViewDetailsGatewayProviders';
import AuthorizeComponent from '../Global/Authorize/AuthorizeComponent';

function ViewGatewaySubDetails(props){
    const {
        gatewaySettingsList, gatewayProviderList, code, gatewayId,
        maximumNoOfAllowablegwSettings, setToastData, maximumNoOfAllowablegwProvider,
        isView
    } = props;
    return(
        <div>
            <Card>
                <Card.Body>
                    <AuthorizeComponent
                        Component={
                            (cprops) => <ViewDetailsGatewaySettings  
                                gatewayId={gatewayId} 
                                code={code} 
                                gatewaySettingsList={gatewaySettingsList} 
                                maximumNoOfAllowablegwSettings={maximumNoOfAllowablegwSettings}
                                setToastData={setToastData}
                                isView={isView}
                                {...cprops} 
                            />
                        }
                        needLayout={false}
                        type="ViewList"
                        module="GateSet"
                    />
                </Card.Body>
            </Card>
            <Card className="mt16">
                <Card.Body>
                    <AuthorizeComponent
                        Component={
                            (cprops) =>  <ViewDetailsGatewayProviders 
                                code={code} 
                                gatewayId={gatewayId} 
                                gatewayProviderList={gatewayProviderList} 
                                maximumNoOfAllowablegwProvider={maximumNoOfAllowablegwProvider}
                                setToastData={setToastData}
                                isView={isView}
                                {...cprops} 
                            />
                        }
                        needLayout={false}
                        type="ViewList"
                        module="GatePro"
                    />
                   
                </Card.Body>
            </Card>
        </div>
    )
}

export default ViewGatewaySubDetails;
