import React from 'react';
import { Card } from 'react-bootstrap';
import ViewDetailsGatewaySettings from './ViewDetailsGatewaySettings';
import ViewDetailsGatewayProviders from './ViewDetailsGatewayProviders';
import AuthorizeComponent from '../../components/Global/Authorize/AuthorizeComponent';

function ViewGatewaySubDetails(props){
    const {
        gatewaySettingsList, gatewayProviderList, code, gatewayId,
        maximumNoOfAllowablegwSettings, setToastData, maximumNoOfAllowablegwProvider,
        isView
    } = props;
    return(
        <div>
            <Card>
                <Card.Body>
                    <AuthorizeComponent
                        Component={(cprops) => <ViewDetailsGatewaySettings  
                                gatewayId={gatewayId} 
                                code={code} 
                                gatewaySettingsList={gatewaySettingsList} 
                                maximumNoOfAllowablegwSettings={maximumNoOfAllowablegwSettings}
                                setToastData={setToastData}
                                isView={isView}
                                {...cprops}  />}
                        type="list"
                        module="gatewaySetting"
                    />
                </Card.Body>
            </Card>
            <Card className="mt16">
                <Card.Body>
                    <ViewDetailsGatewayProviders 
                        code={code} 
                        gatewayId={gatewayId} 
                        gatewayProviderList={gatewayProviderList} 
                        maximumNoOfAllowablegwProvider={maximumNoOfAllowablegwProvider}
                        setToastData={setToastData}
                        isView={isView}
                    />
                </Card.Body>
            </Card>
        </div>
    )
}

export default ViewGatewaySubDetails;
