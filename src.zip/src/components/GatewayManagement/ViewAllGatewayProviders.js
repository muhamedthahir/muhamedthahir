/* eslint-disable react-hooks/exhaustive-deps */
import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from "react-redux";
import {
    Card, Row, Col,
    Image, Spinner
} from 'react-bootstrap';
import { Link } from 'react-router-dom';
import SearchBar from '../Global/SearchBar/SearchBar';
import DataTable from '../Global/DataTable/DataTable';
import EditIcon from '../../assets/icons/icon-edit-filled.svg';
import Switch from '../Global/Switch/Switch';
import { retrieveAllGatewayProvider }  from '../../actions/gatewaymanagement';
import './styles/viewAllGatewayType.scss';

const editIcon = (<Image src={EditIcon} className="icon"/>);

const alphaNumericSorting = (frstValue, scndValue, colId, desc=false) => {
    if( frstValue && scndValue ){
        if( !desc ) return frstValue.localeCompare(scndValue)
        return (-1 *(scndValue.localeCompare(frstValue)))
    }
}
const sortByElement = ( rowA, rowB, colId, desc) => {
    const findFn = ( entry ) => entry.column && (entry.column.id ===  colId)
    const foundAData = rowA.cells.find(findFn);
    const foundBData = rowB.cells.find(findFn);
    const aValue =  typeof rowA.cells[0] !== "function" && foundAData && foundAData.value.props.children;
    const bValue =  typeof rowB.cells[0] !== "function" && foundBData && foundBData.value.props.children;
    return alphaNumericSorting( aValue, bValue, colId, desc)
}
const statusDiv = (rowData) => {
    const { status } = rowData;
    let className = "forApproval";
    let text = "For Approval";
    if (status === "active" || status === "inactive") {
      className = "status" + status;
      text = status[0].toUpperCase() + status.substring(1, status.length);
    }
    return <div className={className}>{text}</div>;
};

const actionDiv = (ele) => {
    let isedit =false;
    if( ele.status === "active") isedit = true;
    return (
        (ele.status ==="active" || ele.status ==="inactive")
            ? (<div className="actionDiv" key={`action_${ele.code}`}>
                <Switch
                    type="switch"
                    id={`custom-switch-${ele.code}`}
                    defaultChecked={ele.status === 'active'}
                    // onChange={(e) => handleStatusChange(e.target.checked, ele.code)}
                />
                 { isedit && <div className="editDiv">{editIcon}</div>}
            </div>
    ): '')
}
function ViewAllGatewayProvider(props) {
    const dispatch = useDispatch();
    const retData = useSelector( state => state.gatewayReducer);
    const { viewAllGatewayProvider=[] }  = retData;
    let  { data }= viewAllGatewayProvider;
    useEffect(() => {
        dispatch(retrieveAllGatewayProvider());           
    }, []);
    let [ localData=data, setData] = useState();
    const categoryList = [
        {'key': 'Provider Code', 'value': 'code'},
        {'key': 'Provider Name', 'value': 'name'},
        {'key': 'Provider Switch', 'value': 'switch'},
        {'key': 'Status', 'value': 'status'},
    ];
    const columns = [
        {
            Header: 'Provider Code',
            accessor: 'code',
            selector: 'code',
            sortType: 'basic',
        },
        {
            Header: 'Provider Name',
            accessor: 'name',
            
        },
        {
            Header: 'Provider Switch',
            accessor: 'switch'
        },
        {
            Header: 'Status',
            accessor: 'status',
            sortType: ( rowA, rowB, colId, desc ) => {
                return sortByElement(rowA, rowB, colId, desc)
            }
        },
        {
            Header: 'Action',
            accessor: 'action',
            disableSortBy: true
        }
    ];
    const  handleClick = ( category, ipText ) => { 
        const condtnFn = (ele) => ele[(category)] !== undefined && ele[(category)].toLowerCase().includes(ipText)
        const categoryFilterdData = [ ...data ].filter(condtnFn);
        setData(categoryFilterdData);
    }
    
    const linkDiv = (rowData) => <Link to={`/gatewaymanagment/gatewayProviders/${rowData.code}`}>{rowData.name}</Link>;
    localData = localData && localData.map((ele) => {
        return {
            ...ele, name: linkDiv(ele), status: statusDiv(ele), action: actionDiv(ele)
        }
    });
    return(
        <div className="gateWayTypeManagement">
            <div className="headerBlock">
                <div>
                    <b>Manage Gateway</b>
                </div>
            </div>
            <Card>
                <Card.Body>
                    <div className="searchCard">
                        <Row className="mb10">
                            <Col sm={8}>
                                <b className="ml10">Search Gateway Provider</b>
                            </Col>
                        </Row>
                        <div className="formBlock">
                            <SearchBar categoryList={categoryList} textPlaceHolder="Enter Settings" handleClick={handleClick}/>
                        </div>  
                    </div>
                </Card.Body>
            </Card>
            <div className="tableBlock">
                <Card>
                    <Card.Body>
                        <h6 className="header6">Gateway Provider</h6>
                        <div className="dataBlock">
                            {
                                localData !== undefined
                                ?  (
                                <DataTable 
                                    columns={columns}
                                    data={localData}
                                    showPagination={true}
                                />):(
                                    <div className="alignCenter">
                                        <Spinner animation="border" />
                                    </div>
                                )
                            }
                        </div>
                    </Card.Body>
                </Card>
            </div>

        </div>
    )
}
export default ViewAllGatewayProvider;
