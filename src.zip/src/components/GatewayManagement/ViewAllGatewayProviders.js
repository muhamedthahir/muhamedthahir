/* eslint-disable react-hooks/exhaustive-deps */
import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Card, Row, Col, Button, Image, Spinner } from "react-bootstrap";
import { useHistory, Link } from "react-router-dom";
import SearchBar from "../Global/SearchBar/SearchBar";
import BDOToast from "../Global/BDOToast/BDOToast";
import DataTable from "../Global/DataTable/DataTable";
import EditIcon from "../../assets/icons/icon-edit-outline.svg";
import Switch from "../Global/Switch/Switch";
import {
  retrieveAllGatewayProviderNew,
  retrieveAllFindGatewayProviderNew,
} from "../../actions/gatewaymanagement";
import "./styles/viewAllGatewayType.scss";

const editIcon = (rowData, toggle, totalElements) => (
  <Image
    onClick={() => toggle("EDIT", rowData, totalElements)}
    src={EditIcon}
    className="icon pointer"
  />
);

const statusDiv = (rowData) => {
  let { status, forApproval } = rowData;
  let className = "forApproval";
  let text = "For Approval";
  if (!forApproval) {
    className = `status${status ? "active" : "inactive"}`;
    text = status ? "Active" : "Inactive";
  }
  return <div className={className}>{text}</div>;
};
const alphaNumericSorting = (frstValue, scndValue, colId, desc = false) => {
  if (frstValue && scndValue) {
    if (!desc) return frstValue.localeCompare(scndValue);
    return -1 * scndValue.localeCompare(frstValue);
  }
};
const sortByElement = (rowA, rowB, colId, desc) => {
  const findFn = (entry) => entry.column && entry.column.id === colId;
  const foundAData = rowA.cells.find(findFn);
  const foundBData = rowB.cells.find(findFn);
  const aValue =
    typeof rowA.cells[0] !== "function" &&
    foundAData &&
    foundAData.value.props.children;
  const bValue =
    typeof rowB.cells[0] !== "function" &&
    foundBData &&
    foundBData.value.props.children;
  return alphaNumericSorting(aValue, bValue, colId, desc);
};
function ViewAllGatewayProvider(props) {
  const dispatch = useDispatch();
  const retData = useSelector((state) => state.gatewayReducer);
  const { viewAllGatewayProvider = [] } = retData;
  let {
    data,
    totalPages = 1,
    totalElements,
    errorResponse,
  } = viewAllGatewayProvider;
  const [isPageChanged, movePage] = useState(false);
  const [toastData, setToastData] = useState({});
  const history = useHistory();
  useEffect(() => {
    dispatch(retrieveAllGatewayProviderNew(`pageNumber=${1}&pageSize=${10}`));
    const {
      history: {
        location: { state = {} },
      },
    } = props;
    const {
      toastState = false,
      toastMessage = "",
      toastType = "success",
    } = state && (state.toastData || {});
    if (toastState) {
      setToastData({ toastState, toastMessage, toastType });
      window.scrollTo({
        top: 0,
        left: 0,
        behavior: "smooth",
      });
    }
  }, []);
  let [localData = data] = useState();
  let errorDiv = "";
  if (errorResponse) {
    errorDiv = (
      <span>
        {errorResponse.ccmErrorCode} - {errorResponse.errorDescription}
      </span>
    );
  }
  let toggle = (toggleaction, datatochild, totalEle) => {
    if (toggleaction === "ADD") {
      history.push({
        pathname: `/gatewaymanagment/gatewayProviders/ADD`,
        state: { toggleaction, datatochild },
      });
    } else if (toggleaction !== "ADD") {
      history.push({
        pathname: `/gatewaymanagment/gatewayProviders/${datatochild.code}`,
        state: { toggleaction, totalElements: totalEle },
      });
    }
  };
  const categoryList = [
    { label: "Provider Code", value: "providerCode" },
    { label: "Provider Name", value: "providerName" },
  ];
  const columns = [
    {
      Header: "Provider Code",
      accessor: "code",
      selector: "code",
      sortType: "basic",
    },
    {
      Header: "Provider Name",
      accessor: "name",
    },
    // {
    //     Header: 'Provider Description',
    //     accessor: 'description'
    // },
    {
      Header: "Status",
      accessor: "status",
      sortType: (rowA, rowB, colId, desc) => {
        return sortByElement(rowA, rowB, colId, desc);
      },
      className: "centerMode",
    },
    {
      Header: "Actions",
      accessor: "action",
      disableSortBy: true,
    },
  ];
  const handleClick = (category, ipText) => {
    movePage(true);
    dispatch(
      retrieveAllFindGatewayProviderNew(
        `searchText=${ipText}&searchType=${category}&pageNumber=${1}&pageSize=${10}`
      )
    );
  };
  const linkDiv = (rowData) => (
    <Link
      to={{
        pathname: `/gatewaymanagment/gatewayProviders/${rowData.code}`,
        state: { action: "view", totalElements: totalElements },
      }}
    >
      {rowData.name}
    </Link>
  );
  const actionDiv = (ele) => {
    let status = ele.status;
    let isedit = false;
    if (status === true) isedit = true;
    return !ele.forApproval ? (
      <div className="actionDiv" key={`action_${ele.code}`}>
        <Switch
          type="switch"
          id={`custom-switch-${ele.code}`}
          defaultChecked={status}
          // onChange={(e) => handleStatusChange(e.target.checked, ele.gatewayCode)}
        />
        {isedit && (
          <div className="editDiv">{editIcon(ele, toggle, totalElements)}</div>
        )}
      </div>
    ) : (
      ""
    );
  };
  localData =
    localData &&
    localData.map((ele) => {
      return {
        ...ele,
        name: linkDiv(ele),
        status: statusDiv(ele),
        action: actionDiv(ele),
      };
    });
  const handleServerSidePagination = (pageNo, pageSize) => {
    dispatch(
      retrieveAllGatewayProviderNew(`pageNumber=${pageNo}&pageSize=${pageSize}`)
    );
  };
  return (
    <div className="gateWayTypeManagement">
      <div className="headerBlock">
        <div>
          <b>Manage Provider</b>
        </div>
        <div className="buttonBlock">
          <Button variant="primary" onClick={(e) => toggle("ADD")}>
            Add Provider{" "}
          </Button>
        </div>
      </div>
      {toastData.toastState && (
        <BDOToast
          openState={toastData.toastState}
          type={toastData.toastType}
          bodyMessage={toastData.toastMessage}
          onClose={() => {
            setToastData({});
            if (history.location.state && history.location.state.toastData) {
              let state = { ...history.location.state };
              delete state.toastData;
              history.replace({ ...history.location, state });
            }
          }}
        />
      )}
      <Card>
        <Card.Body>
          <div className="searchCard">
            <Row className="mb10">
              <Col sm={8}>
                <b className="ml10">Search Gateway Provider</b>
              </Col>
            </Row>
            <div className="formBlock">
              <SearchBar
                categoryList={categoryList}
                textPlaceHolder="Input Keyword"
                handleClick={handleClick}
              />
            </div>
          </div>
        </Card.Body>
      </Card>
      <div className="tableBlock">
        <Card>
          <Card.Body>
            <h6 className="header6">Gateway Provider</h6>
            <div className="dataBlock">
              {localData !== undefined || errorResponse ? (
                <DataTable
                  columns={columns}
                  data={localData || []}
                  showPagination={true}
                  handleServerSidePagination={handleServerSidePagination}
                  errorDiv={errorDiv}
                  pageProperty={{
                    totalPages,
                    isPageChanged,
                    movePage: (val) => movePage(val),
                  }}
                />
              ) : (
                <div className="alignCenter">
                  <Spinner animation="border" />
                </div>
              )}
            </div>
          </Card.Body>
        </Card>
      </div>
    </div>
  );
}
export default ViewAllGatewayProvider;
