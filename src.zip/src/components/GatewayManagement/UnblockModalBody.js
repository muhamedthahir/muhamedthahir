import React from 'react';
import InputText from '../Global/Input/InputText';
import { Form } from 'react-bootstrap';
import { Formik } from 'formik';
import * as Yup from 'yup';
import './styles/viewAllChannal.scss';

const validationSchema = Yup.object().shape({
	reason: Yup.string().required('Required field'),
});

const UnblockModalBody = (props) => {
	const { modalData, handleOnChangeStatus, formIkRef } = props;
	return (
		<div>
			<div className="leftAlign">
				Unblock this channel?
			</div>
			<div className="bdyRow">
				<b> {modalData.code} </b>
			</div>
			<div className="bdyRow">
				<span>Sender : </span>
				<span>{modalData.sender}</span>
			</div>
			<div className="bdyRow">
				<span>Gateway type : </span>
				<span>{modalData.gateway_type}</span>
			</div>
			<div className="bdyRow reasonBlock">
				<Formik
					initialValues={{'reason':'', channelCode: modalData.code, gatewayCode: modalData.gateway_type}}
					validationSchema={validationSchema}
					innerRef={formIkRef}
					onSubmit={(values) => handleOnChangeStatus(values)}
				>
					{({ 
                errors, touched, values, handleSubmit, handleChange,
            }) => (
                    <Form onSubmit={handleSubmit}>
                        <InputText  
                            value={modalData.reason} 
                            onChange={handleChange}
							className={errors.reason && touched.reason?'err-feild':''}
                            placeholder="Please Provide Reason"
                            name="reason"
                        />
                        {
                            errors.reason && touched.reason
                            ?(
                                <div className="alignLeft"> 
                                    <span className="err-feild">
                                        {errors.reason}
                                    </span>
                                </div>
                            ): ''
                        }
                    </Form>
                )}
            </Formik>
        </div>
    </div>
	)
};

export default UnblockModalBody;
