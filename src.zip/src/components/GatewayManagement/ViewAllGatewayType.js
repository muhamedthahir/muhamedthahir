/* eslint-disable react-hooks/exhaustive-deps */
import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from "react-redux";
import {
    Card, Row, Col,
    Image, Spinner
} from 'react-bootstrap';
import { Link , useHistory} from 'react-router-dom';
import SearchBar from '../Global/SearchBar/SearchBar';
import DataTable from '../Global/DataTable/DataTable';
import EditIcon from '../../assets/icons/icon-edit-outline.svg';
import BDOButton from '../Global/Button/BDOButton';
import BDOToast from '../Global/BDOToast/BDOToast';
import BDOModal from '../Global/BDOModal/BDOModal';
import Switch from '../Global/Switch/Switch';
import GatewayModalBody from './GatewayModalBody';
import { 
    retrieveAllGatewayType, retrieveGatewayRecord,
    addOrUpdateGateway
}  from '../../actions/gatewaymanagement';
import { findNextMaxNo } from '../../utils/DataTableUtil';
import './styles/viewAllGatewayType.scss';
import { useMsal  } from "@azure/msal-react";

const editIcon =(rowData , history)=> (
    <Image
        onClick={() =>  history.push({
            pathname: `/gatewaymanagment/${rowData.code}`,
            state: { storage: "local" },
          })} 
        src={EditIcon} 
        className="icon pointer"
    />
);

const actionDiv = ( ele, handleStatusChange ,history , accessMap ) => {
    let status = ele.status;
    let isedit = false;
    if( accessMap?.canUpdate && status === true ) isedit = true;
    return (
        (!ele.forApproval)
            ? (
                <div className="actionDiv">
                    {(accessMap.canEnable || accessMap.canDisable) && (
                        <div 
                            onClick={(e) => handleStatusChange(e, ele)}
                        >
                            <Switch
                                type="switch"
                                id={`custom-switch-${ele.code}`}
                                checked={ele.status}
                            />
                        </div>
                    )}
                    { isedit && <div className="editDiv">{editIcon(ele , history)}</div>}
                </div>
        ): '')
}


const alphaNumericSorting = (frstValue, scndValue, colId, desc=false) => {
    if( frstValue && scndValue ){
        if( !desc ) return frstValue.localeCompare(scndValue)
        return (-1 *(scndValue.localeCompare(frstValue)))
    }
}

const statusDiv = (rowData) => {
    let { status , forApproval} = rowData;
    let className = 'forApproval';
    let text = 'For Approval';
    if( !forApproval) {
        className = `status${status?'active':'inactive'}`;
        text= status?'Active':'Inactive'
    }
    return ( <div className={className}>{text}</div>)
};

const sortByElement = ( rowA, rowB, colId, desc) => {
    const findFn = ( entry ) => entry.column && (entry.column.id ===  colId)
    const foundAData = rowA.cells.find(findFn);
    const foundBData = rowB.cells.find(findFn);
    const aValue =  typeof rowA.cells[0] !== "function" && foundAData && foundAData.value.props.children;
    const bValue =  typeof rowB.cells[0] !== "function" && foundBData && foundBData.value.props.children;
    return alphaNumericSorting( aValue, bValue, colId, desc)
}

function ViewAllGatewayType(props) { 
    const history = useHistory();
    const { 
        canCreate, canDisable, canEnable,
        canUpdate, canViewRecord
    } = props;
    const dispatch = useDispatch();
    const retData = useSelector( state => state.gatewayReducer);
    let { viewAllGatewayType=[] , viewGateway={}}  = retData;
    let selData = viewGateway.data;
    // totalElements = pageSize
    const { 
        data , totalPages=1, currentPageNumber =1, errorResponse,
        totalElements = 10
    } = viewAllGatewayType;
    const [ isPageChanged, movePage ] = useState(false)
    const [ toastData, setToastData] = useState({});
    const [ modalData, setModalData] = useState({});
    const [ , setSelData] = useState()
    const { instance } = useMsal();
    const accounts = instance.getAllAccounts();
    const accountUserId = (accounts && accounts[0]?.localAccountId) || "us-02";
    let errorDiv = '';
    if( errorResponse) {
        errorDiv = (
        <span>{errorResponse.ccmErrorCode} - {errorResponse.errorDescription}</span>
        )
    }
    useEffect(() => {
        dispatch(retrieveAllGatewayType(`page=${1}&size=${10}`));         
        const {
            history : { 
            location: { 
            state ={}
        }}} = props;  
        const {
            toastState= false, toastMessage ='', toastType = 'success'
        } = (state && state.toastData) || {};
        if(toastState) {
            setToastData({ toastState , toastMessage , toastType})
            window.scrollTo({
                top: 0,
                left:0,
                behavior: "smooth"
            });
        }
    }, []);
    let [ localData=data,] = useState();
    const categoryList = [
        { 'label': 'Gateway Code', 'value': 'code' },
        { 'label': 'Gateway Name', 'value': 'name' },
        { 'label': 'Description', 'value': 'description' }
    ];
    let columns = [
        {
            Header: 'Gateway Code',
            accessor: 'code',
            selector: 'code',
            sortType: 'basic',
        },
        {
            Header: 'Gateway Name',
            accessor: 'name',
            sortType: ( rowA, rowB, colId, desc ) => {
                return sortByElement(rowA, rowB, colId, desc)
            }
        },
        {
            Header: 'Description',
            accessor: 'description',
        },
        {
            Header: 'Status',
            accessor: 'status',
            sortType:( rowA, rowB, colId, desc ) => {
                return sortByElement(rowA, rowB, colId, desc)
            }
        },
        {
            Header: 'Actions',
            accessor: 'actions',
            disableSortBy: true,
        }
    ];
    let toggle = (toggleaction , datatochild) => {
        history.push({pathname: '/gatewaymanagment/add', state: {toggleaction , datatochild}})
    };
    const  handleClick = ( category, ipText ) => {
        movePage(true)
    }
    const handleServerSidePagination = (pageNo, pageSize) => {
        dispatch(retrieveAllGatewayType(`page=${pageNo}&size=${pageSize}`));
    };
    const linkDiv = (rowData, access) => (
        access ? (
            <Link  to={{
                pathname: `/gatewaymanagment/${rowData.code}`,
                state: { action: 'view'}
            }}>
                {rowData.name}
            </Link>
        ): (
            <span>{rowData.name}</span>
        )
    )
    const handleStatusChange = ( event, value ) => {
        event.stopPropagation();
        if( event.target.checked ) {
            dispatch(retrieveGatewayRecord(value.code))
            setModalData({
                modalState: true,
                gatewayCode: value.code,
                gatewayName: value.name,
                providerList: selData?.gatewayProviderList || [],
                value: value
            })
        }
        
    }
    const closeModal = () => {
        setModalData({})
        setSelData({})
    }
    
    const constructErrMsg = ( respData, ele, index ) => {
        let msg = '';
        msg += `${ele} : ${respData.data.errorList[ele]}`
        if( Object.values(respData.data.errorList).length -1 !== index){
            msg +=","
        } else {
            msg += "."
        }
        return msg;
    }
    const onSubmitHandler = ( resValues) => {
        resValues.gatewayTypeDetails.status = true;
        resValues.gatewayTypeDetails.forApproval = true;
        dispatch(addOrUpdateGateway(
            resValues,
            accountUserId,
            modalData.value.code,
            (respData) => {
                const { referenceId } = (respData?.data || {});
                if( respData.data.ccmErrorCode && respData.data.errorDescription && !respData.data.errorList ) {
                    closeModal()
                    setToastData({ 
                        toastState: true, 
                        toastMessage: `${respData.data.ccmErrorCode} - ${respData.data.errorDescription}`, 
                        toastType: "warning"
                    });
                    window.scrollTo({
                        top: 0,
                        left:0,
                        behavior: "smooth"
                    });
                }
                else if( respData.data && respData.data.errorList && Object.values(respData.data.errorList).length> 0) {
                    closeModal()
                    let msg = '';
                    
                    if( respData.data.errorList && Object.values(respData.data.errorList).length > 0) {
                        Object.keys(respData.data.errorList).forEach((ele, index) => {
                            msg = constructErrMsg( respData, ele, index )
                        })
                    }
                    setToastData({ toastState: true, toastMessage: msg, referenceId, toastType: "warning"});
                    window.scrollTo({
                        top: 0,
                        left:0,
                        behavior: "smooth"
                    });
                } else {
                    setToastData({ toastState: true, toastMessage: `Gateway request submitted for approval . Reference number ${referenceId}`, toastType: "success"});
                    dispatch(retrieveAllGatewayType(`page=${currentPageNumber}&size=${findNextMaxNo(totalElements)}`))
                    closeModal();
                    window.scrollTo({
                        top: 0,
                        left:0,
                        behavior: "smooth"
                    });
                }
            }
        ))
    }
    const localObj = localData && localData.map((ele) => {
            return {
                ...ele,
                name: linkDiv(ele, canViewRecord), 
                status: statusDiv(ele),
                actions: actionDiv(ele, handleStatusChange , history, { canEnable, canDisable, canUpdate}),
            }
        });
    return(
        <div className="gateWayTypeManagement">
            <div className="headerBlock">
                <div>
                    <b>Manage Gateway</b>
                </div>
                <div className="buttonBlock">
                { canCreate && ( <BDOButton title="Add Gateway" onClick={(e) => toggle('ADD')} style1="style1" />)}
                </div>
            </div>
            {
                toastData.toastState && (
                    <BDOToast 
                        openState={toastData.toastState}
                        type={toastData.toastType}
                        bodyMessage={toastData.toastMessage}
                        onClose={() => {
                            setToastData({})
                            if (history.location.state && history.location.state.toastData) {
                                let state = { ...history.location.state };
                                delete state.toastData;
                                history.replace({ ...history.location, state });
                            }
                        }} 
                    />
                )
            }
            {
                modalData.modalState && (
                    <BDOModal
                        header={"Reactivate Gateway"}
                        body={
                            <GatewayModalBody
                                bodyData={modalData}
                                selData={selData}
                                onSubmitHandler={onSubmitHandler}
                                closeModal={closeModal}
                            />
                        }
                        openState={modalData.modalState}
                        modalProps={{onHide: closeModal , className: "gatewayEnableModal"}}
                    />
                )
            }
            <Card className="searchBlock">
                <Card.Body>
                    <div className="searchCard">
                        <Row className="mb10">
                            <Col sm={8}>
                                <b className="ml10">Search Gateway</b>
                            </Col>
                        </Row>
                        <div className="formBlock">
                            <SearchBar categoryList={categoryList} textPlaceHolder="Input Keyword" handleClick={handleClick}/>
                        </div>  
                    </div>
                </Card.Body>
            </Card>
            <div className="tableBlock">
                <Card>
                    <Card.Body>
                        <div  className="mb10">
                            <b className="header6">Gateways</b>
                        </div>
                        <div className="dataBlock">
                            {
                                (localObj !== undefined || errorResponse)
                                ?  (
                                <DataTable 
                                    columns={columns}
                                    data={localObj || []}
                                    showPagination={true}
                                    handleServerSidePagination={handleServerSidePagination}
                                    errorDiv={errorDiv}
                                    pageProperty={{ totalPages, isPageChanged, movePage: (val) => movePage(val) }}
                                />):(
                                    <div className="alignCenter">
                                        <Spinner animation="border" />
                                    </div>
                                )
                            }
                        </div>
                    </Card.Body>
                </Card>
            </div>

        </div>
    )
}
export default ViewAllGatewayType;
