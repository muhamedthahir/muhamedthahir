/* eslint-disable react-hooks/exhaustive-deps */
import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from "react-redux";
import {
    Card, Row, Col,
    Image, Spinner
} from 'react-bootstrap';
import { Link , useHistory} from 'react-router-dom';
import SearchBar from '../Global/SearchBar/SearchBar';
import DataTable from '../Global/DataTable/DataTable';
import EditIcon from '../../assets/icons/icon-edit-outline.svg';
import BDOButton from '../Global/Button/BDOButton';
import BDOToast from '../Global/BDOToast/BDOToast';
import Switch from '../Global/Switch/Switch';
import { retrieveAllGatewayType }  from '../../actions/gatewaymanagement';
import './styles/viewAllGatewayType.scss';
    

const editIcon =(rowData , history)=> (
    <Image
        onClick={() =>  history.push({
            pathname: `/gatewaymanagment/${rowData.gatewayCode}`,
            state: { storage: "local" },
          })} 
        src={EditIcon} 
        className="icon pointer"
    />
);

const actionDiv = ( ele, handleStatusChange ,history ) => {
    let status = ele.status;
    let isedit =false;
    if( status === "active") isedit = true;
    return (
        (status ==="active" || status ==="inactive")
            ? (<div className="actionDiv" key={`action_${ele.code}`}>
                <Switch
                    type="switch"
                    id={`custom-switch-${ele.gatewayCode}`}
                    defaultChecked={status === 'active'}
                    onChange={(e) => handleStatusChange(e.target.checked, ele.gatewayCode)}
                />
                { isedit && <div className="editDiv">{editIcon(ele , history)}</div>}
            </div>
        ): '')
}


const alphaNumericSorting = (frstValue, scndValue, colId, desc=false) => {
    if( frstValue && scndValue ){
        if( !desc ) return frstValue.localeCompare(scndValue)
        return (-1 *(scndValue.localeCompare(frstValue)))
    }
}

const statusDiv = (rowData) => {
    let { status } = rowData;
    let className = 'forApproval';
    let text = 'For Approval';
    if( status === "active" || status === "inactive") {
        className = "status"+status;
        text= status[0].toUpperCase() + status.substring(1, status.length)
    }
    return ( <div className={className}>{text}</div>)
};

const sortByElement = ( rowA, rowB, colId, desc) => {
    const findFn = ( entry ) => entry.column && (entry.column.id ===  colId)
    const foundAData = rowA.cells.find(findFn);
    const foundBData = rowB.cells.find(findFn);
    const aValue =  typeof rowA.cells[0] !== "function" && foundAData && foundAData.value.props.children;
    const bValue =  typeof rowB.cells[0] !== "function" && foundBData && foundBData.value.props.children;
    return alphaNumericSorting( aValue, bValue, colId, desc)
}

function ViewAllGatewayType(props) { 
    const history = useHistory();
    const { isupdate, iscreate } = props;
    const dispatch = useDispatch();
    const retData = useSelector( state => state.gatewayReducer);
    let { viewAllGatewayType=[] }  = retData;
    const { data , totalPages=1, errorResponse} = viewAllGatewayType;
    const [ isPageChanged, movePage ] = useState(false)
    const [ toastData, setToastData] = useState({});
    let errorDiv = '';
    if( errorResponse) {
        errorDiv = (
        <span>{errorResponse.errorDescription}</span>
        )
    }
    useEffect(() => {
        dispatch(retrieveAllGatewayType(`page=${1}&size=${10}`));         
        const {
            history : { 
            location: { 
            state ={}
        }}} = props;  
        const {
            toastState= false, toastMessage ='', toastType = 'success'
        } = (state.toastData || {});
        if(toastState) {
            setToastData({ toastState , toastMessage , toastType})
            window.scrollTo({
                top: 0,
                left:0,
                behavior: "smooth"
            });
        }
    }, []);
    let [ localData=data, setData] = useState();
    const categoryList = [
        {'key': 'Gateway Code', 'value': 'code'},
        {'key': 'Gateway Name', 'value': 'name'},
        {'key': 'Gateway Description', 'value': 'description'}
    ];

    let columns = [
        {
            Header: 'Gateway Code',
            accessor: 'gatewayCode',
            selector: 'code',
            sortType: 'basic',
        },
        {
            Header: 'Gateway Name',
            accessor: 'name',
            sortType: ( rowA, rowB, colId, desc ) => {
                return sortByElement(rowA, rowB, colId, desc)
            }
        },
        {
            Header: 'Description',
            accessor: 'description',
        },
        {
            Header: 'Status',
            accessor: 'status',
            sortType:( rowA, rowB, colId, desc ) => {
                return sortByElement(rowA, rowB, colId, desc)
            }
        }
    ];
    if( isupdate ) {
        columns = [ 
            ...columns,  {
            Header: 'Actions',
            accessor: 'actions',
            disableSortBy: true,
            }
        ];
    }

    let toggle = (toggleaction , datatochild) => {
        history.push({pathname: '/gatewaymanagment/add', state: {toggleaction , datatochild}})
    };
    const  handleClick = ( category, ipText ) => {
        movePage(true)
    }
    const handleServerSidePagination = (pageNo, pageSize) => {
        dispatch(retrieveAllGatewayType(`page=${pageNo}&size=${pageSize}`));
    };
    const linkDiv = (rowData) => <Link  to={{
            pathname: `/gatewaymanagment/${rowData.gatewayCode}`,
            state: { action: 'view'}
        }}>{rowData.name}</Link>;
    const handleStatusChange = ( value, code ) => {
        const finder = data.find(( ele ) => ele.gatewayCode === code);
        finder["status"] = value?"active": "inactive";
        setData([...data]);
    }
    
    const localObj = localData && localData.map((ele) => {
            return {
                ...ele,
                name: linkDiv(ele), 
                status: statusDiv(ele),
                actions: actionDiv(ele, handleStatusChange , history),
            }
        });
    return(
        <div className="gateWayTypeManagement">
            <div className="headerBlock">
                <div>
                    <b>Manage Gateway</b>
                </div>
                <div className="buttonBlock">
                { iscreate && ( <BDOButton title="Add Gateway" onClick={(e) => toggle('ADD')} style1="style1" />)}
                </div>
            </div>
            {
                toastData.toastState && (
                    <BDOToast 
                        openState={toastData.toastState}
                        type={toastData.toastType}
                        bodyMessage={toastData.toastMessage}
                        onClose={() => {
                            setToastData({})
                            if (history.location.state && history.location.state.toastData) {
                                let state = { ...history.location.state };
                                delete state.toastData;
                                history.replace({ ...history.location, state });
                            }
                        }} 
                    />
                )
            }
            <Card className="searchBlock">
                <Card.Body>
                    <div className="searchCard">
                        <Row className="mb10">
                            <Col sm={8}>
                                <b className="ml10">Search Gateway</b>
                            </Col>
                        </Row>
                        <div className="formBlock">
                            <SearchBar categoryList={categoryList} textPlaceHolder="Input Keyword" handleClick={handleClick}/>
                        </div>  
                    </div>
                </Card.Body>
            </Card>
            <div className="tableBlock">
                <Card>
                    <Card.Body>
                        <div  className="mb10">
                            <b className="header6">Gateways</b>
                        </div>
                        <div className="dataBlock">
                            {
                                (localObj !== undefined || errorResponse)
                                ?  (
                                <DataTable 
                                    columns={columns}
                                    data={localObj || []}
                                    showPagination={true}
                                    handleServerSidePagination={handleServerSidePagination}
                                    errorDiv={errorDiv}
                                    pageProperty={{ totalPages, isPageChanged, movePage: (val) => movePage(val) }}
                                />):(
                                    <div className="alignCenter">
                                        <Spinner animation="border" />
                                    </div>
                                )
                            }
                        </div>
                    </Card.Body>
                </Card>
            </div>

        </div>
    )
}
export default ViewAllGatewayType;
