import React from 'react';
import {
    Spinner
} from 'react-bootstrap';
import SearchBar from '../Global/SearchBar/SearchBar';
import DataTable from '../Global/DataTable/DataTable';
import './styles/viewAllGatewayType.scss';

function ChannelList(props) { 
    const { 
        data, col, handleClick, totalPages,
        handleServerSidePagination, errorResponse,
        currentPageNumber, movePage, isPageChanged, errorDiv
    } = props;
    return(
        <div className="ChannelInformation">
            <b>Channel Information</b>
            <div className="searchBlock mt15">
                <div className="searchCard">
                    <div className="formBlock">
                        <SearchBar labelText="Search Channel" textPlaceHolder="Input channel code" handleClick={handleClick}/>
                    </div>  
                </div>
            </div>
            <div className="tableBlock">
                <div className="dataBlock">
                    {
                        (data !== undefined || errorResponse !== undefined)
                        ?  (
                        <DataTable 
                            columns={col}
                            data={data || []}
                            showPagination={true}
                            handleServerSidePagination={handleServerSidePagination}
                            pageProperty={{ 
                                totalPages, 
                                pageNo: currentPageNumber,
                                isPageChanged, 
                                movePage: (val) => movePage(val)
                            }}
                            errorDiv={errorDiv}
                        />):(
                            <div className="alignCenter">
                                <Spinner animation="border" />
                            </div>
                        )
                    }
                </div>
            </div>

        </div>
    )
}
export default ChannelList;
