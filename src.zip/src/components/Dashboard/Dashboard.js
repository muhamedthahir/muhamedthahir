import React from 'react';
import  { Link } from 'react-router-dom';
import {
    Row,
    Col,
    Card, ListGroup,
} from 'react-bootstrap';
import './Dashboard.scss';
import warningIcon from "../../assets/icons/warning-outline.svg";
import blockedIcon from "../../assets/icons/Icon-blocked.svg";
import approvalIcon from "../../assets/icons/icon-checkbox-outline.svg";


function Dashboard(props) {
     return(
        <Row  className="mt-2 mr-2 ml-2 dashboard">
            <Col sm={4}>
              <Card>
                <Link to={"/approvalPage"} className="linkDiv">
                    <Card.Body>
                        <Card.Title>Transaction Overview</Card.Title>
                        <Card.Text className="card-body">
                            <span className="card-body-text">Pending Approvals</span>
                            <div className="cardBodyCls bg-approval"> <img src={approvalIcon} className="cardIconCls"></img></div>
                            <div className="card-body-number"><a href="/">6</a></div>
                        </Card.Text>
                    </Card.Body>
                </Link>
             </Card>
             <Card className="w-100 mt-3">
                <Link to={"/gatewaymanagment/channels"} className="linkDiv">
                    <Card.Body>
                        <Card.Title>Channel Summary</Card.Title>
                        <Card.Text className="card-body">
                            <span className="card-body-text">Blocked</span>
                            <div className="cardBodyCls bg-blocked"> <img src={blockedIcon} className="cardIconCls"></img></div>
                            <div className="card-body-number"><a href="/">2</a></div>
                        </Card.Text>
                        <Card.Text className="card-body">
                            <span className="card-body-text">Reached Threshold</span>
                            <div className="cardBodyCls bg-reached-threshold"> <img src={warningIcon} className="cardIconCls"></img></div>
                            <div className="card-body-number"><a href="/">4</a></div>
                        </Card.Text>
                    </Card.Body>
                </Link>
             </Card>
            </Col>
         
            <Col sm={8}>
            <Card className="w-100">
                <Card.Body>
                    <Card.Title>Announcement</Card.Title>
                        <ListGroup className="listGroupCls">
                            <ListGroup.Item className="listgroupItemCls"> 
                                    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer posuere
                                    erat a ante.
                                <div className="listItemCls">
                                Jan 21, 2021
                                </div>
                            </ListGroup.Item>
                            <ListGroup.Item className="listgroupItemCls"> 
                                    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer posuere
                                    erat a ante.
                                <div className="listItemCls">
                                Jan 21, 2021
                                </div>
                            </ListGroup.Item>
                            <ListGroup.Item className="listgroupItemCls"> 
                                    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer posuere
                                    erat a ante.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer posuere
                                    erat a ante.

                                <div className="listItemCls">
                                Jan 21, 2021
                                </div>
                            </ListGroup.Item>
                            <ListGroup.Item className="listgroupItemCls"> 
                                    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer posuere
                                    erat a ante.
                                <div className="listItemCls">
                                Jan 21, 2021
                                </div>
                            </ListGroup.Item>
                            <ListGroup.Item className="listgroupItemCls"> 
                                    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer posuere
                                    erat a ante.
                                <div className="listItemCls">
                                Jan 21, 2021
                                </div>
                            </ListGroup.Item>
                            <ListGroup.Item className="listgroupItemCls"> 
                                    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer posuere
                                    erat a ante.
                                <div className="listItemCls">
                                Jan 21, 2021
                                </div>
                            </ListGroup.Item>
                            <ListGroup.Item className="listgroupItemCls"> 
                                    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer posuere
                                    erat a ante.
                                <div className="listItemCls">
                                Jan 21, 2021
                                </div>
                            </ListGroup.Item>
                            <ListGroup.Item className="listgroupItemCls"> 
                                    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer posuere
                                    erat a ante.
                                <div className="listItemCls">
                                Jan 21, 2021
                                </div>
                            </ListGroup.Item>
                        </ListGroup>
                    </Card.Body>
                </Card>
           </Col>
        </Row>
    )
}

export default Dashboard;