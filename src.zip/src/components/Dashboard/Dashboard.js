/* eslint-disable react-hooks/exhaustive-deps */
import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import {
    Row,
    Col,  Spinner,
    Card, ListGroup, 
} from 'react-bootstrap';
import Empty from '../../assets/icons/illustrationEmpty.svg';
import './Dashboard.scss';
import warningIcon from "../../assets/icons/warning-outline.svg";
import blockedIcon from "../../assets/icons/filled_svg/Icon-blocked_white.svg";
import approvalIcon from "../../assets/icons/icon-checkbox-outline.svg";
import { retrieveDashboardData, retrieveAnnounceMent } from '../../actions/login';
import { useMsal } from "@azure/msal-react";
import Moment from 'moment';
import { useDispatch, useSelector } from "react-redux";
const constructGreetingText = ( date, accounts ) => {
    let greetingText = '';
    let currentHour = date.getHours();
    if( currentHour >= 0 && currentHour < 4 ) {
        greetingText = `Good night, ${accounts?.name}!`;
    } else if( currentHour >= 4 && currentHour < 12 ) {
        greetingText = `Good morning, ${accounts?.name}!`;
    } else if( currentHour >= 12 && currentHour < 16 ) {
        greetingText = `Good afternoon, ${accounts?.name}!`;
    } else if ( currentHour >= 16 && currentHour < 19 ) {
        greetingText = `Good evening, ${accounts?.name}!`;
    } else if ( currentHour >= 19 && currentHour <= 23 ) {
        greetingText = `Good night, ${accounts?.name}!`;
    }
    return greetingText;
}

const isLeftCardAvail = ( approval , channel ) => approval  || channel

const fetchInstance = ( instance ) => (instance.getAllAccounts() && instance.getAllAccounts()[0])||{}

function Dashboard(props) {
    let { Approval, Announcement, CBL } = props;
    const { instance } = useMsal();
    const accounts = fetchInstance( instance) ;
    let date = new Date();
    let greetingText = constructGreetingText(date, accounts);
    let stringDate = Moment(date).format('dddd, MMM DD, YYYY hh:mm A')
   
    const retData = useSelector( state => state.loginReducer);
    const { dashboard = {}, announcementList={}} = retData;
    const [ dashboardData = dashboard,] = useState()
    const [ announcementData = announcementList, ] = useState()
    const { data={}, } = dashboardData;
    const { errorResponse = {}} = announcementList;
    const listData  =  announcementData?.data    
    const { blocked =0, pendingApproval = 0, thresholdReached = 0 } = data;
    const dispatch = useDispatch();
    const constructErrorDiv = ( lstData ) => {
        let divEle = '';
        if( errorResponse && Object.keys(errorResponse).length > 0) {
            divEle = (
                <div>
                    <img src={Empty} alt="noData" />
                    <div><span>{errorResponse.ccmErrorCode} - {errorResponse.errorDescription}</span></div>                                                    
                </div>
            )  
        } else if(lstData === undefined){
            divEle = (
                <div className="alignCenter verticalCenter">
                    <Spinner animation="border" />
                </div>
            )
        }  else {
            divEle = (
            <>
                <img src={Empty} alt="noData" />
                <div><span>No announcement found</span></div>
            </>
            )
        }
        return divEle
    }
    useEffect(() => {
        setTimeout(() => {
            dispatch(retrieveDashboardData())
            dispatch(retrieveAnnounceMent())
        },1000);
    },[])
    return (
        <div>
            <div className="headerBlockD">
                <div className="greetingBlock">
                    <span>{greetingText}</span>
                </div>
                <div className="timeBlock">
                    <span>{stringDate}</span>
                </div>
            </div>
            <Row className="mt-2 mr-2 ml-2 dashboard">
                {isLeftCardAvail(Approval  , CBL) ? (
                    <Col sm={4}>
                        {Approval && (
                        <Card>
                            <Link to={"/approvalPage"} className="linkDiv">
                                <Card.Body>
                                    <Card.Title>Transaction Overview</Card.Title>
                                    <Card.Text className="card-body dashboardCard">
                                        <span className="card-body-text">Pending approvals</span>
                                        <div className="cardBodyCls bg-approval"> <img alt="approval" src={approvalIcon} className="cardIconCls approval"></img></div>
                                        <div className="card-body-number"><a href="/">{pendingApproval}</a></div>
                                    </Card.Text>
                                </Card.Body>
                            </Link>
                        </Card>
                        )}
                        {CBL &&(
                            <Card className={`w-100 ${Approval && "mt-3"}`}>
                                <Link to={"/gatewaymanagment/channels"} className="linkDiv">
                                    <Card.Body>
                                        <Card.Title>Channel Summary</Card.Title>
                                        <Card.Text className="card-body dashboardCard">
                                            <span className="card-body-text">Blocked</span>
                                            <div className="cardBodyCls bg-blocked"> <img alt="blocked" src={blockedIcon} className="cardIconCls"></img></div>
                                            <div className="card-body-number"><a href="/">{blocked}</a></div>
                                        </Card.Text>
                                        <Card.Text className="card-body dashboardCard">
                                            <span className="card-body-text">Reached threshold</span>
                                            <div className="cardBodyCls bg-reached-threshold"> <img alt="warning" src={warningIcon} className="cardIconCls"></img></div>
                                            <div className="card-body-number"><a href="/">{thresholdReached}</a></div>
                                        </Card.Text>
                                    </Card.Body>
                                </Link>
                            </Card>
                        )}
                    </Col>
                ):""}
                { Announcement && (
                    <Col sm={isLeftCardAvail(Approval  , CBL)?8:12}>
                        <Card className="w-100">
                            <Card.Body>
                                <Card.Title>Announcements</Card.Title>
                                
                                    {
                                        (listData && listData.length !== 0) ?(
                                            <ListGroup className="listGroupCls">
                                                { listData.map( (ele, idx)  => (
                                                    <ListGroup.Item key={`${ele}_${idx}`} className="listgroupItemCls">
                                                        {ele.message}
                                                        <div className="listItemCls">
                                                            {Moment(ele.date).format('ll')}
                                                        </div>
                                                    </ListGroup.Item>
                                                ))}
                                            </ListGroup>
                                        ):(
                                            <div className="noData">
                                               {constructErrorDiv(listData)}
                                            </div>
                                        )
                                    }
                            </Card.Body>
                        </Card>
                    </Col>
                )}
            </Row>
        </div>
    )
}

export default Dashboard;