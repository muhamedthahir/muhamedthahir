import httpClient from "../http-common";

const getAll = async (paramsData) => {
    const axios = await httpClient()
    return axios.get(`/approval${paramsData}`)
    // return httpClient().get("/newviewAllPending");
};
const getAllApproval = async (paramsData) => {
    const axios = await httpClient();
    return axios.get(`/approval${paramsData}`)
    // return httpClient().get("/newviewAllApproval");
};

const getAllRejected = async (paramsData) => {
    const axios = await httpClient()
    return axios.get(`/approval${paramsData}`)
    // return httpClient().get("/newviewAllRejected");
};

const updateApprovalStatus = async (paramsData) => {
    const axios = await httpClient()
    return axios.put('/approval', paramsData)
};



const ApprovalService = {
    getAll,
    getAllRejected,
    getAllApproval,
    updateApprovalStatus
  };
  
  export default ApprovalService;
  