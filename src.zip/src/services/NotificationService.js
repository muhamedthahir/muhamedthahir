import http from "../http-common";

const getAll = (paramsData='') => {
    const reqData = paramsData ? `?${paramsData}`:''
    return http.get(`/b/X6K6${reqData}`);
};

const getDowntime = (paramsData='') => {
    const reqData = paramsData ? `?${paramsData}`:''
    return http.get(`/b/LHO8${reqData}`);
};


const updateDowntime = (paramsData='') => {
    const reqData = paramsData ? `?${paramsData}`:''
    return http.get(`/b/IQYE${reqData}`);
};


const NotificationService = {
    getAll,
    getDowntime,
    updateDowntime
}


export default NotificationService;
