import httpClient from "../http-common";

const getAllDowntimeNotification = (paramsData='') => {
    return httpClient().get(`/notificationList`);
};

const getDowntime = (paramsData='') => {
    return httpClient().get(`/viewNotification`);
};


const updateDowntime = (paramsData='') => {
    return httpClient().get(`/addOrUpdateChannel`);
};

const addOrUpdateNotification = (params) => {
    return httpClient().get(`/addOrUpdateChannel`)
}


const getAll = (paramsData) => {
    return httpClient().get(`/getNotifications${paramsData?paramsData:''}`)
};
const getRecord = paramsData => {
    return httpClient().get(`/getNotificationsRecord`)
};

const NotificationService = {
    getAll,
    getDowntime,
    getRecord,
    updateDowntime,
    addOrUpdateNotification,
    getAllDowntimeNotification
}


export default NotificationService;
