import http from "../http-common";

const getAll = (paramsData='') => {
    const reqData = paramsData ? `?${paramsData}`:''
    return http.get(`/b/X6K6${reqData}`);
};


const NotificationService = {
    getAll
}


export default NotificationService;
