import httpClient from "../http-common";

const retrieveDashboardData = async ( callBack) => {
    const axios = await httpClient();
    const res =  axios.get(`/dashboard/summary`)
    callBack(res)
}
const createUserSession = async (data={}) => {
    const axios = await httpClient();
    return axios.post(`/userSessions`,{},{
        headers: { ...data}
    })
}

const retrieveAnnounceMent = async ( callBack) => {
    const axios = await httpClient();
    const res =  axios.get(`/dashboard/announcements`)
    callBack(res)
} 
const LoginService = {
    retrieveDashboardData,
    retrieveAnnounceMent,
    createUserSession
}

export default LoginService;
