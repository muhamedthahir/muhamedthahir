import httpClient from "../http-common";

const getAll = async (paramsData) => {
  const axios = await httpClient()
  return axios.get(`/getAllCcmParameters${paramsData?paramsData:''}`)
};

const get = async paramsData => {
  const axios = await httpClient()
  return axios.get(`/getCcmParameter/${paramsData}`)
};

const create = async paramsData => {
  const axios = await httpClient()
  return axios.post("/add-ccm-parameter", paramsData);
};

const update = async (paramsData) => {
  const axios = await httpClient()
  return axios.put("/update-ccm-parameter", paramsData);
};

const remove =  async id => {
  const axios = await httpClient()
  return axios.delete(`/posts/${id}`);
};

const removeAll =  async () => {
  const axios = await httpClient()
  return axios.delete(`/posts`);
};
const find =  async  (paramData) => {
  const axios = await httpClient()
  return axios.get(`/findCCMParameter${paramData?"?"+paramData:''}`);
};

const findByTitle =  async  title => {
  const axios = await httpClient()
  return axios.get(`/posts?title=${title}`);
};

const updateCCMStatus =  async  data => {
  const axios = await httpClient()
  return axios.put("/enable-ccm-parameter", data);
}

const disableCCMStatus =  async data => {
  const axios = await httpClient()
  return axios.put("/disable-ccm-parameter", data);
}
const CcmService = {
  getAll,
  get,
  create,
  update,
  remove,
  removeAll,
  findByTitle,
  updateCCMStatus,
  find,
  disableCCMStatus
};

export default CcmService;
