import http from "../http-common";

const getAll = (paramsData='') => {
  const reqData = paramsData ? `?${paramsData}`:''
  return http.get(`/b/LVL9${reqData}`);
};

const get = paramsData => {
  return http.get(`/b/6SQ7?${paramsData}`);
};

const getAllGatewayProvider = () => {
  return http.get("/b/O06V");
};


const create = data => {
  return http.post("/posts", data);
};

const update = (id, data) => {
  return http.put(`/posts/${id}`, data);
};

const remove = id => {
  return http.delete(`/posts/${id}`);
};

const removeAll = () => {
  return http.delete(`/posts`);
};

const findByTitle = title => {
  return http.get(`/posts?title=${title}`);
};

const getGatewaySettings = id => {
  return http.get(`/b/4ZP7?${id}`);
};

const getGatewayProviders = id => {
  return http.get(`/b/V7G7?${id}`);
}

const getGatewayProviderSetting = id => {
  return http.get(`/b/DCQZ?${id}`);
}

const getAllChannal = () => {
  return http.get(`/b/2AUZ`);
}
const getGatewaySettingForGwType = paramsData => {
  return http.get(`/gateway-settings${paramsData}`);
}

const getGatewayProviderForGwType = paramsData => {
  return http.get(`/gateway-providers${paramsData}`);
}

const getChannelStatus = () => {
  return http.get(`/b/IQYE`);
}

const retriveAllSetting = () => {
  return http.get(`/b/LKVS`);
}

const retriveInitialData = () => {
  return http.get(`/b/VGUN`);
}

const addOrUpdateGateway =(reqObj) => {
  return http.get(`/b/LHXQ`)
}

const GatewayService = {
  getAll,
  get,
  getAllGatewayProvider,
  create,
  update,
  remove,
  removeAll,
  findByTitle,
  getGatewaySettings,
  getGatewayProviders,
  getGatewayProviderSetting,
  getAllChannal,
  getGatewaySettingForGwType,
  getGatewayProviderForGwType,
  getChannelStatus,
  retriveAllSetting,
  retriveInitialData,
  addOrUpdateGateway
};

export default GatewayService;
