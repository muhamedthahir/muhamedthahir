import httpClient from "../http-common";
const getAll = async (paramsData = '') => {
  const reqData = paramsData ? `?${paramsData}` : ''
  const axios = await httpClient();
  return axios.get(`/gateways${reqData}`)
};

const get = async paramsData => {
  const axios = await httpClient();
  return axios.get(`/gateways/${paramsData}`);
};

const getAllGatewayProvider = async (paramData = `forApproval=false`) => {
  const axios = await httpClient();
  return axios.get(`/providers/?${paramData}`);
};
const getAllFindGatewayProvider = async (paramData = `forApproval=${false}`) => {
  const axios = await httpClient();
  return axios.get(`/providers/findGatewayProvider/?${paramData}`);
};


const create = async data => {
  const axios = await httpClient();
  return axios.post("/posts", data);
};

const update = async (id, data) => {
  const axios = await httpClient();
  return axios.put(`/posts/${id}`, data);
};

const remove = async id => {
  const axios = await httpClient();
  return axios.delete(`/posts/${id}`);
};

const removeAll = async () => {
  const axios = await httpClient();
  return axios.delete(`/posts`);
};

const findByTitle = async title => {
  const axios = await httpClient();
  return axios.get(`/posts?title=${title}`);
};

const getGatewaySettings = async id => {
  const axios = await httpClient();
  return axios.get(`/viewSettings`);
};

const getGatewayProviders = async id => {
  const axios = await httpClient();
  return axios.get(`/getProvider`);
}

const getGatewayProviderSetting = async id => {
  const axios = await httpClient();
  return axios.get(`/b/DCQZ?${id}`);
}

const getAllChannal = async (paramData) => {
  const axios = await httpClient();
  return axios.get(`/channel/${paramData}`);
}
const getGatewaySettingForGwType = async paramsData => {
  const axios = await httpClient();
  return axios.get(`/gateway-settings/${paramsData}`);
}

const getGatewayProviderForGwType = async paramsData => {
  const axios = await httpClient();
  return axios.get(`/gateway-providers/${paramsData}`);
}

const getChannelStatus = async (data) => {
  const axios = await httpClient();
  return axios.put(`/channel/unblock`, data);
}

const retriveAllSetting = async () => {
  const axios = await httpClient();
  return axios.get(`/settingList`);
}

const retriveInitialData = async () => {
  const axios = await httpClient();
  return axios.get(`/initialInfo`);
}

const retrieveChannelSummary = async () => {
  const axios = await httpClient();
  return axios.get(`/channel/info`);
}

const addGateway = async (reqObj) => {
  const axios = await httpClient();
  return axios.post(`/gateways`, reqObj);
}

const updateGateway = async (reqObj) => {
  const axios = await httpClient();
  return axios.put(`/gateways`, reqObj);
}
const addProvider = async (paramData) => {
  const axios = await httpClient();
  return axios.post(`/providers`, paramData);
}

const updateProvider = async (paramData) => {
  const axios = await httpClient();
  return axios.put(`/providers`, paramData);
}

const GatewayService = {
  getAll,
  get,
  getAllGatewayProvider,
  getAllFindGatewayProvider,
  create,
  update,
  remove,
  removeAll,
  findByTitle,
  getGatewaySettings,
  getGatewayProviders,
  getGatewayProviderSetting,
  getAllChannal,
  getGatewaySettingForGwType,
  getGatewayProviderForGwType,
  getChannelStatus,
  retriveAllSetting,
  retrieveChannelSummary,
  retriveInitialData,
  addGateway,
  updateGateway,
  addProvider,
  updateProvider
};

export default GatewayService;
