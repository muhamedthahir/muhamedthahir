/* eslint-disable react-hooks/exhaustive-deps */
import React, { useEffect, useState } from "react";
import { BrowserRouter as Router, Switch, Route } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";
import "./App.scss";
import Header from "./components/Global/Header/Header";
import { useIsAuthenticated, useMsal } from "@azure/msal-react";
import SideBar from "./components/Global/SideBar/Sidebar";
import GatewayPage from "./pages/GatewayPage";
import CCMPage from "./pages/CCMPage";
import ApprovalPage from "./pages/ApprovalPage";
import NotificationsPage from "./pages/NotificationPage";
import ViewAllGatewayProviders from "./components/GatewayManagement/ViewAllGatewayProviders";
import AuthorizeComponent from "./components/Global/Authorize/AuthorizeComponent";
import DashboardPage from "./pages/DashboardPage";
import Login from "./components/Login/Login";
import {
  updateMsalInstance,
  updateAuthorizeMod,
  updateSsoToken,
} from "./actions/login";
import { useDispatch } from "react-redux";
import { loginRequest } from "./components/Login/authConfig";

const getRootClass = (isActive) => isActive ? "sidebarView " : "sidebarView50";

const parseGroups = (groupList = []) => {
  let moduleObj = {};
  if (groupList.length > 0) {
    [...groupList].forEach((ele) => {
      let indexOfModule = ele.indexOf("-SubM-");
      if (indexOfModule !== -1) {
        let replacedString = ele.substring(indexOfModule + 6);
        const [module, subMod] = replacedString.split("-");
        if (moduleObj[module] === undefined) {
          moduleObj[module] = [];
        }
        if (subMod) {
          moduleObj[module].push(subMod);
        }
      }
    });
  }
  return moduleObj;
};

function App(props) {
  const dispatch = useDispatch();
  const [isActive, setActive] = useState(true);
  const isAuth = useIsAuthenticated();
  const { instance } = useMsal();
  const toggleClass = () => {
    setActive(!isActive);
  };

  useEffect(() => {
    const accounts =
      (instance.getAllAccounts() && instance.getAllAccounts()[0]) || {};
    dispatch(updateMsalInstance({ instance }));
    if (accounts && Object.keys(accounts).length > 0) {
      instance
        ?.acquireTokenSilent({
          ...loginRequest,
          account: accounts[0],
        })
        .then((resp) => {
          dispatch(updateSsoToken(resp.accessToken));
        });
    }
    const { idTokenClaims = {} } = accounts;
    const { groups = [] } = idTokenClaims;
    const parsedGroup = parseGroups(groups);
    console.log("sa", parsedGroup);
    dispatch(updateAuthorizeMod(parsedGroup));
  }, [isAuth]);
  return isAuth ? (
    <>
      <Router>
        <div className="container-fluid mainview">
          <div class="row">
            <div className={getRootClass(isActive)}>
              <AuthorizeComponent
                Component={(cProps) => (
                  <SideBar {...cProps} setActive={setActive} />
                )}
                type="entitlements"
                module="entitlements"
                isActive={isActive}
                toggleClass={toggleClass}
              />
            </div>
            <div className="col p-0 mainContainer">
              <Header isActive={isActive} toggleClass={toggleClass} />
              <div className="mainLayout">
                <Switch>
                  <Route path={"/gatewaymanagment"} component={GatewayPage} />
                  <Route path={"/ccmparameter"} component={CCMPage} />
                  <Route
                    path={"/notifications"}
                    component={NotificationsPage}
                  />
                  <Route path={"/approvalPage"} component={ApprovalPage} />
                  <Route path={"/notification"} component={NotificationsPage} />
                  <Route
                    path={"/gatewayprovider"}
                    component={ViewAllGatewayProviders}
                    exact
                  />
                  <Route path={"/"} component={DashboardPage} exact />
                </Switch>
              </div>
            </div>
          </div>
        </div>
      </Router>
    </>
  ) : (
    <Login />
  );
}
export default App;
