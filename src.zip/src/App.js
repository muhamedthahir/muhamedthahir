
import React, { useState } from "react";
import { BrowserRouter as Router, Switch, Route } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";
import "./App.scss";
import Header from "./components/Global/Header/Header";
import SideBar from "./components/Global/SideBar/Sidebar";
import GatewayPage from './pages/GatewayPage';
import CCMPage from "./pages/CCMPage";
import ApprovalPage from "./pages/ApprovalPage";
import ViewAllGatewayProviders from './components/GatewayManagement/ViewAllGatewayProviders';
import AuthorizeComponent from './components/Global/Authorize/AuthorizeComponent';
import NotificationPage from "./pages/NotificationPage";
import DashboardPage from "./pages/DashboardPage";

function App(props) {
  const [isActive, setActive] = useState(true);
  console.log('props', props)
  const toggleClass = () => {
    setActive(!isActive);
  };
  return (
    <Router >
      <div  className="container-fluid mainview">
      <div class="row">
            <div className= {isActive?"sidebarView ":"sidebarView50"}>
            <AuthorizeComponent
              Component={(cProps) => <SideBar {...cProps} />}
              type="entitlements"
              module="entitlements"
              isActive={isActive} 
              toggleClass={toggleClass}
          />
            </div>
            <div className="col p-0">
            <Header   isActive={isActive} 
              toggleClass={toggleClass}/>
            <div className="mainLayout">
              <Switch>
                <Route  path={"/gatewaymanagment"} component={GatewayPage} />
                <Route  path={"/ccmparameter"} component={CCMPage} />
                <Route  path={"/approvalPage"} component={ApprovalPage} />
                <Route path={"/notification"} component={NotificationPage} />
                <Route path={"/gatewayprovider"} component={ViewAllGatewayProviders} exact/>
                <Route path={"/"} component={DashboardPage} exact/>
              </Switch>
            </div>
            </div>
        </div>    
     
      </div>
    </Router>
  );
}

export default App;

