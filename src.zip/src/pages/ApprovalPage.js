import React from 'react';

import { Switch, Route } from "react-router-dom";
import ApprovalHome from '../components/Approval/ApprovalHome'
import AuthorizeComponent from '../components/Global/Authorize/AuthorizeComponent';


const AuthorizeApprovalHome = (parentProps) => 
    <AuthorizeComponent 
        Component={(props) => 
            <ApprovalHome 
                {...props}
                {...parentProps}
            />} 
        module="Approval" 
    />
function ApprovalPage(props) {
    return (
        <Switch>
            <Route path={"/"} component={AuthorizeApprovalHome} />
        </Switch>
    )
}
export default ApprovalPage;
