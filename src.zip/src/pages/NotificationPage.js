import React from 'react';

import { Switch, Route } from "react-router-dom";
import ViewAllScheduleTime from '../components/Notification/ViewAllScheduleTime';
import ScheduleDowntime from '../components/Notification/ScheduleDownTime'

function NotificationPage(props) {
    console.log('adfsf')
    return (
        <Switch>
            <Route path={"/notification/viewdowntime/:id"} component={ScheduleDowntime} exact />    
            <Route path={"/notification/downtime"} component={ViewAllScheduleTime} />
        </Switch>
    )
}
export default NotificationPage;
