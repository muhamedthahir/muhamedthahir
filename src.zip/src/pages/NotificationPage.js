import React from 'react';

import { Switch, Route } from "react-router-dom";
import ViewAllScheduleTime from '../components/Notification/ViewAllScheduleTime'

function NotificationPage(props) {
    console.log('adfsf')
    return (
        <Switch>
            <Route path={"/notification/downtime"} component={ViewAllScheduleTime} exact />
        </Switch>
    )
}
export default NotificationPage;
