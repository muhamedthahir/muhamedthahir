import React from 'react';

import { Switch, Route } from "react-router-dom";
import ViewAllScheduleTime from '../components/Notification/ViewAllScheduleTime';
import ScheduleDowntime from '../components/Notification/ScheduleDownTime';
import ViewAllNotifications from '../components/notifications/ViewAllNotifications';
import ViewNotificationRecord from '../components/notifications/ViewNotificationRecord';

function NotificationPage(props) {
    return (
        <Switch>
            <Route path={"/notification/viewdowntime/:id"} component={ScheduleDowntime} exact />    
            <Route path={"/notification/downtime"} component={ViewAllScheduleTime} />
            <Route path={"/notifications/:id"} component={ViewNotificationRecord} />
            <Route path={"/"} component={ViewAllNotifications} />
        </Switch>
    )
}
export default NotificationPage;
