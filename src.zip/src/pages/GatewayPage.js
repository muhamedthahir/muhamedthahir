import React from 'react';

import { Switch, Route } from "react-router-dom";
import ViewAllGatewayType from '../components/GatewayManagement/ViewAllGatewayType';
import ViewGatewayRecord from '../components/GatewayManagement/ViewGatewayRecord';
import ViewGatewaySettings from '../components/GatewayManagement/ViewGatewaySettings';
import AuthorizeComponent from '../components/Global/Authorize/AuthorizeComponent';
import ViewGatewayProviders from '../components/GatewayManagement/ViewGatewayProviders';
import ViewGatewayProviderSetting from '../components/GatewayManagement/ViewGatewayProviderSetting';
import ViewGwProviderSetting from '../components/GatewayManagement/ViewGwProviderSetting';
import ViewGatewayProviderSpecificGw from '../components/GatewayManagement/ViewGatewayProviderSpecificGw';
import EnrollGateway from '../components/GatewayManagement/EnrollGateway';
import ViewAllChannels from '../components/GatewayManagement/ViewAllChannels';
import ViewAllGatewayProvider from '../components/GatewayManagement/ViewAllGatewayProviders';

const AuthorizedViewAllGatewayType = (parentProps) => <AuthorizeComponent Component={(props) => <ViewAllGatewayType {...props} {...parentProps} />} type="ViewList" module="Gatew"  />
const AuthorizedEnrollGateway = (parentProps) => <AuthorizeComponent Component={(props) => <EnrollGateway name="settings" {...props} {...parentProps} />} type="Create" module="Gatew"  />
const AuthorizedViewGatewayRecord = (parentProps) => <AuthorizeComponent Component={(props) => <ViewGatewayRecord  {...props} {...parentProps} />} type="ViewRecord" module="Gatew"  />
const AuthorizedViewGatewaySettings = (parentProps) => <AuthorizeComponent Component={(props) => <ViewGatewaySettings {...props} {...parentProps} />} type="ViewRecord" module="GateSet" />
const AuthorizedViewAllChannels = (parentProps) => <AuthorizeComponent Component={(props) => <ViewAllChannels {...props} {...parentProps} />} type="ViewList" module="CBL"  />
const AuthorizedViewGatewayProviderSetting = (parentProps) => <AuthorizeComponent Component={(props) => <ViewGatewayProviderSetting {...props} {...parentProps} />} type="ViewRecord" module="GatePro"  />
const AuthorizedViewGatewayProviderSpecificGw = (parentProps) => <AuthorizeComponent Component={(props) => <ViewGatewayProviderSpecificGw {...props} {...parentProps} />} type="ViewRecord" module="GatePro"  />

function GatewayPage(props) {
    return (
        <>
            <Switch>
                <Route path={"/gatewaymanagment/EnrollGateway"} component={AuthorizedEnrollGateway} exact/>
                <Route path={"/gatewaymanagment/gatewayProvider/:providercode/:id"} component={ViewGwProviderSetting} exact />
                <Route path={"/gatewaymanagment/gatewayProviders/:providerCode/:id"} component={AuthorizedViewGatewayProviderSetting} exact />
                <Route path={"/gatewaymanagment/gatewayProviders/:id"} component={ViewGatewayProviders} exact />
                <Route path={"/gatewaymanagment/gatewayProvidersGw/:id"} component={AuthorizedViewGatewayProviderSpecificGw} exact />
                <Route path={"/gatewaymanagment/gatewaySettings/:id"} component={AuthorizedViewGatewaySettings} />
                <Route path={"/gatewaymanagment/providers"} component={ViewAllGatewayProvider} exact />
                <Route path={"/gatewaymanagment/channels"} component={AuthorizedViewAllChannels} exact />
                <Route path={"/gatewaymanagment/:id"} component={AuthorizedViewGatewayRecord} />
                <Route path={"/gatewaymanagment"} component={AuthorizedViewAllGatewayType}  />
            </Switch>
        </>
    )
}
export default GatewayPage;
