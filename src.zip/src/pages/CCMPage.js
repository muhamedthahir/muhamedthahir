import React from 'react';

import { Switch, Route } from "react-router-dom";
import ViewAllCcmParameter from '../components/CcmParameter/ViewAllCcmParameter';
import AddCCMParameter from '../components/CcmParameter/AddCCMParameter';
import ViewCCMRecord from '../components/CcmParameter/ViewCCMRecord';
import AuthorizeComponent from '../components/Global/Authorize/AuthorizeComponent';

const AuthorizeAddCCMParameter = (parentProps) => <AuthorizeComponent Component={(props) => <AddCCMParameter {...props} {...parentProps} />} type="ViewRecord" module="CCMP"  />
const AuthorizeViewAllCcmParameter = (parentProps) => <AuthorizeComponent Component={(props) => <ViewAllCcmParameter {...props} {...parentProps} />} type="ViewList" module="CCMP"  />
function CCMPage(props) {
    return (
        <Switch>
            <Route path={"/ccmparameter/addccmparameter"} component={AuthorizeAddCCMParameter} />
            <Route path={"/ccmparameter/:id"} component={ViewCCMRecord} exact/>
            <Route path={"/"} component={AuthorizeViewAllCcmParameter} />
        </Switch>
    )
}
export default CCMPage;
