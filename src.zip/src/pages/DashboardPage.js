import React from 'react';

import { Switch, Route } from "react-router-dom";
import Dashboard from '../components/Dashboard/Dashboard';

function DashboardPage(props) {
    return (
        <Switch>
            <Route path={"/"} component={Dashboard} />
        </Switch>
    )
}
export default DashboardPage;
