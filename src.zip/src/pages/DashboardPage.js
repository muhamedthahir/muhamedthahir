import React from 'react';

import { Switch, Route } from "react-router-dom";
import Dashboard from '../components/Dashboard/Dashboard';
import AuthorizeComponent from '../components/Global/Authorize/AuthorizeComponent';

const AuthorizeDashboard = (parentProps) => 
    <AuthorizeComponent 
        Component={(props) => 
            <Dashboard 
                {...props}
                {...parentProps}
            />} 
        module="Dashboard" 
    />
function DashboardPage(props) {
    return (
        <>
            <Switch>
               <Route path={"/"} component={AuthorizeDashboard} />
            </Switch>
        </>
    )
}
export default DashboardPage;
