
export const alphaNumericSorting = (frstValue, scndValue, colId, desc = false) => {
    if (frstValue && scndValue) {
      if (!desc) return frstValue.localeCompare(scndValue);
      return -1 * scndValue.localeCompare(frstValue);
    }
};
  
export const sortByElement = ( rowA, rowB, colId, desc) => {
    const findFn = ( entry ) => entry.column && (entry.column.id ===  colId)
    const foundAData = rowA.cells.find(findFn);
    const foundBData = rowB.cells.find(findFn);
    const aValue =  typeof rowA.cells[0] !== "function" && foundAData && foundAData.value.props.children;
    const bValue =  typeof rowB.cells[0] !== "function" && foundBData && foundBData.value.props.children;
    return alphaNumericSorting( aValue, bValue, colId, desc)
}
  


export const selectList = [5,10, 20, 30, 40, 50,100];
export const findNextMaxNo = ( pSize) => {
    let no = pSize;
    for (let itr =0; itr < selectList.length; itr++){
        if( pSize < selectList[itr]) return selectList[itr]
        else if( pSize === selectList[itr]) return pSize
    }
    return no
}
