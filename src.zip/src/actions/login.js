import {
    UPDATE_MSAL_INSTANCE, 
    UPDATE_AUTH_OBJ,
    VIEW_DASHBOARD,
    UPDATE_SSO_TOKEN,
    CREATE_USER_SESSION,
    VIEW_ALL_ANNOUNCEMENT
} from './types';
import commonerror from './commonerror';
import LoginService from '../services/LoginService';

export const updateMsalInstance = ( data ) => async(dispatch) => {
    dispatch({
        type: UPDATE_MSAL_INSTANCE,
        payload: data,
    });
}

export const updateSsoToken = ( data ) => async(dispatch) => {
    dispatch({
        type: UPDATE_SSO_TOKEN,
        payload: data,
    });
}


export const updateAuthorizeMod = ( data ) => async(dispatch) => {
    dispatch({
        type: UPDATE_AUTH_OBJ,
        payload: data,
    });
}

export const createUserSession = ( data ) => async(dispatch) => {
    try {
        const res = await LoginService.createUserSession(data);
        dispatch({
          type: CREATE_USER_SESSION,
          payload: { data: res.data },
        });
    } catch (err) {
        dispatch({
          type: CREATE_USER_SESSION,
          payload: { errorResponse: err.response && err.response.data },
        });
    }
}

export const retrieveDashboardData = () => async(dispatch) => {
    try {
        await LoginService.retrieveDashboardData((res) => {
            res.then((response) => {
                try {
                    dispatch({
                        type: VIEW_DASHBOARD,
                        payload: { data: response.data },
                    });
                } catch (err) {
                    commonerror(err)
                    dispatch({
                      type: VIEW_DASHBOARD,
                      payload: { errorResponse: err.response && err.response.data },
                    });
                }
            })
        });
    } catch (err) {
        commonerror(err)
        dispatch({
          type: VIEW_DASHBOARD,
          payload: { errorResponse: err.response && err.response.data },
        });
    }
}

export const retrieveAnnounceMent = () => async(dispatch) => {
    try {
        await LoginService.retrieveAnnounceMent((res) => {
            res.then((response) => {
                try {
                    dispatch({
                        type: VIEW_ALL_ANNOUNCEMENT,
                        payload: { data: response.data.data },
                    });
                } catch (err) {
                    commonerror(err)
                    dispatch({
                      type: VIEW_ALL_ANNOUNCEMENT,
                      payload: { errorResponse: err?.response?.data },
                    });
                }
            })
            .catch((err) => {
                commonerror(err)
                dispatch({
                  type: VIEW_ALL_ANNOUNCEMENT,
                  payload: { errorResponse: err?.response?.data },
                });
            })
        });
    } catch (err) {
        dispatch({
          type: VIEW_ALL_ANNOUNCEMENT,
          payload: { errorResponse: err.response && err.response.data },
        });
    }
}