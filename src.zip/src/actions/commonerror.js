const commonerror = (err) => {
    if(!err?.response?.data?.ccmErrorCode){
      if(err?.response?.status === 404){
        err.response.data.errorCode = err.response.data.status +"_BAD Request"
        err.response.data.ccmErrorCode = err.response.data.status +"_BAD Request"
         err.response.data.errorDescription = err.response.data.error
      } else if(err?.response?.status === 408){
        err.response.data.errorCode = "400_BAD Request"
        err.response.data.ccmErrorCode = "CCM-GEN-ERR-0001"
         err.response.data.errorDescription = "System error occured due to timeout issue"
      } else if(err?.response?.status === 400){
        err.response.data = {}
        err.response.data.errorCode = "400_BAD Request"
        err.response.data.ccmErrorCode = "400_BAD Request"
        err.response.data.errorDescription = "Error Encountered"
      } else if(err?.response?.status === 503){
        err.response.data = {}
        err.response.data.errorCode = "503_BAD Request"
        err.response.data.ccmErrorCode = "503_BAD Request"
        err.response.data.errorDescription = "Error Encountered"
      } else {
        err.response = {data :{}};
        err.response.data.errorCode = "Error occured, unable to retrive data"
        err.response.data.ccmErrorCode = "Error occured, unable to retrive data"
        err.response.data.errorDescription = "Please refresh and try again later"
      }
    }
  }

export default commonerror