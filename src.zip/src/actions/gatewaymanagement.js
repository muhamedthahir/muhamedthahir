import {
    VIEW_GATEWAY_TYPE,
    VIEW_ALL_GATEWAY_TYPE,
    VIEW_ALL_GATEWAY_PROVIDER,
    VIEW_GATEWAY_SETIINGS,
    VIEW_GATEWAY_PROVIDERS,
    VIEW_GATEWAY_PROVIDER_SETTING,
    VIEW_ALL_CHANNAL,
    UNBLOCK_CHANNEL,  
    VIEW_GWS_FOR_GWTYPE,
    VIEW_GWPR_FOR_GWTYPE,
    VIEW_ALL_GW_SETTING_CODE,
    GATEWAY_INITIAL_DATA,
    GATEWAY_TYPE_SUBMIT,
    VIEW_GATEWAY_PROVIDER_SETIINGS
  } from "./types";
  
  import GatewayService from "../services/GatewayService";

  export const retrieveAllGatewayType = ( paramsData ) => async (dispatch) => {
    try {
      const res = await GatewayService.getAll(paramsData);
      dispatch({
        type: VIEW_ALL_GATEWAY_TYPE,
        payload: res.data,
      });
    } catch (err) {
      dispatch({
        type: VIEW_ALL_GATEWAY_TYPE,
        payload: { errorResponse: err.response && err.response.data },
      });
    }
  };

  export const retrieveGatewayRecord = ( id ) => async (dispatch) => {
    try {
      const res = await GatewayService.get(id);
      dispatch({
        type: VIEW_GATEWAY_TYPE,
        payload: res.data,
      });
    } catch (err) {
      dispatch({
        type: VIEW_GATEWAY_TYPE,
        payload:{ errorResponse: err.response && err.response.data },
      });
    }
  };

  export const updateLocalData = ( updateObj ) => async (dispatch) => {
    try {
      dispatch({
        type: VIEW_GATEWAY_TYPE,
        payload: updateObj,
      });
    } catch (err) {
      console.log(err);
    }
  };
  
  export const retrieveAllGatewayProvider = () => async (dispatch) => {
    try {
      const res = await GatewayService.getAllGatewayProvider();
      dispatch({
        type: VIEW_ALL_GATEWAY_PROVIDER,
        payload: res.data,
      });
    } catch (err) {
      console.log(err);
    }
  };

  export const retrieveGatewaySettings = (id) => async (dispatch) => {
    try {
      const res = await GatewayService.getGatewaySettings( id);
      dispatch({
        type: VIEW_GATEWAY_SETIINGS,
        payload: res.data,
      });
    } catch (err) {
      console.log(err);
    }
  };
  
  export const retrieveGatewayProviders = (id) => async (dispatch) => {
    try {
      const res = await GatewayService.getGatewayProviders( id);
      dispatch({
        type: VIEW_GATEWAY_PROVIDERS,
        payload: res.data,
      });
    } catch (err) {
      console.log(err);
    }
  };
  
  export const retrieveGatewayProviderSetting = (id) => async (dispatch) => {
    try {
      const res = await GatewayService.getGatewayProviderSetting( id);
      dispatch({
        type: VIEW_GATEWAY_PROVIDER_SETTING,
        payload: res.data,
      });
    } catch (err) {
      console.log(err);
    }
  };

  export const retrieveAllGwSettingForGwType = (paramData) => async (dispatch) => {
    try {
      const res = await GatewayService.getGatewaySettingForGwType( paramData);
      dispatch({
        type: VIEW_GWS_FOR_GWTYPE,
        payload: res.data,
      });
    } catch (err) {
      dispatch({
        type: VIEW_GWS_FOR_GWTYPE,
        payload: { errorResponse: err.response && err.response.data },
      });
    }
  };

  export const retrieveAllGwProviderForGwType = (paramData) => async (dispatch) => {
    try {
      const res = await GatewayService.getGatewayProviderForGwType( paramData);
      dispatch({
        type: VIEW_GWPR_FOR_GWTYPE,
        payload: res.data,
      });
    } catch (err) {
      dispatch({
        type: VIEW_GWPR_FOR_GWTYPE,
        payload: { errorResponse: err.response && err.response.data },
      });
    }
  };


  export const retrieveAllChannal = ( paramsData ) => async (dispatch) => {
    try {
      const res = await GatewayService.getAllChannal(paramsData);
      dispatch({
        type: VIEW_ALL_CHANNAL,
        payload: res.data,
      });
    } catch (err) {
      console.log(err);
    }
  };

  export const updateChannelStatus = ( paramsData, callback ) => async (dispatch) => {
    try {
      const res = await GatewayService.getChannelStatus(paramsData);
      callback(res.data);
      dispatch({
        type: UNBLOCK_CHANNEL,
        payload: res.data,
      });
    } catch (err) {
      console.log(err);
    }
  };

  export const retreiveAllSettingsCode = (paramData) => async (dispatch) => {
    try {
      const res = await GatewayService.retriveAllSetting(paramData);
      dispatch({
        type: VIEW_ALL_GW_SETTING_CODE,
        payload: res.data,
      });
    } catch (err) {
      dispatch({
        type: VIEW_ALL_GW_SETTING_CODE,
        payload: { errorResponse: err.response && err.response.data },
      });
    }
  };

  export const addGatewayRecord = () => async (dispatch) => {
    try {
      const res = await GatewayService.retriveInitialData();
      dispatch({
        type: GATEWAY_INITIAL_DATA,
        payload: res.data,
      });
    } catch (err) {
      dispatch({
        type: GATEWAY_INITIAL_DATA,
        payload: { errorResponse: err.response && err.response.data },
      });
    }
  };
  export const addOrUpdateGateway = (reqObj, callback) => async (dispatch) => {
    try {
      const res = await GatewayService.addOrUpdateGateway(reqObj);
      callback(res.data);
      dispatch({
        type: GATEWAY_TYPE_SUBMIT,
        payload: res.data,
      });
    } catch (err) {
      dispatch({
        type: GATEWAY_TYPE_SUBMIT,
        payload: { errorResponse: err.response && err.response.data },
      });
    }
  };
  

  export const updateLocalValue = (value ) => async (dispatch) => {
    try {
      dispatch({
        type: VIEW_GATEWAY_SETIINGS,
        payload: { data: value},
      });
    } catch (err) {
      console.log('err', err);
    }
  };

  export const updateLocalGwProviderValue = (value ) => async (dispatch) => {
    try {
      dispatch({
        type: VIEW_GATEWAY_PROVIDER_SETIINGS,
        payload: { data: value},
      });
    } catch (err) {
      console.log('err', err);
    }
  };

