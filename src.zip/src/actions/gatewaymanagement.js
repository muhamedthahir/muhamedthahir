import {
  VIEW_GATEWAY_TYPE,
  VIEW_ALL_GATEWAY_TYPE,
  VIEW_ALL_GATEWAY_PROVIDER,
  VIEW_GATEWAY_SETIINGS,
  VIEW_GATEWAY_PROVIDERS,
  VIEW_ALL_CHANNAL,
  UNBLOCK_CHANNEL,
  VIEW_GWS_FOR_GWTYPE,
  VIEW_GWPR_FOR_GWTYPE,
  VIEW_ALL_GW_SETTING_CODE,
  GATEWAY_INITIAL_DATA,
  GATEWAY_TYPE_SUBMIT,
  VIEW_GATEWAY_PROVIDER_RECORD,
  VIEW_GATEWAY_PROVIDER_SETIINGS,
  VIEW_CHANNEL_SUMMARY,
  ADD_GATEWAY_PROVIDER,
} from "./types";

import GatewayService from "../services/GatewayService";
import CcmService from "../services/CcmService";

const constructObj = (arrayObj, accountUserId, action) =>
  arrayObj.map((ele) => {
    return {
      // ...ele,
      code: action !== "add" ? null : ele.code,
      name: ele.fieldName,
      description: ele.description,
      value: ele.fieldValue,
      status: ele.status,
      params: {
        dataType: ele.dataType,
        dataFormat: ele.dataFormat,
        fieldDefaultValue: ele.defaultValue,
        maximumValue: ele.maximumValue,
        minimumValue: ele.minimumValue,
        dataList: ele.dataList,
        affectedModules: ele.affectedModule,
      },
      reason: ele.reason,
      isUpdated: ele.isUpdate ? ele.isUpdate : false,
      isNewlyAdded: ele.isNewlyAdded ? ele.isNewlyAdded : false,
      updatedUserId: accountUserId,
      forApproval: true,
    };
  });

  const isNotNewlyAdded = ( ele ) => (ele.isNewlyAdded ? false : true)
  const constructObjForProvider = (arrayObj, accountUserId,  action) =>
  arrayObj.map((ele) => {
    return {
      // ...ele,
      // code: action !== "add" ? null : ele.code,
      name: ele.fieldName,
      description: ele.description,
      value: ele.fieldValue,
      status: ele.status,
      params: {
        dataType: ele.dataType,
        dataFormat: ele.dataFormat,
        fieldDefaultValue: ele.defaultValue,
        maximumValue: ele.maximumValue ,
        minimumValue: ele.minimumValue,
        dataList: ele.dataList,
        affectedModules: ele.affectedModule,
      },
      reason: ele.reason,
      isUpdated: ele.isUpdate?  isNotNewlyAdded(ele): false,
      isNewlyAdded: ele.isNewlyAdded ? ele.isNewlyAdded : false,
      // forApproval: true,
    };
  });

const parseRequest = (requestObj, accountUserId, action) => {
  let newObj = {};
  newObj.updatedUserId = accountUserId;
  newObj.gatewayRequestDTO = {
    ...requestObj["gatewayTypeDetails"],
    code: requestObj["gatewayTypeDetails"].gatewayCode,
    updatedUserId: accountUserId,
    status: requestObj["gatewayTypeDetails"].status? requestObj["gatewayTypeDetails"].status: false,
    forApproval: true,
    isNewlyAdded: action !== "add" ? false : true,
    isUpdated: action !== "add" ? true : false,
  };
  newObj.listGatewaySettingsRequestDTO = constructObj(
    requestObj["gatewaySettingsList"],
    accountUserId,
    action
  );
  newObj.listGatewayProviderMappingRequestDTO = requestObj[
    "gatewayProviderList"
  ].map((ele) => {
    return {
      code: ele.code,
      forApproval: (ele.isNewlyAdded || ele.isUpdated)? true: false,
      updatedUserId: accountUserId,
      isNewlyAdded: ele.isNewlyAdded?ele.isNewlyAdded: false,
      isUpdated: ele.isUpdated?ele.isUpdated:false,      
      distributionPercentageWeight: ele.distributionPercentage,
      status: ele.status,
      gatewayProviderRequestDTO: {
        code: ele.code,
        name: ele.name,
        description: ele.description,
        internalApiIntegration: ele.apiIntegration,
        gatewayURL: ele.providerUrl,
        gatewayPort: ele.gatewayPort,
        status: ele.gatewayProviderStatus,
        forApproval: false,
      },
      listGatewayProviderMappingSettingsRequestDTO: constructObj(
        ele["gatewayProviderSettingList"],
        accountUserId,
        action
      ),
    };
  });

  return newObj;
};
export const addProvider =
  (paramData, accountUserId, id, callback) => async (dispatch) => {
    try {
      console.log('sa',paramData)
      const reconstructorObj = {
        gatewayProviderRequest: {
          "status": paramData.status,
          "internalApiIntegration":  paramData.internalApiIntegration,
          "name":paramData.fieldName,
          "description": paramData.fieldDescription,
          "remarks":  paramData.reason,
          "gatewayURL": paramData.gatewayDomain,
          "gatewayPort":paramData.gatewayPort,
          "clientId": paramData.clientId,
          "secretId": paramData.secretId,
          "reason":  paramData.reason,
          isUpdated: id === "ADD"? false: true,
          isNewlyAdded: id !== "ADD"?false:true,
        },
        gatewayProviderSettingList: constructObjForProvider(
          paramData.gatewayProviderSettingList,
          accountUserId
        ),
      };
      let res;
      console.log('res', reconstructorObj);
      if( id === "ADD") {
        res = await GatewayService.addProvider(reconstructorObj);
      } else {
        res = await GatewayService.updateProvider(reconstructorObj);
      }
      dispatch({
        type: ADD_GATEWAY_PROVIDER,
        payload: res.data,
      });
      callback(res);
    } catch (err) {
      callback(err.response);
      dispatch({
        type: ADD_GATEWAY_PROVIDER,
        payload: { errorResponse: err.response && err.response.data },
      });
    }
  };

export const retrieveAllGatewayType = (paramsData) => async (dispatch) => {
  try {
    const res = await GatewayService.getAll(paramsData);
    dispatch({
      type: VIEW_ALL_GATEWAY_TYPE,
      payload: res.data,
    });
  } catch (err) {
    dispatch({
      type: VIEW_ALL_GATEWAY_TYPE,
      payload: { errorResponse: err.response && err.response.data },
    });
  }
};

const constructSettingMap = (listMap) => {
  return listMap.map((ele) => {
    return {
      ...ele,
      ...ele.params,
      gatewaySettingsCode: ele.code,
      fieldName: ele.name,
      fieldValue: ele.value,
      dataType: ele.params.dataType.toLowerCase(),
      defaultValue: ele.params.fieldDefaultValue,
      affectedModule: ele.params.affectedModules,
    };
  });
};

const constructProviderMap = (list) => {
  return list.map((ele) => {
    return {
      ...ele.gatewayProvider,
      ...ele,
      gatewayProviderStatus: ele.gatewayProvider.status,
      gatewayProviderForApproval: ele.gatewayProvider.forApproval,
      distributionPercentage: ele.distributionPercentageWeight,
      apiIntegration: ele.gatewayProvider.internalApiIntegration,
      providerUrl: ele.gatewayProvider.gatewayURL,
      gatewayProviderSettingList: constructSettingMap(
        ele.gatewayProviderMappingSettingList
      ),
    };
  });
};

export const retrieveGatewayRecord = (id) => async (dispatch) => {
  try {
    const res = await GatewayService.get(id);
    let retData = {};
    if (res.data) {
      retData.gatewayTypeDetails = {
        ...res.data.gateway,
        gatewayCode: res.data.gateway.code,
      };
      retData.gatewaySettingsList = constructSettingMap([
        ...res.data.gateway.gatewayParameterSettingList,
      ]);
      retData.gatewayProviderList = constructProviderMap([
        ...res.data.gatewayProviderMappingList,
      ]);
    }
    dispatch({
      type: VIEW_GATEWAY_TYPE,
      payload: { data: retData },
    });
  } catch (err) {
    dispatch({
      type: VIEW_GATEWAY_TYPE,
      payload: { errorResponse: err.response && err.response.data },
    });
  }
};

export const updateLocalData = (updateObj) => async (dispatch) => {
  try {
    dispatch({
      type: VIEW_GATEWAY_TYPE,
      payload: updateObj,
    });
  } catch (err) {
    console.log(err);
  }
};

export const retrieveAllGatewayProvider = () => async (dispatch) => {
  try {
    const res = await GatewayService.getAllGatewayProvider();
    let data = res.data.data.map((elem) => {
      if (
        elem.gatewayProviderSettingList === "null" ||
        elem.gatewayProviderSettingList === null
      )
        elem.gatewayProviderSettingList = [];
      return elem;
    });
    dispatch({
      type: VIEW_ALL_GATEWAY_PROVIDER,
      payload: data,
    });
  } catch (err) {
    console.log(err);
  }
};
export const retrieveAllGatewayProviderNew =
  (paramsData) => async (dispatch) => {
    try {
      const res = await GatewayService.getAllGatewayProvider(paramsData);
      dispatch({
        type: VIEW_ALL_GATEWAY_PROVIDER,
        payload: res.data,
      });
    } catch (err) {
      console.log(err);
      dispatch({
        type: VIEW_ALL_GATEWAY_PROVIDER,
        payload: { errorResponse: err.response && err.response.data },
      });
    }
  };
export const retrieveAllFindGatewayProviderNew =
  (paramsData) => async (dispatch) => {
    try {
      const res = await GatewayService.getAllFindGatewayProvider(paramsData);
      dispatch({
        type: VIEW_ALL_GATEWAY_PROVIDER,
        payload: res.data,
      });
    } catch (err) {
      console.log(err);
      dispatch({
        type: VIEW_ALL_GATEWAY_PROVIDER,
        payload: { errorResponse: err.response && err.response.data },
      });
    }
  };
export const retrieveGatewaySettings = (id, settingList) => (dispatch) => {
  try {
    let searchObj =
      settingList && settingList.filter((ele) => ele.code === id)[0];
    searchObj = {
      ...searchObj,
      gatewaySettingsCode: searchObj.code,
      fieldName: searchObj.name,
      ...searchObj.params,
      fieldValue: searchObj.value,
      affectedModule: searchObj.params.affectedModules,
      dataType:
        searchObj.params.dataType[0].toLowerCase() +
        searchObj.params.dataType.substring(
          1,
          searchObj.params.dataType.length
        ),
      defaultValue: searchObj.params.fieldDefaultValue,
    };
    const res = { data: { data: searchObj } };
    dispatch({
      type: VIEW_GATEWAY_SETIINGS,
      payload: res.data,
    });
  } catch (err) {
    console.log(err);
  }
};

export const retrieveGatewayProviders = (id, list) => async (dispatch) => {
  try {
    let obj = list && list.find((ele) => ele.code === id);
    const res = {
      data: {
        ...obj,
        providerUrl: obj.gatewayURL,
        apiIntegration: obj.internalApiIntegration,
        gatewayProviderStatus: obj.status,
        gatewayProviderForApproval: obj.forApproval,
        status: false,
        forApproval: undefined,
        gatewayProviderSettingList: obj.gatewayProviderSettingList.map(
          (item) => {
            return {
              ...item,
              fieldName: item.name,
              fieldValue: item.value,
              ...item.params,
              defaultValue: item.params.fieldDefaultValue,
              affectedModule: item.params.affectedModules,
            };
          }
        ),
      },
    };
    dispatch({
      type: VIEW_GATEWAY_PROVIDERS,
      payload: res.data,
    });
  } catch (err) {
    console.log(err);
  }
};

export const retrieveGatewayProvidersApi =
  (id, totalElements) => async (dispatch) => {
    try {
      const res = await GatewayService.getAllFindGatewayProvider(
        `searchText=${id}&searchType=providerCode&pageNumber=${1}&pageSize=${totalElements}`
      );
      const filterData = res.data.data.filter((ele) => ele.code === id)[0];
      const resObj = { data: filterData } || {};
      if (
        resObj.data.gatewayProviderSettingList === "null" ||
        resObj.data.gatewayProviderSettingList === null
      ) {
        resObj.data.gatewayProviderSettingList = [];
      }
      resObj.data.gatewayProviderSettingList =
        resObj.data.gatewayProviderSettingList.map((obj) => {
          return {
            ...obj,
            fieldName: obj.name,
            fieldValue: obj.value,
            ...obj.params,
            defaultValue: obj.params.fieldDefaultValue,
            affectedModule: obj.params.affectedModules,
          };
        });
      resObj.data.fieldCode = resObj.data.code;
      resObj.data.fieldName = resObj.data.name;
      resObj.data.fieldDescription = resObj.data.description;
      resObj.data.gatewayDomain = resObj.data.gatewayURL;
      resObj.data.reason = resObj.data.remarks;
      dispatch({
        type: VIEW_GATEWAY_PROVIDER_RECORD,
        payload: resObj,
      });
    } catch (err) {
      console.log(err);
    }
  };

export const retrieveGatewayProviderSetting = (id) => async (dispatch) => {
  try {
    const res = await GatewayService.getGatewayProviders(id);
    dispatch({
      type: VIEW_GATEWAY_PROVIDER_RECORD,
      payload: res.data,
    });
  } catch (err) {
    console.log(err);
  }
};

export const retrieveAllGwSettingForGwType =
  (paramData) => async (dispatch) => {
    try {
      const res = await GatewayService.getGatewaySettingForGwType(paramData);
      dispatch({
        type: VIEW_GWS_FOR_GWTYPE,
        payload: res.data,
      });
    } catch (err) {
      dispatch({
        type: VIEW_GWS_FOR_GWTYPE,
        payload: { errorResponse: err.response && err.response.data },
      });
    }
  };

export const retrieveAllGwProviderForGwType =
  (paramData) => async (dispatch) => {
    try {
      const res = await GatewayService.getGatewayProviderForGwType(paramData);
      dispatch({
        type: VIEW_GWPR_FOR_GWTYPE,
        payload: res.data,
      });
    } catch (err) {
      dispatch({
        type: VIEW_GWPR_FOR_GWTYPE,
        payload: { errorResponse: err.response && err.response.data },
      });
    }
  };

export const retrieveAllChannal = (paramsData) => async (dispatch) => {
  try {
    const res = await GatewayService.getAllChannal(paramsData);
    dispatch({
      type: VIEW_ALL_CHANNAL,
      payload: res.data,
    });
  } catch (err) {
    console.log(err);
    dispatch({
      type: VIEW_ALL_CHANNAL,
      payload: { errorResponse: err.response && err.response.data },
    });
  }
};

export const updateChannelStatus =
  (paramsData, callback) => async (dispatch) => {
    try {
      const res = await GatewayService.getChannelStatus(paramsData);
      callback(res.data);
      dispatch({
        type: UNBLOCK_CHANNEL,
        payload: res.data,
      });
    } catch (err) {
      console.log(err);
      callback({ errorResponse: err.response && err.response.data });
      dispatch({
        type: UNBLOCK_CHANNEL,
        payload: { errorResponse: err.response && err.response.data },
      });
    }
  };

export const retreiveAllSettingsCode =
  (paramData, list) => async (dispatch) => {
    try {
      const response = await GatewayService.get(paramData);
      const res = {
        data: {
          data: {
            settingCodeList:
              response?.data?.gateway?.gatewayParameterSettingList,
          },
        },
      };
      dispatch({
        type: VIEW_ALL_GW_SETTING_CODE,
        payload: res.data,
      });
    } catch (err) {
      dispatch({
        type: VIEW_ALL_GW_SETTING_CODE,
        payload: { errorResponse: err.response && err.response.data },
      });
    }
  };

export const addGatewayRecord = () => async (dispatch) => {
  try {
    let initalData = {};
    let res1, res2, res;
    try {
      const responseData = await CcmService.find(
        `searchText=ccm_maximum_number_of_allowable_gateway_settings&searchType=FieldCode&pageSize=1&pageNumber=1`
      );
      res = (responseData?.data && responseData?.data?.data[0].fieldValue) || 10;
    } catch ( err) {
      res = 10;
    }
    try {
      const resData = await CcmService.find(
        `searchText=ccm_maximum_allowable_number_of_gateway_providers&searchType=FieldCode&pageSize=1&pageNumber=1`
      );  
      res1 = (resData && resData?.data?.data[0].fieldValue) || 1;
    } catch(err) {
      res1 = 1;
    } 
    try {
      const respData = await CcmService.find(
        `searchText=ccm_maximum_allowable_no_of_provider_mapping_settings&searchType=FieldCode&pageSize=1&pageNumber=1`
      );
      res2 = (respData?.data && respData?.data?.data[0].fieldValue) || 5;
    } catch ( err ) {
      res2 = 5;
    } 
    console.log('res', res, res1,res2)
    initalData.data = {
      maximumNoOfAllowablegwSettings: res,
      maximumNoOfAllowablegwProvider: res1,
      maximumNoOfAllowablegwProviderSettings: res2,
    };
    dispatch({
      type: GATEWAY_INITIAL_DATA,
      payload: initalData,
    });
  } catch (err) {
    dispatch({
      type: GATEWAY_INITIAL_DATA,
      payload: { errorResponse: err.response && err.response.data },
    });
  }
};
export const addOrUpdateGateway =
  (reqObj, accountUserId, action, callback) => async (dispatch) => {
    const reconstructReqObj = parseRequest(reqObj, accountUserId, action);
    console.log('asd',reconstructReqObj)
    try {
      let res;
      if (action === "add") {
        reconstructReqObj.action = "Enroll";
        res = await GatewayService.addGateway(reconstructReqObj, action);
      } else {
        reconstructReqObj.action = "Update";
        res = await GatewayService.updateGateway(reconstructReqObj, action);
      }
      callback(res);
    } catch (err) {
      callback(err.response);
      dispatch({
        type: GATEWAY_TYPE_SUBMIT,
        payload: { errorResponse: err.response && err.response.data },
      });
    }
  };

export const updateLocalValue = (value) => async (dispatch) => {
  try {
    dispatch({
      type: VIEW_GATEWAY_SETIINGS,
      payload: { data: value },
    });
  } catch (err) {
    console.log("err", err);
  }
};

export const updateLocalGwProviderValue = (value) => async (dispatch) => {
  try {
    dispatch({
      type: VIEW_GATEWAY_PROVIDER_SETIINGS,
      payload: { data: value },
    });
  } catch (err) {
    console.log("err", err);
  }
};

export const retrieveChannelSummary = () => async (dispatch) => {
  try {
    const res = await GatewayService.retrieveChannelSummary();
    dispatch({
      type: VIEW_CHANNEL_SUMMARY,
      payload: { data: res.data },
    });
  } catch (err) {
    dispatch({
      type: VIEW_CHANNEL_SUMMARY,
      payload: { errorResponse: err.response && err.response.data },
    });
  }
};

export const updateGwProviderLocalData = (updateObj) => async (dispatch) => {
  try {
    dispatch({
      type: VIEW_GATEWAY_PROVIDER_RECORD,
      payload: updateObj,
    });
  } catch (err) {
    console.log(err);
  }
};
