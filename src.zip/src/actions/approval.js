import ApprovalService from "../services/ApprovalService";

import  {
    VIEW_ALL_PENDING,
    VIEW_ALL_APPROVAL,
    VIEW_ALL_REJECTED
} from './types';

export const retrieveAllPendingList = ( paramsData ) => async (dispatch) => {
    try {
      const res = await ApprovalService.getAll(paramsData);
      dispatch({
        type: VIEW_ALL_PENDING,
        payload: res.data,
      });
    } catch (err) {
        dispatch({
            type: VIEW_ALL_PENDING,
            payload: { errorResponse: err.response && err.response.data},
      });
  } 
};


export const retrieveAllApprovedList = ( paramsData ) => async (dispatch) => {
    try {
      const res = await ApprovalService.getAllApproval(paramsData);
      dispatch({
        type: VIEW_ALL_APPROVAL,
        payload: res.data,
      });
    } catch (err) {
        dispatch({
            type: VIEW_ALL_APPROVAL,
            payload: { errorResponse: err.response && err.response.data},
        });
    }
  };

  export const retrieveAllRejectedList = ( paramsData ) => async (dispatch) => {
    try {
      const res = await ApprovalService.getAllRejected(paramsData);
      dispatch({
        type: VIEW_ALL_REJECTED,
        payload: res.data,
      });
    } catch (err) {
        dispatch({
            type: VIEW_ALL_REJECTED,
            payload: { errorResponse: err.response && err.response.data},
        });
    }
  };



