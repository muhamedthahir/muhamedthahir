import {
  VIEW_ALL_CCM_PARAMETER,
  VIEW_CCM_PARAMETER,
  ENABLE_CCM_PARAMETER
} from "./types";

import CcmService from "../services/CcmService";

export const retrieveAllCCMParameter = (paramData) => async (dispatch) => {
  try {
    const res = await CcmService.getAll(paramData);

    dispatch({
      type: VIEW_ALL_CCM_PARAMETER,
      payload: res.data,
    });
  } catch (err) {
    dispatch({
      type: VIEW_ALL_CCM_PARAMETER,
      payload: { errorResponse: err.response && err.response.data },
    });
  }
};
export const retrieveCCMRecord = ( id ) => async (dispatch) => {
  try {
    const res = await CcmService.get(id);
    dispatch({
      type: VIEW_CCM_PARAMETER,
      payload: res.data,
    });
  } catch (err) {
    dispatch({
      type: VIEW_CCM_PARAMETER,
      payload: { errorResponse: err.response && err.response.data },
    });
  }
};

export const updateCCMStatus = (data, callback) => async (dispatch) => {
  try {
    const res = await CcmService.updateCCMStatus(data);
    callback(res.data);
    dispatch({
      type: ENABLE_CCM_PARAMETER,
      payload: res.data,
    })
  } catch (err) {
    console.log(err);
  }
}

export const retrieveFindCCMParameter = (paramData) => async (dispatch) => {
  try {
    const res = await CcmService.find(paramData);
    dispatch({
      type: VIEW_ALL_CCM_PARAMETER,
      payload: res.data,
    });
  } catch (err) {
    dispatch({
      type: VIEW_ALL_CCM_PARAMETER,
      payload: { errorResponse: err.response && err.response.data },
    });
  }
};