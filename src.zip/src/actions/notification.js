import {
    VIEW_ALL_DOWNTIME_NOTIFICATION,
    VIEW_DOWNTIME_NOTIFICATION,
    DELETE_NOTIFICATION,
    VIEW_ALL_NOTIFICATIONS,
    VIEW_NOTIFICATION_RECORD
} from './types';

import NotificationService from "../services/NotificationService";

export const retrieveAllDowntimeNotification = ( paramsData ) => async (dispatch) => {
    try {
      const res = await NotificationService.getAllDowntimeNotification(paramsData);
      dispatch({
        type: VIEW_ALL_DOWNTIME_NOTIFICATION,
        payload: res.data,
      });
    } catch (err) {
      dispatch({
        type: VIEW_ALL_DOWNTIME_NOTIFICATION,
        payload: { errorResponse: err.response && err.response.data },
      });
    }
  };

  export const retriveScheduleDowntime = ( paramsData ) => async (dispatch) => {
    try {
      const res = await NotificationService.getDowntime(paramsData);
      dispatch({
        type: VIEW_DOWNTIME_NOTIFICATION,
        payload: res.data,
      });
    } catch (err) {
      dispatch({
        type: VIEW_DOWNTIME_NOTIFICATION,
        payload: { errorResponse: err.response && err.response.data },
      });
    }
  };

  export const updateNotification = ( paramsData, callback) => async (dispatch) => {
    try {
      const res = await NotificationService.updateDowntime(paramsData);
      callback(res.data);
      dispatch({
        type: DELETE_NOTIFICATION,
        payload: res.data,
      });
    } catch (err) {
      dispatch({
        type: DELETE_NOTIFICATION,
        payload: { errorResponse: err.response && err.response.data },
      });
    }
  };



  export const addOrUpdateNotification = ( paramsData, callback) => async (dispatch) => {
    try {
      const res = await NotificationService.addOrUpdateNotification(paramsData);
      callback(res.data);
      dispatch({
        type: DELETE_NOTIFICATION,
        payload: res.data,
      });
    } catch (err) {
      dispatch({
        type: DELETE_NOTIFICATION,
        payload: { errorResponse: err.response && err.response.data },
      });
    }
  };

  
  export const retrieveAllNotifications = (paramData) => async (dispatch) => {
    try {
      const res = await NotificationService.getAll(paramData);
  
      dispatch({
        type: VIEW_ALL_NOTIFICATIONS,
        payload: res.data,
      });
    } catch (err) {
      dispatch({
        type: VIEW_ALL_NOTIFICATIONS,
        payload: { errorResponse: err.response && err.response.data },
      });
    }
  };
  export const retrieveNotificationRecord = ( id ) => async (dispatch) => {
    try {
      const res = await NotificationService.getRecord(id);
      dispatch({
        type: VIEW_NOTIFICATION_RECORD,
        payload: res.data,
      });
    } catch (err) {
      dispatch({
        type: VIEW_NOTIFICATION_RECORD,
        payload: { errorResponse: err.response && err.response.data },
      });
    }
  };