import {
    VIEW_ALL_DOWNTIME_NOTIFICATION
} from './types';

import NotificationService from "../services/NotificationService";

export const retrieveAllDowntimeNotification = ( paramsData ) => async (dispatch) => {
    try {
      const res = await NotificationService.getAll(paramsData);
      dispatch({
        type: VIEW_ALL_DOWNTIME_NOTIFICATION,
        payload: res.data,
      });
    } catch (err) {
      dispatch({
        type: VIEW_ALL_DOWNTIME_NOTIFICATION,
        payload: { errorResponse: err.response && err.response.data },
      });
    }
  };