import Home from './lib/screen/home/Home';
import React from 'react';

export default function App() {
  return (
    <Home />
  );
}
